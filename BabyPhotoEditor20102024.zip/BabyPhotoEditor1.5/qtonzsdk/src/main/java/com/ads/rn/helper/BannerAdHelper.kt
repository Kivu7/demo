package com.recorder.video.player.activity

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.view.ViewParent
import android.widget.FrameLayout
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.lifecycleScope
import com.ads.rn.R
import com.ads.rn.ads.RNAd
import com.ads.rn.funtion.AdCallback
import com.ads.rn.helper.AdsHelper
import com.ads.rn.helper.banner.BannerAdConfig
import com.ads.rn.helper.banner.DefaultCallback
import com.ads.rn.helper.banner.param.AdBannerState
import com.ads.rn.helper.banner.param.BannerAdParam
import com.applovin.mediation.ads.MaxAdView
import com.facebook.shimmer.ShimmerFrameLayout
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

class BannerAdHelper(activity: Activity, lifecycleOwner: LifecycleOwner, config: BannerAdConfig) :
    AdsHelper<BannerAdConfig, BannerAdParam>(activity, lifecycleOwner, config) {
    public val activity: Activity = activity
    val adBannerState: MutableStateFlow<AdBannerState>
    private var bannerAdView: ViewGroup? = null
    private lateinit var bannerContentView: FrameLayout
    val config: BannerAdConfig = config
    private val impressionOnResume: AtomicBoolean
    private var job: Job? = null
    public val lifecycleOwner: LifecycleOwner = lifecycleOwner
    private val listAdCallback: CopyOnWriteArrayList<AdCallback>
    private val resumeCount: AtomicInteger
    private lateinit var shimmerLayoutView: ShimmerFrameLayout
    var timeShowAdImpression: Long = 0


    //    public static final class AnonymousClass1 extends SuspendLambda implements Function2<Lifecycle.Event, Continuation<? super Unit>, Object> {
    //        /* synthetic */ Object L$0;
    //        int label;
    //
    //        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    //        AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
    //            super(2, continuation);
    //            BannerAdHelper.this = r1;
    //        }
    //
    //        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    //        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
    //            AnonymousClass1 anonymousClass1 = new AnonymousClass1(continuation);
    //            anonymousClass1.L$0 = obj;
    //            return anonymousClass1;
    //        }
    //
    //        @Override // kotlin.jvm.functions.Function2
    //        public final Object invoke(Lifecycle.Event event, Continuation<? super Unit> continuation) {
    //            return ((AnonymousClass1) create(event, continuation)).invokeSuspend(Unit.INSTANCE);
    //        }
    //
    //        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    //        public final Object invokeSuspend(Object obj) {
    //            IntrinsicsKt.getCOROUTINE_SUSPENDED();
    //            if (this.label == 0) {
    //                ResultKt.throwOnFailure(obj);
    //                Lifecycle.Event event = (Lifecycle.Event) this.L$0;
    //                if (event == Lifecycle.Event.ON_CREATE && !BannerAdHelper.this.canRequestAds()) {
    //                    FrameLayout frameLayout = BannerAdHelper.this.bannerContentView;
    //                    if (frameLayout != null) {
    //                        frameLayout.setVisibility(8);
    //                    }
    //                    ShimmerFrameLayout shimmerFrameLayout = BannerAdHelper.this.shimmerLayoutView;
    //                    if (shimmerFrameLayout != null) {
    //                        shimmerFrameLayout.setVisibility(8);
    //                    }
    //                }
    //                if (event == Lifecycle.Event.ON_RESUME && !BannerAdHelper.this.canShowAds() && BannerAdHelper.this.isActiveState()) {
    //                    BannerAdHelper.this.cancel();
    //                }
    //                if (event == Lifecycle.Event.ON_PAUSE) {
    //                    BannerAdHelper bannerAdHelper = BannerAdHelper.this;
    //                    try {
    //                        Result.Companion companion = Result.Companion;
    //                        ViewGroup bannerAdView = bannerAdHelper.getBannerAdView();
    //                        if ((bannerAdView instanceof MaxAdView) && bannerAdHelper.config.getCanReloadAds()) {
    //                            ((MaxAdView) bannerAdView).stopAutoRefresh();
    //                        }
    //                        Result.m1215constructorimpl(Unit.INSTANCE);
    //                    } catch (Throwable th) {
    //                        Result.Companion companion2 = Result.Companion;
    //                        Result.m1215constructorimpl(ResultKt.createFailure(th));
    //                    }
    //                }
    //                if (event == Lifecycle.Event.ON_STOP) {
    //                    if (BannerAdHelper.this.config.getRemoteAdWhenStop()) {
    //                        BannerAdHelper bannerAdHelper2 = BannerAdHelper.this;
    //                        try {
    //                            Result.Companion companion3 = Result.Companion;
    //                            ViewGroup bannerAdView2 = bannerAdHelper2.getBannerAdView();
    //                            if (bannerAdView2 != null) {
    //                                ViewParent parent = bannerAdView2.getParent();
    //                                ViewGroup viewGroup = parent instanceof ViewGroup ? (ViewGroup) parent : null;
    //                                if (viewGroup != null) {
    //                                    viewGroup.removeView(bannerAdView2);
    //                                }
    //                            }
    //                            Result.m1215constructorimpl(Unit.INSTANCE);
    //                        } catch (Throwable th2) {
    //                            Result.Companion companion4 = Result.Companion;
    //                            Result.m1215constructorimpl(ResultKt.createFailure(th2));
    //                        }
    //                    }
    //                    BannerAdHelper.this.cancelAutoReload();
    //                }
    //                if (event == Lifecycle.Event.ON_START && BannerAdHelper.this.config.getRemoteAdWhenStop()) {
    //                    FrameLayout frameLayout2 = BannerAdHelper.this.bannerContentView;
    //                    ViewGroup bannerAdView3 = BannerAdHelper.this.getBannerAdView();
    //                    if (BannerAdHelper.this.canShowAds() && frameLayout2 != null && bannerAdView3 != null) {
    //                        BannerAdHelper.this.showAd(frameLayout2, bannerAdView3);
    //                    }
    //                }
    //                return Unit.INSTANCE;
    //            }
    //            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    //        }
    //    }
    //    public static final class AnonymousClass2 extends SuspendLambda implements Function2<Lifecycle.Event, Continuation<? super Unit>, Object> {
    //        Object L$0;
    //        int label;
    //
    //        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    //        AnonymousClass2(Continuation<? super AnonymousClass2> continuation) {
    //            super(2, continuation);
    //            BannerAdHelper.this = r1;
    //        }
    //
    //        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    //        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
    //            AnonymousClass2 anonymousClass2 = new AnonymousClass2(continuation);
    //            anonymousClass2.L$0 = obj;
    //            return anonymousClass2;
    //        }
    //
    //        @Override // kotlin.jvm.functions.Function2
    //        public final Object invoke(Lifecycle.Event event, Continuation<? super Unit> continuation) {
    //            return ((AnonymousClass2) create(event, continuation)).invokeSuspend(Unit.INSTANCE);
    //        }
    //
    //        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    //        public final Object invokeSuspend(Object obj) {
    //            IntrinsicsKt.getCOROUTINE_SUSPENDED();
    //            if (this.label == 0) {
    //                ResultKt.throwOnFailure(obj);
    //                Lifecycle.Event event = (Lifecycle.Event) this.L$0;
    //                if (event == Lifecycle.Event.ON_RESUME) {
    //                    BannerAdHelper.this.resumeCount.incrementAndGet();
    //                    BannerAdHelper.this.logZ$ads_release("Resume repeat " + BannerAdHelper.this.resumeCount.get() + " times");
    //                    if (!BannerAdHelper.this.isActiveState()) {
    //                        BannerAdHelper.this.logInterruptExecute$ads_release("Request when resume");
    //                    }
    //                }
    //                if (event == Lifecycle.Event.ON_RESUME && BannerAdHelper.this.resumeCount.get() > 1 && BannerAdHelper.this.getBannerAdView() != null && BannerAdHelper.this.canRequestAds() && BannerAdHelper.this.canReloadAd() && BannerAdHelper.this.isActiveState() && BannerAdHelper.this.impressionOnResume.get()) {
    //                    BannerAdHelper.this.logZ$ads_release("requestAds on resume");
    //                    BannerAdHelper.this.requestAds((BannerAdParam) BannerAdParam.Reload.INSTANCE);
    //                }
    //                if (!BannerAdHelper.this.impressionOnResume.get()) {
    //                    BannerAdHelper.this.impressionOnResume.set(true);
    //                }
    //                return Unit.INSTANCE;
    //            }
    //            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    //        }
    //    }
    //    public static final class AnonymousClass3 extends SuspendLambda implements Function2<AdBannerState, Continuation<? super Unit>, Object> {
    //     Object L$0;
    //        int label;
    //
    //        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    //        AnonymousClass3(Continuation<? super AnonymousClass3> continuation) {
    //            super(2, continuation);
    //            BannerAdHelper.this = r1;
    //        }
    //
    //        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    //        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
    //            AnonymousClass3 anonymousClass3 = new AnonymousClass3(continuation);
    //            anonymousClass3.L$0 = obj;
    //            return anonymousClass3;
    //        }
    //
    //        @Override // kotlin.jvm.functions.Function2
    //        public final Object invoke(AdBannerState adBannerState, Continuation<? super Unit> continuation) {
    //            return ((AnonymousClass3) create(adBannerState, continuation)).invokeSuspend(Unit.INSTANCE);
    //        }
    //
    //        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    //        public final Object invokeSuspend(Object obj) {
    //            IntrinsicsKt.getCOROUTINE_SUSPENDED();
    //            if (this.label == 0) {
    //                ResultKt.throwOnFailure(obj);
    //                BannerAdHelper.this.logZ$ads_release("adBannerState(" + ((AdBannerState) this.L$0).getClass().getSimpleName() + ')');
    //                return Unit.INSTANCE;
    //            }
    //            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    //        }
    //    }
    //    public static final class AnonymousClass4 extends SuspendLambda implements Function2<AdBannerState, Continuation<? super Unit>, Object> {
    //        Object L$0;
    //        int label;
    //
    //        AnonymousClass4(Continuation<? super AnonymousClass4> continuation) {
    //            super(2, continuation);
    //            BannerAdHelper.this = r1;
    //        }
    //
    //        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    //        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
    //            AnonymousClass4 anonymousClass4 = new AnonymousClass4(continuation);
    //            anonymousClass4.L$0 = obj;
    //            return anonymousClass4;
    //        }
    //
    //        @Override // kotlin.jvm.functions.Function2
    //        public final Object invoke(AdBannerState adBannerState, Continuation<? super Unit> continuation) {
    //            return ((AnonymousClass4) create(adBannerState, continuation)).invokeSuspend(Unit.INSTANCE);
    //        }
    //
    //        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    //        public final Object invokeSuspend(Object obj) {
    //            IntrinsicsKt.getCOROUTINE_SUSPENDED();
    //            if (this.label == 0) {
    //                ResultKt.throwOnFailure(obj);
    //                BannerAdHelper.this.handleShowAds((AdBannerState) this.L$0);
    //                return Unit.INSTANCE;
    //            }
    //            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    //        }
    //    }
    init {
        val MutableStateFlow: MutableStateFlow<AdBannerState> =
            MutableStateFlow<AdBannerState>(if (canRequestAds()) AdBannerState.None else AdBannerState.Fail)
        this.adBannerState = MutableStateFlow
        this.listAdCallback = CopyOnWriteArrayList<AdCallback>()
        this.resumeCount = AtomicInteger(0)
        this.impressionOnResume = AtomicBoolean(true)
        registerAdListener(defaultCallback)


//        FlowKt.onEach(getLifecycleEventState()) { event: Lifecycle.Event, continuation: Continuation<Unit>? ->
//            if (event == Lifecycle.Event.ON_CREATE && !this@BannerAdHelper.canRequestAds()) {
//                val frameLayout: FrameLayout? = this@BannerAdHelper.bannerContentView
//                if (frameLayout != null) {
//                    frameLayout.setVisibility(View.GONE)
//                }
//                val shimmerFrameLayout: ShimmerFrameLayout? = this@BannerAdHelper.shimmerLayoutView
//                if (shimmerFrameLayout != null) {
//                    shimmerFrameLayout.setVisibility(View.GONE)
//                }
//            }
//            if (event == Lifecycle.Event.ON_RESUME && !this@BannerAdHelper.canShowAds() && this@BannerAdHelper.isActiveState()) {
//                this@BannerAdHelper.cancel()
//            }
//            if (event == Lifecycle.Event.ON_PAUSE) {
//                val bannerAdHelper = this@BannerAdHelper
//                try {
//                    val bannerAdView: ViewGroup? = bannerAdHelper.getBannerAdView()
//                    if ((bannerAdView is MaxAdView) && bannerAdHelper.config.getCanReloadAds()) {
//                        (bannerAdView as MaxAdView?)?.stopAutoRefresh()
//                    }
//                } catch (th: Throwable) {
//                }
//            }
//            if (event == Lifecycle.Event.ON_STOP) {
//                if (this@BannerAdHelper.config.getRemoteAdWhenStop()) {
//                    val bannerAdHelper2 = this@BannerAdHelper
//                    try {
//                        val bannerAdView2: ViewGroup? = bannerAdHelper2.getBannerAdView()
//                        if (bannerAdView2 != null) {
//                            val parent: ViewParent = bannerAdView2.getParent()
//                            val viewGroup: ViewGroup? =
//                                if (parent is ViewGroup) parent as ViewGroup else null
//                            if (viewGroup != null) {
//                                viewGroup.removeView(bannerAdView2)
//                            }
//                        }
//                    } catch (th2: Throwable) {
//                    }
//                }
//                this@BannerAdHelper.cancelAutoReload()
//            }
//            if (event == Lifecycle.Event.ON_START && this@BannerAdHelper.config.getRemoteAdWhenStop()) {
//                val bannerAdView3: ViewGroup? = this@BannerAdHelper.getBannerAdView()
//                if (canShowAds() && bannerContentView != null && bannerAdView3 != null) {
//                    showAd(bannerContentView, bannerAdView3)
//                }
//            }
//            Unit
//        }.launchIn(lifecycleOwner.getLifecycle())
        observeLifecycleEvents()


//        FlowKt.onEach(
//            debounce(
//                getLifecycleEventState(),
//                config.getTimeDebounceResume()
//            )
//        ) { event: Lifecycle.Event, continuation: Continuation<Unit>? ->
//            if (event == Lifecycle.Event.ON_RESUME) {
//                resumeCount.incrementAndGet()
//                logZ("Resume repeat " + resumeCount.get() + " times")
//                if (!isActiveState()) {
//                    logInterruptExecute("Request when resume")
//                }
//            }
//            if ((event == Lifecycle.Event.ON_RESUME && resumeCount.get() > 1) && this@BannerAdHelper.getBannerAdView() != null && this@BannerAdHelper.canRequestAds() && this@BannerAdHelper.canReloadAd() && this@BannerAdHelper.isActiveState() && impressionOnResume.get()) {
//                logZ("requestAds on resume")
//                requestAds(BannerAdParam.Reload.INSTANCE as BannerAdParam)
//            }
//            if (!impressionOnResume.get()) {
//                impressionOnResume.set(true)
//            }
//            Unit
//        }.launchIn(lifecycleOwner.getLifecycle())
        observeLifecycleEvents2()

//        adBannerStateFlow
//            .onEach { adBannerState ->
//                logZ("adBannerState(${adBannerState::class.simpleName})")
//            }
//            .launchIn(lifecycleOwner.lifecycleScope)


//        FlowKt.onEach(MutableStateFlow) { adBannerState: AdBannerState?, continuation: Continuation<Unit>? ->
//            this@BannerAdHelper.handleShowAds(adBannerState as AdBannerState?)
//            null
//        }.launchIn(lifecycleOwner.getLifecycle())
        observeAdBannerState(adBannerState)

    }

    fun observeAdBannerState(adBannerStateFlow: MutableStateFlow<AdBannerState>) {
        adBannerStateFlow
            .onEach { adBannerState ->
                handleShowAds(adBannerState)
            }
            .launchIn(lifecycleOwner.lifecycleScope)
    }


    fun observeLifecycleEvents2() {
        getLifecycleEventState()
            .debounce(config.getTimeDebounceResume())
            .onEach { event ->
                if (event == Lifecycle.Event.ON_RESUME) {
                    resumeCount.incrementAndGet()
                    logZ("Resume repeat ${resumeCount.get()} times")

                    if (!isActiveState()) {
                        logInterruptExecute("Request when resume")
                    }

                    if (resumeCount.get() > 1 &&
                        getBannerAdView() != null &&
                        canRequestAds() &&
                        canReloadAd() &&
                        isActiveState() &&
                        impressionOnResume.get()
                    ) {
                        logZ("requestAds on resume")
                        requestAds(BannerAdParam.Reload as BannerAdParam)
                    }

                    if (!impressionOnResume.get()) {
                        impressionOnResume.set(true)
                    }
                }
            }
            .launchIn(lifecycleOwner.lifecycleScope)
    }

    fun observeLifecycleEvents() {
        getLifecycleEventState().onEach { event ->
                when (event) {
                    Lifecycle.Event.ON_CREATE -> {
                        if (!canRequestAds()) {
                            bannerContentView?.visibility = View.GONE
                            shimmerLayoutView?.visibility = View.GONE
                        }
                    }
                    Lifecycle.Event.ON_RESUME -> {
                        if (!canShowAds() && isActiveState()) {
                            cancel()
                        }
                    }
                    Lifecycle.Event.ON_PAUSE -> {
                        try {
                            val bannerAdView = getBannerAdView()
                            if (bannerAdView is MaxAdView && config.getCanReloadAds()) {
                                (bannerAdView as? MaxAdView)?.stopAutoRefresh()
                            }
                        } catch (th: Throwable) {
                            // Handle the exception
                        }
                    }
                    Lifecycle.Event.ON_STOP -> {
                        if (config.getRemoteAdWhenStop()) {
                            try {
                                val bannerAdView = getBannerAdView()
                                bannerAdView?.parent?.let { parent ->
                                    if (parent is ViewGroup) {
                                        parent.removeView(bannerAdView)
                                    }
                                }
                            } catch (th: Throwable) {
                                // Handle the exception
                            }
                        }
                        cancelAutoReload()
                    }
                    Lifecycle.Event.ON_START -> {
                        if (config.getRemoteAdWhenStop()) {
                            if (canShowAds() && bannerContentView != null) {
                                val bannerAdView = getBannerAdView()
                                if (bannerAdView != null) {
                                    showAd(bannerContentView, bannerAdView)
                                }
                            }
                        }
                    }
                    else -> {
                        // Handle other lifecycle events if needed
                    }
                }
            }
            .launchIn(lifecycleOwner.lifecycleScope) // Use lifecycleScope for launching coroutines
    }

    fun handleShowAds(adBannerState: AdBannerState?) {
        var frameLayout: FrameLayout?=null
        var z = true
        if (!canShowAds() && this.bannerContentView != null) {
            val collapsibleGravity: String = config.getCollapsibleGravity()
            if (!(collapsibleGravity == null || collapsibleGravity.length == 0)) {
                removeBannerCollapseIfNeed(bannerContentView)
            }
        }
        if (bannerContentView != null) {
            bannerContentView.setVisibility(if ((adBannerState is AdBannerState.Cancel) || !canShowAds()) View.GONE else View.VISIBLE)
        }
        if (shimmerLayoutView != null) {
            if (adBannerState !is AdBannerState.Loading || this.bannerAdView != null) {
                z = false
            }
            shimmerLayoutView.setVisibility(if (z) View.VISIBLE else View.GONE)
        }
        if (adBannerState !is AdBannerState.Loaded || (bannerContentView.also {
                frameLayout = it
            }) == null) {
            return
        }
        showAd(frameLayout, (adBannerState as AdBannerState.Loaded).adBanner)
    }

    fun invokeAdListener(function1: Function1<AdCallback, Unit>) {
        for (obj in this.listAdCallback) {
            function1.invoke(obj)
        }
    }

    private fun removeBannerCollapseIfNeed(viewGroup: ViewGroup) {
        val collapsibleGravity: String = config.getCollapsibleGravity()
        if (collapsibleGravity == null || collapsibleGravity.length == 0) {
            return
        }
        val childCount: Int = viewGroup.getChildCount()
        for (i in 0 until childCount) {
            val childAt: View = viewGroup.getChildAt(i)
            if (childAt is AdView) {
                childAt.destroy()
                childAt.setVisibility(View.GONE)
                viewGroup.removeView(childAt)
                return
            }
        }
    }

    fun showAd(frameLayout: FrameLayout?, viewGroup: ViewGroup?) {
        impressionOnResume.set(getLifecycleEventState().value === Lifecycle.Event.ON_RESUME)
        if (frameLayout?.indexOfChild(viewGroup) != -1) {
            logZ("bannerContentView has contains adView")
            return
        }
        frameLayout.setBackgroundColor(-1)
        val view = View(frameLayout.getContext())
        val view2 = View(frameLayout.getContext())
        view.setBackgroundColor(-1973791)
        val height: Int = frameLayout.getHeight()
        removeBannerCollapseIfNeed(frameLayout)
        val dimensionPixelOffset: Int =
            frameLayout.getContext().getResources().getDimensionPixelOffset(R.dimen._1sdp)
        frameLayout.removeAllViews()
        frameLayout.addView(view2, 0, height)
        val parent: ViewParent = viewGroup!!.getParent()
        val viewGroup2: ViewGroup? = if (parent is ViewGroup) parent as ViewGroup else null
        if (viewGroup2 != null) {
            viewGroup2.removeView(viewGroup)
        }
        frameLayout.addView(viewGroup, -1, -2)
        val layoutParams: ViewGroup.LayoutParams = viewGroup.getLayoutParams()
        if (layoutParams != null) {
            val layoutParams2: FrameLayout.LayoutParams = layoutParams as FrameLayout.LayoutParams
            layoutParams2.setMargins(0, dimensionPixelOffset, 0, 0)
            layoutParams2.gravity = 81
            viewGroup.setLayoutParams(layoutParams2)
            frameLayout.addView(view, -1, dimensionPixelOffset)
            updateHeightBannerMax(frameLayout)
            return
        }
        throw NullPointerException("null cannot be cast to non-null type android.widget.FrameLayout.LayoutParams")
    }

    private fun updateHeightBannerMax(viewGroup: ViewGroup) {
//        if (AperoAd.getInstance().getMediationProvider() == 0) {
//            return;
//        }
        val dimensionPixelSize: Int =
            activity.getResources().getDimensionPixelSize(R.dimen.banner_height)
        val layoutParams: ViewGroup.LayoutParams = viewGroup.getLayoutParams()
        layoutParams.width = -1
        layoutParams.height = dimensionPixelSize + 5
        viewGroup.setLayoutParams(layoutParams)
    }

    // com.ads.control.helper.AdsHelper
//    override fun cancel() {
//        logZ("cancel() called")
//        getFlagActive().compareAndSet(true, false)
//        this.bannerAdView = null
//        BuildersKt.launch(
//            lifecycleOwner.getLifecycle(),
//            Dispatchers.getIO(),
//            CoroutineStart.DEFAULT
//        ) { coroutineScope: CoroutineScope?, continuation: Continuation<Unit>? ->
//            val coroutine_suspended: Any = getCOROUTINE_SUSPENDED.getCOROUTINE_SUSPENDED()
//            val adBannerState: MutableStateFlow<AdBannerState> = getAdBannerState()
//            val cancel: Cancel = AdBannerState.Cancel.INSTANCE
//
//            if (adBannerState.emit(cancel, continuation) === coroutine_suspended) {
//                return@launch coroutine_suspended
//            }
//            Unit
//        }
//    }

    override fun cancel() {
        logZ("cancel() called")
        getFlagActive().compareAndSet(true, false)
        bannerAdView = null
        // Launch a coroutine in the IO dispatcher
        lifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
            val adBannerState = getAdBannerState()
            val cancel = AdBannerState.Cancel
            adBannerState.emit(cancel)
        }
    }


    protected fun cancelAutoReload() {
        logZ("cancelAutoReload")
        try {
            val job = this.job
            if (job != null) {
                job.cancel(null)
            } else {
            }
        } catch (th: Throwable) {
        }
        this.job = null
    }

    fun getAdBannerState(): MutableStateFlow<AdBannerState> {
        return this.adBannerState
    }

    val bannerAdConfig: BannerAdConfig
        get() = this.config

    fun getBannerAdView(): ViewGroup? {
        return this.bannerAdView
    }

    val bannerState: StateFlow<AdBannerState>
        get() = adBannerState.asStateFlow()

    protected val defaultCallback: AdCallback
        get() = DefaultCallback(this)

    fun invokeListenerAdCallback(): AdCallback {
        return object : AdCallback() {
            // com.ads.control.funtion.AdCallback
            override fun onAdClicked() {
                super.onAdClicked()

                this@BannerAdHelper.invokeAdListener { adCallback: AdCallback ->
                    adCallback.onAdClicked()
                    Unit
                }
            }

            // com.ads.control.funtion.AdCallback
            override fun onAdClosed() {
                super.onAdClosed()

                this@BannerAdHelper.invokeAdListener { adCallback: AdCallback ->
                    adCallback.onAdClosed()
                    Unit
                }
            }

            // com.ads.control.funtion.AdCallback
            override fun onAdFailedToLoad(loadAdError: LoadAdError?) {
                super.onAdFailedToLoad(loadAdError)
                this@BannerAdHelper.invokeAdListener { adCallback: AdCallback ->
                    adCallback.onAdFailedToLoad(loadAdError)
                    Unit
                }
            }

            // com.ads.control.funtion.AdCallback
            override fun onAdFailedToShow(adError: AdError?) {
                super.onAdFailedToShow(adError)
                this@BannerAdHelper.invokeAdListener { adCallback: AdCallback ->
                    adCallback.onAdFailedToShow(adError)
                    Unit
                }
            }

            override fun onAdImpression() {
                super.onAdImpression()
                this@BannerAdHelper.invokeAdListener { adCallback: AdCallback ->
                    adCallback.onAdImpression()
                    Unit
                }
            }

            override fun onAdLeftApplication() {
                super.onAdLeftApplication()
                this@BannerAdHelper.invokeAdListener { adCallback: AdCallback ->
                    adCallback.onAdLeftApplication()
                    Unit
                }
            }

            // com.ads.control.funtion.AdCallback
            override fun onAdLoaded() {
                super.onAdLoaded()

                this@BannerAdHelper.invokeAdListener { adCallback: AdCallback ->
                    adCallback.onAdLoaded()
                    Unit
                }
            }

            override fun onAdSplashReady() {
                super.onAdSplashReady()

                this@BannerAdHelper.invokeAdListener { adCallback: AdCallback ->
                    adCallback.onAdSplashReady()
                    Unit
                }
            }

            override fun onBannerLoaded(viewGroup: ViewGroup?) {
                super.onBannerLoaded(viewGroup)
                this@BannerAdHelper.invokeAdListener { adCallback: AdCallback ->
                    adCallback.onBannerLoaded(viewGroup)
                    Unit
                }
            }

            override fun onInterstitialLoad(interstitialAd: InterstitialAd?) {
                super.onInterstitialLoad(interstitialAd)
                this@BannerAdHelper.invokeAdListener { adCallback: AdCallback ->
                    adCallback.onInterstitialLoad(interstitialAd)
                    Unit
                }
            }

            override fun onInterstitialShow() {
                super.onInterstitialShow()

                this@BannerAdHelper.invokeAdListener { adCallback: AdCallback ->
                    adCallback.onInterstitialShow()
                    Unit
                }
            }

            override fun onNextAction() {
                super.onNextAction()

                this@BannerAdHelper.invokeAdListener { adCallback: AdCallback ->
                    adCallback.onNextAction()
                    Unit
                }
            }

            // com.ads.control.funtion.AdCallback
            override fun onRewardAdLoaded(rewardedAd: RewardedAd) {
                super.onRewardAdLoaded(rewardedAd)

                this@BannerAdHelper.invokeAdListener { adCallback: AdCallback ->
                    adCallback.onRewardAdLoaded(rewardedAd)
                    Unit
                }
            }

            override fun onUnifiedNativeAdLoaded(unifiedNativeAd: NativeAd) {
                super.onUnifiedNativeAdLoaded(unifiedNativeAd)
                this@BannerAdHelper.invokeAdListener { adCallback: AdCallback ->
                    adCallback.onUnifiedNativeAdLoaded(unifiedNativeAd)
                    Unit
                }
            }

            override fun onRewardAdLoaded(rewardedInterstitialAd: RewardedInterstitialAd) {
                super.onRewardAdLoaded(rewardedInterstitialAd)
                this@BannerAdHelper.invokeAdListener { adCallback: AdCallback ->
                    adCallback.onRewardAdLoaded(rewardedInterstitialAd)
                    Unit
                }
            }
        }
    }

    fun loadBannerAd() {
        if (canRequestAds()) {
            val mutableStateFlow: MutableStateFlow<AdBannerState> = this.adBannerState
            do {
            } while (!mutableStateFlow.compareAndSet(
                    mutableStateFlow.value,
                    AdBannerState.Loading
                )
            )
            RNAd.getInstance().requestLoadBanner(
                this.activity,
                config.getIdAds(), bannerAdConfig.getCollapsibleGravity(),
                config.getSize(), invokeListenerAdCallback()
            )
        }
    }

    fun registerAdListener(adCallback: AdCallback) {
        listAdCallback.add(adCallback)
    }


    //    public final void requestAutoReloadAd() {
    //        if (!adBannerState.getValue().equals(AdBannerState.Loading.INSTANCE) && canReloadAd() && config.getEnableAutoReload()) {
    //            logZ("requestAutoReloadAd setup");
    //
    //            // Cancel the existing job if it's active
    //            if (job != null) {
    //                job.cancel(null);
    //            }
    //
    //            // Launch a new coroutine for auto-reloading the ad
    //            job = LifecycleOwnerKt.getLifecycleScope(lifecycleOwner).launch(null, null, (coroutineScope, continuation) -> {
    //                try {
    //                    reloadAd();
    //                } catch (Exception e) {
    //                    logZ("Error during ad reload: " + e.getMessage());
    //                }
    //                return Unit.INSTANCE;
    //            });
    //
    //            // Start the job if it's not null
    //            if (job != null) {
    //                job.start();
    //            }
    //        }
    //    }
    fun requestAutoReloadAd() {
        if (adBannerState.value != AdBannerState.Loading && canReloadAd() && config.enableAutoReload) {
            logZ("requestAutoReloadAd setup")
            try {
                job?.cancel()
            } catch (th: Throwable) {
                // Handle any exception if necessary
            }

            job = lifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
                val autoReloadTime = config.autoReloadTime
                delay(autoReloadTime)

                logZ("requestAutoReloadAd")
                requestAds(BannerAdParam.Reload)
            }

            job?.start()
        }
    }



    fun setBannerAdView(viewGroup: ViewGroup?) {
        this.bannerAdView = viewGroup
    }

    fun setBannerContentView(nativeContentView: FrameLayout): BannerAdHelper {
        try {
            this.bannerContentView = nativeContentView
            this.shimmerLayoutView = nativeContentView.findViewById<ShimmerFrameLayout>(R.id.shimmer_container_banner)

            val currentState = lifecycleOwner.lifecycle.currentState
            val stateCreated = Lifecycle.State.CREATED
            val stateResumed = Lifecycle.State.RESUMED

            if (currentState >= stateCreated && currentState <= stateResumed) {
                if (!canRequestAds()) {
                    nativeContentView.visibility = View.GONE
                    shimmerLayoutView?.visibility = View.GONE
                }

                bannerAdView?.let { viewGroup ->
                    if (canShowAds()) {
                        showAd(nativeContentView, viewGroup)
                    }
                }
            }
        } catch (th: Throwable) {
            // Handle exceptions
        }
        return this
    }

    fun setShimmerLayoutView(shimmerLayoutView: ShimmerFrameLayout): BannerAdHelper {
        try {
            this.shimmerLayoutView = shimmerLayoutView

            val currentState = lifecycleOwner.lifecycle.currentState
            val stateCreated = Lifecycle.State.CREATED
            val stateResumed = Lifecycle.State.RESUMED

            if (currentState >= stateCreated && currentState <= stateResumed && !canRequestAds()) {
                shimmerLayoutView.visibility = View.GONE
            }
        } catch (th: Throwable) {
            // Handle exceptions
        }
        return this
    }


//    fun setBannerContentView(nativeContentView: FrameLayout): BannerAdHelper {
//        try {
//            this.bannerContentView = nativeContentView
//            this.shimmerLayoutView =
//                nativeContentView.findViewById<View>(R.id.shimmer_container_banner) as ShimmerFrameLayout
//            val state = Lifecycle.State.CREATED
//            val state2 = Lifecycle.State.RESUMED
//            val currentState: Lifecycle.State =
//                lifecycleOwner.getLifecycle().getCurrentState()
//            if (currentState.compareTo(state) >= 0 && currentState.compareTo(state2) <= 0) {
//                if (!canRequestAds()) {
//                    nativeContentView.setVisibility(View.GONE)
//                    val shimmerFrameLayout: ShimmerFrameLayout? = this.shimmerLayoutView
//                    if (shimmerFrameLayout != null) {
//                        shimmerFrameLayout.setVisibility(View.GONE)
//                    }
//                }
//                val viewGroup: ViewGroup? = this.bannerAdView
//                if (canShowAds() && viewGroup != null) {
//                    showAd(nativeContentView, viewGroup)
//                }
//            }
//        } catch (th: Throwable) {
//        }
//        return this
//    }
//
//    fun setShimmerLayoutView(shimmerLayoutView: ShimmerFrameLayout): BannerAdHelper {
//        try {
//            this.shimmerLayoutView = shimmerLayoutView
//            val state = Lifecycle.State.CREATED
//            val state2 = Lifecycle.State.RESUMED
//            val currentState: Lifecycle.State =
//                lifecycleOwner.getLifecycle().getCurrentState()
//            if ((currentState.compareTo(state) >= 0 && currentState.compareTo(state2) <= 0) && !canRequestAds()) {
//                shimmerLayoutView.setVisibility(View.GONE)
//            }
//        } catch (th: Throwable) {
//        }
//        return this
//    }

    fun unregisterAdListener(adCallback: AdCallback) {
        listAdCallback.remove(adCallback)
    }

    fun unregisterAllAdListener() {
        listAdCallback.clear()
    }

    override fun requestAds(param: BannerAdParam) {
        logZ("requestAds with param: ${param::class.simpleName}")
        if (canRequestAds()) {
            lifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
                when (param) {
                    is BannerAdParam.Request -> {
                        getFlagActive().compareAndSet(false, true)
                        loadBannerAd()
                    }
                    is BannerAdParam.Ready -> {
                        getFlagActive().compareAndSet(false, true)
                        setBannerAdView(param.bannerAds)
                        val adBannerState = getAdBannerState()
                        val loaded = AdBannerState.Loaded(param.bannerAds)
                        adBannerState.emit(loaded)
                    }
                    is BannerAdParam.Clickable -> {
                        if (isActiveState() && canRequestAds() && canReloadAd() &&
                            getAdBannerState().value != AdBannerState.Loading
                        ) {
                            if (timeShowAdImpression + param.minimumTimeKeepAdsDisplay < System.currentTimeMillis()) {
                                loadBannerAd()
                            }
                        } else {
                            logInterruptExecute("requestAds Clickable")
                        }
                    }
                    is BannerAdParam.Reload -> {
                        getFlagActive().compareAndSet(false, true)
                        loadBannerAd()
                    }
                }
            }
        } else if (isOnline() || bannerAdView != null) {
            // Optional: Handle this case
        } else {
            cancel()
        }
    }

}