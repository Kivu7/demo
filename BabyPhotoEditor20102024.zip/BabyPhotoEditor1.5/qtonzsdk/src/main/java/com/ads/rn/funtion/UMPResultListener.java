package com.ads.rn.funtion;

public interface UMPResultListener {
    void onCheckUMPSuccess(boolean var1);
}