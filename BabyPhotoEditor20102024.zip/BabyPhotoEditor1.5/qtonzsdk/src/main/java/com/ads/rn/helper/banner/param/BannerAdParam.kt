package com.ads.rn.helper.banner.param

import com.facebook.ads.AdView

sealed class BannerAdParam : IAdsParam {

    //    data class Clickable(val minimumTimeKeepAdsDisplay: Long) : BannerAdParam() {
//        fun copy(minimumTimeKeepAdsDisplay: Long = this.minimumTimeKeepAdsDisplay): Clickable {
//            return Clickable(minimumTimeKeepAdsDisplay)
//        }
//    }
////
//    data class Ready(val bannerAds: AdView) : BannerAdParam() {
//        fun copy(bannerAds: AdView = this.bannerAds): Ready {
//            return Ready(bannerAds)
//        }
//
//    }
    data class Clickable(val minimumTimeKeepAdsDisplay: Long) : BannerAdParam()

    data class Ready(val bannerAds: AdView) : BannerAdParam()

    object Reload : BannerAdParam() {
        @JvmStatic
        fun create(): Reload = Reload
    }

    object Request : BannerAdParam() {
        @JvmStatic
        fun create(): Request = Request
    }
}
