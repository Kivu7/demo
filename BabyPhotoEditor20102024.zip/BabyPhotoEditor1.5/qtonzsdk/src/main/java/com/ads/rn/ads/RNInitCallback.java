package com.ads.rn.ads;

public interface RNInitCallback {
    void initAdSuccess();
}
