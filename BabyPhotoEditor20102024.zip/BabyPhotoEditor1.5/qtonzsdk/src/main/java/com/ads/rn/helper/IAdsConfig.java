package com.ads.rn.helper;


public interface IAdsConfig {
    boolean getCanReloadAds();

    boolean getCanShowAds();

    String getIdAds();
}