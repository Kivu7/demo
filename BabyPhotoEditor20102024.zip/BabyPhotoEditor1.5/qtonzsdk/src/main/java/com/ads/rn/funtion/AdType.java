package com.ads.rn.funtion;

public enum AdType {
    BANNER,
    INTERSTITIAL,
    NATIVE,
    REWARDED,
    APP_OPEN
}
