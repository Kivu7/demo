package com.ads.rn.funtion;

public interface BillingListener {
    void onInitBillingFinished(int resultCode);
}
