package com.ads.rn.helper.banner.param

import android.view.ViewGroup

sealed class AdBannerState {

    object Cancel : AdBannerState()

    object Fail : AdBannerState()

    data class Loaded(val adBanner: ViewGroup) : AdBannerState() {
//        fun copy(adBanner: ViewGroup = this.adBanner): Loaded {
//            return Loaded(adBanner)
//        }
    }

    object Loading : AdBannerState()

    object None : AdBannerState()

}
