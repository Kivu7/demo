package com.ads.rn.funtion;

public interface UpdatePurchaseListener {
    void onUpdateFinished();
}
