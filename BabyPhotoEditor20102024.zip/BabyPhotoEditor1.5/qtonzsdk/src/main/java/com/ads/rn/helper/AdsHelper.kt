import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.util.Log
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.OnLifecycleEvent
import com.ads.rn.billing.AppPurchase
import com.ads.rn.helper.banner.BannerAdConfig
import com.ads.rn.helper.banner.param.IAdsParam
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.concurrent.atomic.AtomicBoolean

abstract class AdsHelper<C : BannerAdConfig, P : IAdsParam>(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner,
    private val config: C
) : LifecycleObserver {

    private val flagActive = AtomicBoolean(false)
    private var flagUserEnableReload = true
    private val lifecycleEventState = MutableStateFlow<Lifecycle.Event?>(null)
    private var tag: String = context.javaClass.simpleName

    init {
        lifecycleOwner.lifecycle.addObserver(this)
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
    fun onDestroy() {
        lifecycleOwner.lifecycle.removeObserver(this)
    }

    fun canReloadAd(): Boolean {
        return config.canReloadAds && flagUserEnableReload
    }

    fun canRequestAds(): Boolean {
        return canShowAds() && isOnline()
    }

    fun canShowAds(): Boolean {
        return !AppPurchase.getInstance().isPurchased() && config.canShowAds
    }

    abstract fun cancel()

    fun isActiveState(): Boolean {
        return flagActive.get()
    }

    fun isOnline(): Boolean {
        return try {
            val connectivityManager =
                context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val networkInfo: NetworkInfo? = connectivityManager.activeNetworkInfo
            networkInfo != null && networkInfo.isConnected
        } catch (e: Exception) {
            false
        }
    }

    fun logInterruptExecute(message: String) {
        logZ("$message not execute because has called cancel()")
    }

    fun logZ(message: String) {
        Log.d(this::class.java.simpleName, "$tag: $message")
    }

    abstract fun requestAds(param: P)

    fun setFlagUserEnableReload(enable: Boolean) {
        flagUserEnableReload = enable
        logZ("setFlagUserEnableReload($flagUserEnableReload)")
    }

    fun setTagForDebug(tag: String) {
        this.tag = tag
    }

    fun getFlagActive(): AtomicBoolean {
        return flagActive
    }

    fun getFlagUserEnableReload(): Boolean {
        return flagUserEnableReload
    }

    fun getLifecycleEventState(): MutableStateFlow<Lifecycle.Event?> {
        return lifecycleEventState
    }
}
