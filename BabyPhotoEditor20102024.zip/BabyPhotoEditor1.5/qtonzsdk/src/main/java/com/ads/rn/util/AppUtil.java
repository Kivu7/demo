package com.ads.rn.util;

public class AppUtil {
    public static Boolean VARIANT_DEV = true;
    public static float currentTotalRevenue001Ad;
}
