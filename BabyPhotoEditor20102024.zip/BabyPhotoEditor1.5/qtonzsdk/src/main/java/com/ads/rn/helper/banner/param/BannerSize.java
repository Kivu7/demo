package com.ads.rn.helper.banner.param;


public enum BannerSize {
    ADAPTIVE,
    LARGE_BANNER,
    MEDIUM_RECTANGLE,
    FULL_BANNER,
    LEADERBOARD
}