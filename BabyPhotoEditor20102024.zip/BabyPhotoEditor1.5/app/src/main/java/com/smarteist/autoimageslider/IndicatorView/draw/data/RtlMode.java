package com.smarteist.autoimageslider.IndicatorView.draw.data;

public enum RtlMode {On, Off, Auto}