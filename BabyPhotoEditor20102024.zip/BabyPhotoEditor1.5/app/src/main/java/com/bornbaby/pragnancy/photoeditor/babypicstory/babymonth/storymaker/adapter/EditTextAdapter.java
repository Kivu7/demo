package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.adapter;

import android.app.Activity;
import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.R;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.EditText;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.view.CircleImageview;

public class EditTextAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    Activity mActivity;
    onEditTextClick mOnEditTextClick;
    EditText modelList;
    public int type;

    public interface onEditTextClick {
        void onEditTextClick(Object obj, int i);
    }

    public EditTextAdapter(EditText editText, Activity activity, onEditTextClick onedittextclick, int i) {
        this.type = i;
        this.modelList = editText;
        this.mActivity = activity;
        this.mOnEditTextClick = onedittextclick;
    }

    @NonNull
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        LayoutInflater from = LayoutInflater.from(viewGroup.getContext());
        if (this.type == 1) {
            return new ViewHolder(from.inflate(R.layout.single_color_thumb, null));
        }
        return new textViewHolder(from.inflate(R.layout.fontfamily_item, null));
    }

    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder viewHolder, int i) {
        if (this.type == 1) {
            ViewHolder viewHolder2 = (ViewHolder) viewHolder;
            viewHolder2.mCircleImageView.setImageResource(this.modelList.getColorList().get(viewHolder.getAdapterPosition()).intValue());
            viewHolder2.mCircleImageView.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    EditTextAdapter.this.mOnEditTextClick.onEditTextClick(EditTextAdapter.this.modelList.getColorList().get(viewHolder.getAdapterPosition()), 1);
                }
            });
            return;
        }
        AssetManager assets = this.mActivity.getAssets();
        Typeface createFromAsset = Typeface.createFromAsset(assets, "fonts/" + this.modelList.getFontList().get(viewHolder.getAdapterPosition()) + ".ttf");
        textViewHolder textviewholder = (textViewHolder) viewHolder;
        textviewholder.mTextView.setTypeface(createFromAsset);
        textviewholder.mTextView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                EditTextAdapter.this.mOnEditTextClick.onEditTextClick(EditTextAdapter.this.modelList.getFontList().get(viewHolder.getAdapterPosition()), 2);
            }
        });
    }

    public int getItemCount() {
        if (this.type == 1) {
            return this.modelList.getColorList().size();
        }
        return this.modelList.getFontList().size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        CircleImageview mCircleImageView;

        public ViewHolder(View view) {
            super(view);
            this.mCircleImageView = view.findViewById(R.id.colorImg);
        }
    }

    public static class textViewHolder extends RecyclerView.ViewHolder {
        TextView mTextView;

        public textViewHolder(View view) {
            super(view);
            this.mTextView = view.findViewById(R.id.textView);
        }
    }

    public int getItemViewType(int i) {
        return this.type;
    }

    public void set(int i) {
        this.type = i;
        notifyDataSetChanged();
    }
}
