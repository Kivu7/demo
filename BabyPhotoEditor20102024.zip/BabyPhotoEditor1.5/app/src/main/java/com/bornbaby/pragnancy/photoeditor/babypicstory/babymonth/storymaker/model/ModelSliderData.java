package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model;

public class ModelSliderData {
    private String Id;

    public ModelSliderData(String  Id) {
        this.Id = Id;
    }

    public String getImgUrl() {
        return Id;
    }

    public void setImgUrl(String Id) {
        this.Id = Id;
    }
}
