package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.TemplateJason;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import java.io.Serializable;

public class DynamicLayout implements Serializable {
    @SerializedName("horizontal_alignment")
    @Expose
    private String horizontalAlignment;
    @SerializedName("overflow")
    @Expose
    private String overflow;
    @SerializedName("sticker_alphabet")
    @Expose
    private Double stickerAlphabet;
    @SerializedName("text_value")
    @Expose
    private String textValue;

    public String getTextValue() {
        return this.textValue;
    }

    public void setTextValue(String str) {
        this.textValue = str;
    }

    public Double getStickerAlphabet() {
        return this.stickerAlphabet;
    }

    public void setStickerAlphabet(Double d) {
        this.stickerAlphabet = d;
    }

    public String getHorizontalAlignment() {
        return this.horizontalAlignment;
    }

    public void setHorizontalAlignment(String str) {
        this.horizontalAlignment = str;
    }

    public String getOverflow() {
        return this.overflow;
    }

    public void setOverflow(String str) {
        this.overflow = str;
    }
}
