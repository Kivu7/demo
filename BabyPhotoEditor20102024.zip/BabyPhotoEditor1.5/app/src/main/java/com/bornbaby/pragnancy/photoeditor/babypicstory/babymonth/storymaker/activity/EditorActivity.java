package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.activity;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.Xfermode;
import android.graphics.drawable.Drawable;
import android.media.ExifInterface;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatSeekBar;
import androidx.constraintlayout.solver.widgets.analyzer.BasicMeasure;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ads.rn.ads.RNAd;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.R;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.adapter.EditTextAdapter;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.adapter.LayerAdapter;


import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.application.MyApplication;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.EditText;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.SelectedImage;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.TemplateJason.RootTemplate;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.TemplateJason.TempleteLayer;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.UndoViews;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.ViewModel;


import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.myAds.AdSDKPref;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.touchListeners.MultiTouchListener;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.CommonUtils;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.Constant;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.Constants;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.CustomDialog;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.DynamicUnitUtils;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.FileUtils;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.view.BubbleTextView;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.view.StickerView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.target.Target;
import com.bumptech.glide.request.transition.Transition;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.gauravk.bubblenavigation.BubbleNavigationLinearView;
import com.gauravk.bubblenavigation.listener.BubbleNavigationChangeListener;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.material.imageview.ShapeableImageView;
import com.google.android.material.shape.ShapeAppearanceModel;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class EditorActivity extends AppCompatActivity {

    private static final String TAG = "Edit";
    public static Bitmap cutOuts;
    public static Bitmap originalImgs;
    public float actualHeight;
    public float actualWidth;

    public FrameLayout adFrame;
    private LinearLayout addBackground;
    private LinearLayout addCutout;
    private LinearLayout addStickerBtn;
    private LinearLayout addTextSticker;

    public ImageView backgroundImg;
    private Bitmap[] bitmap;
    private LinearLayout bottomLinear;
    private ImageView btnBack;

    public BubbleNavigationLinearView bubbleNavigation;
    private ArrayList<Integer> colorList = new ArrayList<>();
    private RelativeLayout colorThumbForText;

    public RelativeLayout container;

    public CustomDialog customDialogForCamera;
    private final View[] cutoutView = new View[1];

    public DisplayMetrics displayMetrics;
    private ImageView downloadBtn;
    private RelativeLayout editThumbForText;
    private LinearLayout fontFamilyThumbForText;
    private ArrayList<String> fontStyleList = new ArrayList<>();
    private float heightForShadowChild = 0.0f;
    private RelativeLayout innerContainer;

    public boolean isAnimatedLayer = true;
    public Boolean isCutoutLoaded = false;
    public boolean isForFront = false;

    public ImageView layer_ic;

    public LinearLayout letterSpacing;

    public AppCompatSeekBar letterSpacingSeekBar;
    private LinearLayout letterSpacingThumbForText;

    public LinearLayout lineSpacingForText;

    public AppCompatSeekBar lineSpacingSeekBarForText;
    private LinearLayout lineSpacingThumbForText;
    private LinearLayout linearLayout;

    public CustomDialog loading;
    private ViewGroup.LayoutParams lp;

    public BubbleTextView mCurrentEditTextView;

    public StickerView mCurrentView;

    public EditTextAdapter mEditTextAdapter;

    public LayerAdapter mLayerAdapter;

    public RecyclerView mRecyclerView;

    public AppCompatSeekBar mSeekBar;

    public AppCompatSeekBar mSeekBarForText;
    ItemTouchHelper.SimpleCallback mSimpleCallback = new ItemTouchHelper.SimpleCallback(51, 0) {
        public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        }

        public boolean onMove(@NonNull RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder viewHolder2) {
            View view;
            int adapterPosition = viewHolder.getAdapterPosition();
            int adapterPosition2 = viewHolder2.getAdapterPosition();
            Collections.swap(mViewModels, adapterPosition, adapterPosition2);
            int i = 0;
            while (true) {
                if (i >= rootStickers.getChildCount()) {
                    view = null;
                    break;
                } else if (rootStickers.getChildAt(i) == ((ViewModel) mViewModels.get(adapterPosition)).getView()) {
                    view = rootStickers.getChildAt(i);
                    break;
                } else {
                    i++;
                }
            }
            int i2 = 0;
            for (int i3 = 0; i3 < rootStickers.getChildCount(); i3++) {
                if (rootStickers.getChildAt(i3) == mViewModels.get(adapterPosition2).getView()) {
                    i2 = i3;
                }
            }
            rootStickers.removeView(view);
            rootStickers.addView(view, i2);
            recyclerView.getAdapter().notifyItemMoved(adapterPosition, adapterPosition2);
            return false;
        }

        public boolean canDropOver(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder viewHolder2) {
            return super.canDropOver(recyclerView, viewHolder, viewHolder2);
        }
    };

    public ArrayList<UndoViews> mUndoViews = new ArrayList<>();

    public ArrayList<ViewModel> mViewModels = new ArrayList<>();

    public ArrayList<View> mViews;
    private float maxFitMargin;
    private LayerAdapter.onClick onClick;

    public LinearLayout opacity;

    public LinearLayout opacityForText;

    public LinearLayout opacityThumbForSticker;
    private RelativeLayout opacityThumbForText;


    public RecyclerView recycleEditText;
    public ImageView rootFrame;
    private RelativeLayout rootImages;

    public RelativeLayout rootStickers;
    private RootTemplate rootTemplate;
    private CustomDialog saveLoader;

    public View secondDivider;
    private SelectedImage selectedImg;

    public ImageView shadowChild;
    private ShapeableImageView shadowImage;

    public ImageView shadowParent;
    private List<TempleteLayer> template_layers = new ArrayList();
    private TempleteLayer template_layers_obj;
    private ImageView undoBtn;
    private ImageView erase;

    public void sortList() {
    }

    public static void createActivity(Activity activity, ArrayList<String> arrayList, RootTemplate rootTemplate2, Bitmap bitmap2, Bitmap bitmap3) {
        cutOuts = bitmap2;
        originalImgs = bitmap3;
        Intent intent = new Intent(activity, EditorActivity.class);
        intent.putExtra("selectedImg", new SelectedImage(arrayList));
        intent.putExtra("rootTemplate", rootTemplate2);
        activity.startActivity(intent);
    }
    private void loadAdaptiveBaner() {
        FrameLayout ad_view_container = findViewById(R.id.bannerView);

        if (AdSDKPref.getInstance(this).getString(AdSDKPref.TAG_ALL_AD_OFF, "0").equals("off") || AdSDKPref.getInstance(this).getString(AdSDKPref.TAG_BANNER_HOME_ONOFF, "0").equals("off")) {
            ad_view_container.setVisibility(View.GONE);
        } else {
            ad_view_container.setVisibility(View.VISIBLE);
            RNAd.getInstance().loadBanner(this, getString(R.string.banner_home));
        }
    }

    public void onCreate(Bundle bundle) {

        super.onCreate(bundle);
        CommonUtils.updateLanguage(this);
        CustomDialog customDialog = new CustomDialog(this);
        this.customDialogForCamera = customDialog;
        customDialog.setMessage(getString(R.string.loading_));
        setContentView(R.layout.activity_edit);
        loadAdaptiveBaner();
        this.selectedImg = (SelectedImage) getIntent().getSerializableExtra("selectedImg");
        this.rootTemplate = (RootTemplate) getIntent().getSerializableExtra("rootTemplate");
        init();
        float dimension = getResources().getDimension(R.dimen._0sdp);
        this.adFrame.post(new Runnable() {


            public void run() {
                lambda$onCreate$3$EditorActivity(shadowImage.getShapeAppearanceModel().toBuilder().setTopLeftCorner(0, dimension).setTopRightCorner(0, dimension).build());
            }
        });
    }

    public void lambda$onCreate$3$EditorActivity(ShapeAppearanceModel shapeAppearanceModel) {
        this.shadowImage.setShapeAppearanceModel(shapeAppearanceModel);
        this.bubbleNavigation.setCurrentActiveItem(0);
        CustomDialog customDialog = new CustomDialog(this);
        this.saveLoader = customDialog;
        customDialog.setMessage(getString(R.string.please_wait_));
        CustomDialog customDialog2 = new CustomDialog(this);
        this.loading = customDialog2;
        customDialog2.show();
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage(getString(R.string.please_wait_));
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.setCancelable(false);
        ProgressDialog progressDialog2 = new ProgressDialog(this);
        progressDialog2.setMessage(getString(R.string.saving_));
        progressDialog2.setCanceledOnTouchOutside(false);
        progressDialog2.setCancelable(false);
        this.bottomLinear.getHeight();
        this.bubbleNavigation.getHeight();
        this.bottomLinear.post(new Runnable() {
            public final void run() {
                heightForShadowChild += (float) bottomLinear.getHeight();
            }
        });
        this.bubbleNavigation.post(new Runnable() {
            public final void run() {
                heightForShadowChild += (float) bubbleNavigation.getHeight();
            }
        });
        new Handler(Looper.myLooper()).postDelayed(new Runnable() {
            public final void run() {
                shadowChild.getLayoutParams().height = (int) (heightForShadowChild + 20.0f);
            }
        }, 2000);
        int actionBarHeight = (int) getTheme().obtainStyledAttributes(new int[]{16843499}).getDimension(0, 0.0f);
        int dimension = ((int) getResources().getDimension(R.dimen._40sdp)) + (actionBarHeight * 2) + this.adFrame.getHeight();
        this.displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(this.displayMetrics);
        if (this.rootTemplate.getType().equals("Wallpaper")) {
            double d = this.displayMetrics.heightPixels;
            double d2 = dimension;
            Double.isNaN(d2);
            Double.isNaN(d2);
            Double.isNaN(d);
            this.actualHeight = (float) (d - ((d2 * 0.25d) + d2));
        }
        double d3 = (double) this.displayMetrics.heightPixels;
        double d4 = (double) dimension;
        Double.isNaN(d4);
        Double.isNaN(d4);
        Double.isNaN(d3);
        this.maxFitMargin = (float) (d3 - ((0.25d * d4) + d4));
        this.mViews = new ArrayList<>();
        this.template_layers = this.rootTemplate.getTemplate_layers();
        initListener();
        initAdapter();
        this.lp = new ViewGroup.LayoutParams(-2, -2);
        this.rootFrame.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                setCurrentEditAtSave(mCurrentView);
                setCurrentEditAtSave(mCurrentEditTextView);
                bubbleNavigation.setVisibility(View.INVISIBLE);
                bubbleNavigation.setVisibility(View.INVISIBLE);
                mLayerAdapter.setSelected((View) null);
                return false;
            }
        });
        this.rootStickers.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {

                setCurrentEditAtSave(mCurrentView);

                setCurrentEditAtSave(mCurrentEditTextView);
                bubbleNavigation.setVisibility(View.INVISIBLE);
                mLayerAdapter.setSelected((View) null);
                opacity.setVisibility(View.INVISIBLE);
                letterSpacing.setVisibility(View.INVISIBLE);
                lineSpacingForText.setVisibility(View.INVISIBLE);
                shadowParent.setVisibility(View.GONE);
                shadowChild.setVisibility(View.INVISIBLE);
                return false;
            }
        });
        if (this.rootTemplate.getType().equals("Portrait") || this.rootTemplate.getType().equals("Wallpaper")) {
            setFrame();
        } else if (this.rootTemplate.getType().equals("Collage")) {
            setFrame();
        } else if (this.rootTemplate.getType().equals("Cutout")) {
            setBackground();
            this.rootFrame.setVisibility(View.GONE);
            this.rootImages.setVisibility(View.GONE);
        }
    }


    private void initListener() {
        this.addCutout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), SelectImageActivity.class);
                intent.putExtra("from", "EditCutout");
                intent.putExtra("forCrop", "yes");
                startActivityForResult(intent, 12);
            }
        });
        if (this.rootTemplate.getType().equals("Cutout")) {
            this.rootStickers.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {

                    setCurrentEditAtSave(mCurrentView);

                    setCurrentEditAtSave(mCurrentEditTextView);
                    bubbleNavigation.setVisibility(View.INVISIBLE);
                    mLayerAdapter.setSelected((View) null);
                    opacity.setVisibility(View.INVISIBLE);
                }
            });
        }
        this.onClick = new LayerAdapter.onClick() {
            public void onClick(int i, int i2) {
                if (i2 == 1) {
                    if (mViewModels.get(i).isVisible()) {
                        int i3 = 0;
                        while (true) {
                            if (i3 >= rootStickers.getChildCount()) {
                                break;
                            } else if (rootStickers.getChildAt(i3) == ((ViewModel) mViewModels.get(i)).getView()) {
                                rootStickers.getChildAt(i3).setVisibility(View.INVISIBLE);
                                break;
                            } else {
                                i3++;
                            }
                        }
                        mViewModels.get(i).setVisible(false);
                        return;
                    }
                    int i4 = 0;
                    while (true) {
                        if (i4 >= rootStickers.getChildCount()) {
                            break;
                        } else if (rootStickers.getChildAt(i4) == ((ViewModel) mViewModels.get(i)).getView()) {
                            rootStickers.getChildAt(i4).setVisibility(View.VISIBLE);
                            break;
                        } else {
                            i4++;
                        }
                    }
                    mViewModels.get(i).setVisible(true);
                } else if (mViewModels.get(i).isClickable()) {
                    if (mViewModels.get(i).getView() instanceof StickerView) {
                        ((StickerView) mViewModels.get(i).getView()).setStickerClickable(false);
                    } else if (mViewModels.get(i).getView() instanceof BubbleTextView) {
                        ((BubbleTextView) mViewModels.get(i).getView()).setTextStickerClickable(false);
                    }
                    mViewModels.get(i).setClickable(false);
                } else {
                    if (mViewModels.get(i).getView() instanceof StickerView) {
                        ((StickerView) mViewModels.get(i).getView()).setStickerClickable(true);
                    } else if (mViewModels.get(i).getView() instanceof BubbleTextView) {
                        ((BubbleTextView) mViewModels.get(i).getView()).setTextStickerClickable(true);
                    }
                    mViewModels.get(i).setClickable(true);
                }
            }
        };
        this.addBackground.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                showAddImageDialog();
            }
        });
        this.mSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                float f = ((float) progress) / 100.0f;
                if (mCurrentView != null) {
                    mCurrentView.setAlpha(f);
                } else if (mCurrentEditTextView != null) {
                    mCurrentEditTextView.setAlpha(f);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }


        });
        this.mSeekBarForText.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                float f = ((float) progress) / 100.0f;
                if (mCurrentEditTextView != null) {
                    mCurrentEditTextView.setAlpha(f);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }


        });
        this.opacityThumbForText.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                setVisibility(opacityForText);
                setViewInvisible(letterSpacing);
                setViewInvisible(recycleEditText);
                setViewInvisible(lineSpacingForText);
            }
        });
        this.letterSpacingThumbForText.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                setVisibility(letterSpacing);

                setViewInvisible(opacityForText);

                setViewInvisible(recycleEditText);

                setViewInvisible(lineSpacingForText);
            }
        });
        this.letterSpacingSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int i = progress;
                if (mCurrentEditTextView != null) {
                    mCurrentEditTextView.setLetterSpacing((float) i);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }


        });
        this.lineSpacingSeekBarForText.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int i = progress;
                if (mCurrentEditTextView != null) {
                    mCurrentEditTextView.setLineSpacing((float) (i / 3));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }


        });
        this.addTextSticker.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                showEditTextDialog(true);
            }
        });
        setVisibilityMainEditList((View) null);
        this.addStickerBtn.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                startActivityForResult(new Intent(getApplicationContext(), StickerActivity.class), 2);
            }
        });
        this.colorThumbForText.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                mEditTextAdapter.set(1);
                if (recycleEditText.getVisibility() == 4) {
                    setVisibility(recycleEditText);
                }
                setViewInvisible(opacityForText);
                setViewInvisible(letterSpacing);
                setViewInvisible(lineSpacingForText);
            }
        });
        this.fontFamilyThumbForText.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                mEditTextAdapter.set(2);
                if (recycleEditText.getVisibility() == 4) {
                    setVisibility(recycleEditText);
                }
                setViewInvisible(opacityForText);
                setViewInvisible(letterSpacing);
                setViewInvisible(lineSpacingForText);
            }
        });
        this.editThumbForText.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                setViewInvisible(letterSpacing);

                setViewInvisible(opacityForText);

                setViewInvisible(recycleEditText);

                setViewInvisible(lineSpacingForText);
                showEditTextDialog(false);
            }
        });
        this.lineSpacingThumbForText.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                setVisibility(lineSpacingForText);

                setViewInvisible(letterSpacing);

                setViewInvisible(opacityForText);

                setViewInvisible(recycleEditText);
            }
        });
        this.undoBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (!mUndoViews.isEmpty()) {
                    int size = mUndoViews.size() - 1;
                    UndoViews undoViews = mUndoViews.get(size);
                    if (undoViews.getViewModel().getView() instanceof StickerView) {
                        addStickerViewAtPosition(undoViews.getViewModel().getBitmap(), undoViews.getHeight(), undoViews.getWidth(), undoViews.getX(), undoViews.getY(), undoViews.getRotation(), undoViews.getPosition());
                    } else {
                        addBubble(undoViews.getX(), undoViews.getY(), undoViews.getHeight(), undoViews.getWidth(), undoViews.getRotation(), "Enter Text", 0.1f);
                    }
                    mUndoViews.remove(size);
                }
            }
        });
        this.erase.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                EraserBgActivity.f4458b = Constant.Cutout_portrait;
                Intent intent = new Intent(EditorActivity.this, EraserBgActivity.class);
                intent.putExtra(Constants.KEY_OPEN_FROM, Constants.VALUE_OPEN_FROM_REMOVE_BG);
                startActivityForResult(intent, 12);
            }
        });
        this.downloadBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                showSaveImageDialog();
            }
        });
        this.btnBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                showBackHomeDialog();
            }
        });
        this.layer_ic.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (isAnimatedLayer) {
                    boolean unused = isAnimatedLayer = false;
                    mRecyclerView.setVisibility(View.VISIBLE);
                    layer_ic.animate().translationX(0.0f).setDuration(300);
                    mRecyclerView.animate().translationX(0.0f).setDuration(300).setListener(new AnimatorListenerAdapter() {
                        public void onAnimationEnd(Animator animator) {
                            super.onAnimationEnd(animator);
                        }
                    });
                    return;
                }
                isAnimatedLayer = true;
                layer_ic.animate().translationX((float) (-mRecyclerView.getWidth())).setDuration(300);
                mRecyclerView.animate().translationX((float) (-mRecyclerView.getWidth())).setDuration(300).setListener(new AnimatorListenerAdapter() {
                    public void onAnimationEnd(Animator animator) {
                        super.onAnimationEnd(animator);
                    }
                });
            }
        });
        this.bubbleNavigation.setNavigationChangeListener(new BubbleNavigationChangeListener() {
            public void onNavigationChanged(View view, int i) {
                if (i == 0) {

                    setVisibility(opacityForText);

                    setViewInvisible(letterSpacing);

                    setViewInvisible(recycleEditText);

                    setViewInvisible(lineSpacingForText);
                } else if (i == 1) {
                    mEditTextAdapter.set(1);
                    if (recycleEditText.getVisibility() == 4) {

                        setVisibility(recycleEditText);
                    }

                    setViewInvisible(opacityForText);

                    setViewInvisible(letterSpacing);

                    setViewInvisible(lineSpacingForText);
                } else if (i == 2) {
                    mEditTextAdapter.set(2);
                    if (recycleEditText.getVisibility() == 4) {

                        setVisibility(recycleEditText);
                    }

                    setViewInvisible(opacityForText);

                    setViewInvisible(letterSpacing);

                    setViewInvisible(lineSpacingForText);
                } else if (i == 3) {
                    setVisibility(letterSpacing);
                    setViewInvisible(opacityForText);
                    setViewInvisible(recycleEditText);
                    setViewInvisible(lineSpacingForText);
                } else if (i == 4) {
                    setVisibility(lineSpacingForText);
                    setViewInvisible(letterSpacing);
                    setViewInvisible(opacityForText);
                    setViewInvisible(recycleEditText);
                }
            }
        });
        this.opacityThumbForSticker.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (opacity.getVisibility() == 4) {
                    shadowParent.setVisibility(View.GONE);
                    shadowChild.setVisibility(View.VISIBLE);
                    opacity.setVisibility(View.VISIBLE);
                    return;
                }
                opacity.setVisibility(View.INVISIBLE);
                shadowChild.setVisibility(View.INVISIBLE);
            }
        });
    }


    public void setVisibility(View view) {
        if (view.getVisibility() == 0) {
            view.setVisibility(View.INVISIBLE);
        } else {
            view.setVisibility(View.VISIBLE);
        }
    }


    public void saveImageAtStorage(Boolean bool) {
        String format = new SimpleDateFormat("yyyyMMddHHmmss", Locale.getDefault()).format(new Date());
        Bitmap viewToBitmap = viewToBitmap(this.innerContainer);
        saveImage(viewToBitmap, "img_" + format, bool);
    }

    private void initAdapter() {
        this.mRecyclerView.addItemDecoration(new DividerItemDecoration(this, 1));
        this.mLayerAdapter = new LayerAdapter(this, this.mViewModels, this.onClick);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(1);
        this.mRecyclerView.setLayoutManager(linearLayoutManager);
        this.mRecyclerView.setAdapter(this.mLayerAdapter);
        new ItemTouchHelper(this.mSimpleCallback).attachToRecyclerView(this.mRecyclerView);
        float f = -getResources().getDimension(R.dimen._112sdp);
        this.layer_ic.animate().translationX(f).setDuration(0);
        this.mRecyclerView.animate().translationX(f).setDuration(0).setListener(new AnimatorListenerAdapter() {
            public void onAnimationEnd(Animator animator) {
                super.onAnimationEnd(animator);
            }
        });
        this.colorList.add(R.color.aquamarine);
        this.colorList.add(R.color.beige);
        this.colorList.add(R.color.chartreuse);
        this.colorList.add(R.color.dark_blue);
        this.colorList.add(R.color.navajo_white);
        ArrayList<Integer> arrayList = this.colorList;
        Integer valueOf = R.color.thistle;
        arrayList.add(valueOf);
        ArrayList<Integer> arrayList2 = this.colorList;
        Integer valueOf2 = R.color.indian_red;
        arrayList2.add(valueOf2);
        colorList.add(R.color.black);
        colorList.add(valueOf);
        colorList.add(R.color.indigo);
        colorList.add(R.color.old_lace);
        colorList.add(R.color.bisque);
        colorList.add(R.color.slate_blue);
        colorList.add(R.color.cornflower_blue);
        colorList.add(R.color.burlyWood);
        colorList.add(R.color.pale_turquoise);
        colorList.add(R.color.dark_khaki);
        colorList.add(valueOf2);
        fontStyleList.add("Bangers-Regular");
        fontStyleList.add("roboto_regular");
        fontStyleList.add("roboto_boldItalic");
        fontStyleList.add("Pacifico-Regular");
        fontStyleList.add("Oi-Regular");
        fontStyleList.add("Fascinate-Regular");
        fontStyleList.add("DreamwoodDemoRegular-Zj3q");
        fontStyleList.add("NerkoOne-Regular");
        fontStyleList.add("Melon-nR2p1");
        fontStyleList.add("JotiOne-Regular");
        fontStyleList.add("Paprika-Regular");
        fontStyleList.add("QuartsPachinoDemoVersion-PK9Ex");
        fontStyleList.add("RockSalt-Regular");
        mEditTextAdapter = new EditTextAdapter(new EditText(this.colorList, this.fontStyleList), this, new EditTextAdapter.onEditTextClick() {
            public final void onEditTextClick(Object obj, int i) {
                lambda$initAdapter$9$EditorActivity(obj, i);
            }
        }, 1);
        LinearLayoutManager linearLayoutManager2 = new LinearLayoutManager(this);
        linearLayoutManager2.setOrientation(RecyclerView.HORIZONTAL);
        this.recycleEditText.setLayoutManager(linearLayoutManager2);
        this.recycleEditText.setAdapter(this.mEditTextAdapter);
    }

    public void lambda$initAdapter$9$EditorActivity(Object obj, int i) {
        BubbleTextView bubbleTextView = this.mCurrentEditTextView;
        if (bubbleTextView == null) {
            return;
        }
        if (i == 1) {
            this.mCurrentEditTextView.setColor(ContextCompat.getColor(this, ((Integer) obj).intValue()));
            return;
        }
        bubbleTextView.setFontFamily((String) obj);
    }

    private void load(int i, String str, float f, float f2, float f3, float f4, float f5, boolean z) {
        int i2 = i;
        if (str == null) {
            setCutoutImg(BitmapFactory.decodeResource(getResources(), R.drawable.baby), f, f2, f3, f4, f5, z);
        } else if (i2 == 1) {
            new Thread(new Runnable() {

                public void run() {
                    runOnUiThread(new Runnable() {

                        public void run() {
                            try {
                                backgroundImg.setImageBitmap(BitmapFactory.decodeStream(new URI(str).toURL().openConnection().getInputStream()));
                            } catch (IOException e) {
                                throw new RuntimeException(e);
                            } catch (URISyntaxException e) {
                                throw new RuntimeException(e);
                            }
                        }
                    });
                }
            }).start();
        } else if (i2 == 2) {
            new Thread(new Runnable() {

                public final void run() {
                    runOnUiThread(new Runnable() {


                        public final void run() {
                            try {
                                Glide.with(EditorActivity.this).asBitmap().load(str).into(new CustomTarget<Bitmap>() {
                                    @Override
                                    public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {

                                        setCutoutImg(resource, f, f2, f3, f4, f5, z);

                                    }

                                    @Override
                                    public void onLoadCleared(@Nullable Drawable placeholder) {
                                    }
                                });

                            } catch (Exception e) {

                            }
                        }
                    });
                }
            }).start();
        } else if (i2 == 3) {
            new Thread(new Runnable() {


                public final void run() {
                    runOnUiThread(new Runnable() {


                        public void run() {
                            try {

                                Glide.with(EditorActivity.this).asBitmap().load(str).into(new CustomTarget<Bitmap>() {
                                    @Override
                                    public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {

                                        setimagedata(new ImageView(EditorActivity.this), resource);


                                    }

                                    @Override
                                    public void onLoadCleared(@Nullable Drawable placeholder) {
                                    }
                                });


                            } catch (Exception e) {
                            }
                        }
                    });
                }
            }).start();
        }
    }


    public void setimagedata(ImageView imageView, Bitmap bitmap2) {
        imageView.setImageBitmap(bitmap2);
        imageView.setLayoutParams(this.lp);
    }


    public void setCutoutImg(Bitmap bitmap2, float f, float f2, float f3, float f4, float f5, boolean z) {
        Bitmap bitmap3;
        final StickerView stickerView = new StickerView(this);
        if (f == 0.0f && f2 == 0.0f) {
            double width = bitmap2.getWidth();
            Double.isNaN(width);
            double height = bitmap2.getHeight();
            Double.isNaN(height);
            bitmap3 = Bitmap.createScaledBitmap(bitmap2, (int) (width * 0.5d), (int) (height * 0.5d), true);
        } else {
            bitmap3 = Bitmap.createScaledBitmap(bitmap2, (int) f2, (int) f, true);
        }
        stickerView.setImageBitmap(bitmap3, f3, f4, f5);
        stickerView.setOperationListener(new StickerView.OperationListener() {
            public void onDeleteClick() {
                mViews.remove(stickerView);
                mLayerAdapter.notifyDataSetChanged();
                addViewToUndoList(stickerView);
                rootStickers.removeView(stickerView);
                removeViewFromModel(stickerView);
                setVisibilityMainEditList((View) null);
                opacityThumbForSticker.setVisibility(View.GONE);
                secondDivider.setVisibility(View.INVISIBLE);
            }

            public void onEdit(StickerView stickerView) {
                if (mViews.contains(stickerView)) {
                    if (mCurrentEditTextView != null) {
                        mCurrentEditTextView.setInEdit(false);
                    }
                    secondDivider.setVisibility(View.VISIBLE);
                    mCurrentView.setInEdit(false);
                    mCurrentView = stickerView;
                    mCurrentView.setInEdit(true);

                    setVisibilityMainEditList(mCurrentView);
                    opacityThumbForSticker.setVisibility(View.VISIBLE);
                    if (mCurrentView.getAlpha() != 0.0f) {
                        mSeekBar.setProgress((int) (mCurrentView.getAlpha() * 100.0f));
                    }
                    mLayerAdapter.setSelected(stickerView);
                    opacity.setVisibility(View.INVISIBLE);
                    shadowChild.setVisibility(View.INVISIBLE);
                    shadowParent.setVisibility(View.GONE);
                }
            }

            public void onTop(StickerView stickerView) {
                int indexOf = mViews.indexOf(stickerView);
                if (indexOf != mViews.size() - 1) {
                    mViews.add(mViews.size(), mViews.remove(indexOf));
                }
            }
        });
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, -1);
        setVisibilityMainEditList(null);
        if (!z) {
            this.rootStickers.addView(stickerView, layoutParams);
            this.mViews.add(stickerView);
            this.mViewModels.add(new ViewModel(stickerView, bitmap2));
        } else {
            this.rootStickers.addView(stickerView, 0, layoutParams);
            this.mViews.add(stickerView);
            this.cutoutView[0] = stickerView;
        }
        this.bubbleNavigation.setVisibility(View.INVISIBLE);
        sortList();
        this.mLayerAdapter.notifyDataSetChanged();
        this.mLayerAdapter.setSelected(stickerView);
        setCurrentEdit(stickerView);
    }


    public void addStickerViewAtPosition(Bitmap bitmap2, float f, float f2, float f3, float f4, float f5, int i) {
        final StickerView stickerView = new StickerView(this);
        stickerView.setImageBitmap(Bitmap.createScaledBitmap(bitmap2, (int) f2, (int) f, true), f3, f4, f5);
        stickerView.setOperationListener(new StickerView.OperationListener() {
            public void onDeleteClick() {
                mViews.remove(stickerView);
                mLayerAdapter.notifyDataSetChanged();
                addViewToUndoList(stickerView);
                rootStickers.removeView(stickerView);
                removeViewFromModel(stickerView);
            }

            public void onEdit(StickerView stickerView) {
                if (mCurrentEditTextView != null) {
                    mCurrentEditTextView.setInEdit(false);
                }
                mCurrentView.setInEdit(false);
                mCurrentView = stickerView;
                mCurrentView.setInEdit(true);
                mLayerAdapter.setSelected(stickerView);
            }

            public void onTop(StickerView stickerView) {
                int indexOf = mViews.indexOf(stickerView);
                if (indexOf != mViews.size() - 1) {
                    mViews.add(mViews.size(), mViews.remove(indexOf));
                }
            }
        });
        this.rootStickers.addView(stickerView, new RelativeLayout.LayoutParams(-1, -1));
        this.mViews.add(stickerView);
        this.mViewModels.add(new ViewModel(stickerView, bitmap2));
        sortList();
        this.mLayerAdapter.notifyDataSetChanged();
        this.mLayerAdapter.setSelected(stickerView);
        setCurrentEdit(stickerView);
        setCurrentEditAtSave(stickerView);
    }


    public void addViewToUndoList(View view) {
        ViewModel viewModel;
        float f;
        float f2;
        float f3;
        float f4;
        float f5;
        float rotation = 0;
        float h = 0;
        float w = 0;
        float xVar = 0;
        float yVar = 0;
        int i = 0;
        while (true) {
            if (i >= this.mViewModels.size()) {
                viewModel = null;
                break;
            } else if (this.mViewModels.get(i).getView() == view) {
                viewModel = this.mViewModels.get(i);
                break;
            } else {
                i++;
            }
        }
        ViewModel viewModel2 = viewModel;
        if (viewModel2 != null) {
            viewModel2.getView().getLocationOnScreen(new int[2]);
            viewModel2.getView().getMatrix().getValues(new float[9]);
            if (viewModel2.getView() instanceof StickerView) {
                rotation = viewModel2.getView().getRotation();
                h = ((StickerView) viewModel2.getView()).getH();
                w = ((StickerView) viewModel2.getView()).getW();
                xVar = ((StickerView) viewModel2.getView()).getx();
                yVar = ((StickerView) viewModel2.getView()).gety();
            } else if (viewModel2.getView() instanceof BubbleTextView) {
                rotation = viewModel2.getView().getRotation();
                h = ((BubbleTextView) viewModel2.getView()).getH();
                w = ((BubbleTextView) viewModel2.getView()).getW();
                xVar = ((BubbleTextView) viewModel2.getView()).getx();
                yVar = ((BubbleTextView) viewModel2.getView()).gety();
            } else {
                f5 = 0.0f;
                f4 = 0.0f;
                f3 = 0.0f;
                f2 = 0.0f;
                f = 0.0f;
                this.mUndoViews.add(new UndoViews(viewModel2, f5, f4, f3, 1, f2, f));
            }
            f2 = h;
            f = w;
            f5 = xVar;
            f4 = yVar;
            f3 = rotation;
            this.mUndoViews.add(new UndoViews(viewModel2, f5, f4, f3, 1, f2, f));
        }
    }


    public void addBubble(float f, float f2, float f3, float f4, float f5, String str, float f6) {
        final BubbleTextView bubbleTextView = new BubbleTextView(this, -1, 0);
        bubbleTextView.setImageResource(R.drawable.updated_bg, f, f2, f3, f4, f5);
        bubbleTextView.setOperationListener(new BubbleTextView.OperationListener() {
            public void onDeleteClick() {
                mViews.remove(bubbleTextView);
                mLayerAdapter.notifyDataSetChanged();
                addViewToUndoList(bubbleTextView);
                rootStickers.removeView(bubbleTextView);
                removeViewFromModel(bubbleTextView);
                setVisibilityMainEditList(null);
                shadowParent.setVisibility(View.GONE);
                secondDivider.setVisibility(View.INVISIBLE);
            }

            public void onEdit(BubbleTextView bubbleTextView) {
                if (mViews.contains(bubbleTextView)) {
                    if (mCurrentView != null) {
                        mCurrentView.setInEdit(false);
                    }
                    mCurrentEditTextView.setInEdit(false);
                    mCurrentEditTextView = bubbleTextView;
                    mCurrentEditTextView.setInEdit(true);
                    float alpha = mCurrentEditTextView.getAlpha();
                    float letterSpacing = mCurrentEditTextView.getLetterSpacing();
                    float lineSpacing = mCurrentEditTextView.getLineSpacing();
                    if (alpha != 0.0f) {
                        mSeekBarForText.setProgress((int) (mCurrentEditTextView.getAlpha() * 100.0f));
                    }
                    letterSpacingSeekBar.setProgress((int) (letterSpacing * 100.0f));
                    lineSpacingSeekBarForText.setProgress((int) (lineSpacing * 3.0f));

                    setVisibilityMainEditList(mCurrentEditTextView);
                    mLayerAdapter.setSelected(bubbleTextView);
                    bubbleNavigation.setCurrentActiveItem(0);
                    opacityForText.setVisibility(View.VISIBLE);
                    opacity.setVisibility(View.INVISIBLE);
                    opacityThumbForSticker.setVisibility(View.GONE);
                    shadowParent.setVisibility(View.VISIBLE);
                }
            }

            public void onClick(BubbleTextView bubbleTextView) {
                showEditTextDialog(false);
            }

            public void onTop(BubbleTextView bubbleTextView) {
                int indexOf = mViews.indexOf(bubbleTextView);
                if (indexOf != mViews.size() - 1) {
                    mViews.add(mViews.size(), mViews.remove(indexOf));
                }
            }
        });
        this.rootStickers.addView(bubbleTextView, new RelativeLayout.LayoutParams(-1, -1));
        this.mViews.add(bubbleTextView);
        bubbleTextView.setText(str);
        bubbleTextView.setLetterSpacing(f6);
        bubbleTextView.setLineSpacing(10.0f);
        this.mViewModels.add(new ViewModel(bubbleTextView, createBitmapFromView(bubbleTextView, 20, 20)));
        this.mLayerAdapter.notifyDataSetChanged();
        setCurrentEdit(bubbleTextView);
        this.mLayerAdapter.setSelected(bubbleTextView);
    }

    private void addBubbleAtPosition(int i, int i2, String str) {
        final BubbleTextView bubbleTextView = new BubbleTextView(this, i2, 0);
        bubbleTextView.setImageResource(R.drawable.updated_bg);
        bubbleTextView.setText(str);
        bubbleTextView.setOperationListener(new BubbleTextView.OperationListener() {
            public void onClick(BubbleTextView bubbleTextView) {
            }

            public void onDeleteClick() {
                mViews.remove(bubbleTextView);
                mLayerAdapter.notifyDataSetChanged();
                addViewToUndoList(bubbleTextView);
                rootStickers.removeView(bubbleTextView);
                removeViewFromModel(bubbleTextView);
            }

            public void onEdit(BubbleTextView bubbleTextView) {
                if (mCurrentView != null) {
                    mCurrentView.setInEdit(false);
                }
                mCurrentEditTextView.setInEdit(false);
                mCurrentEditTextView = bubbleTextView;
                mCurrentEditTextView.setInEdit(true);
            }

            public void onTop(BubbleTextView bubbleTextView) {
                int indexOf = mViews.indexOf(bubbleTextView);
                if (indexOf != mViews.size() - 1) {
                    mViews.add(mViews.size(), mViews.remove(indexOf));
                }
            }
        });
        this.rootStickers.addView(bubbleTextView, i, new RelativeLayout.LayoutParams(-1, -1));
        this.mViews.add(i, bubbleTextView);
        sortList();
        this.mLayerAdapter.notifyDataSetChanged();
        setCurrentEdit(bubbleTextView);
    }

    private void setCurrentEdit(BubbleTextView bubbleTextView) {
        StickerView stickerView = this.mCurrentView;
        if (stickerView != null) {
            stickerView.setInEdit(false);
        }
        BubbleTextView bubbleTextView2 = this.mCurrentEditTextView;
        if (bubbleTextView2 != null) {
            bubbleTextView2.setInEdit(false);
        }
        this.opacityThumbForSticker.setVisibility(View.GONE);
        this.secondDivider.setVisibility(View.VISIBLE);
        this.mCurrentEditTextView = bubbleTextView;
        bubbleTextView.setInEdit(true);
        this.bubbleNavigation.setVisibility(View.VISIBLE);
        this.opacityForText.setVisibility(View.VISIBLE);
        this.mLayerAdapter.setSelected(bubbleTextView);
    }

    private void setCurrentEdit(StickerView stickerView) {
        StickerView stickerView2 = this.mCurrentView;
        if (stickerView2 != null) {
            stickerView2.setInEdit(false);
        }
        BubbleTextView bubbleTextView = this.mCurrentEditTextView;
        if (bubbleTextView != null) {
            bubbleTextView.setInEdit(false);
        }
        this.opacityThumbForSticker.setVisibility(View.VISIBLE);
        this.secondDivider.setVisibility(View.VISIBLE);
        this.mCurrentView = stickerView;
        stickerView.setInEdit(true);
        this.mLayerAdapter.setSelected(stickerView);
    }


    public void setCurrentEditAtSave(StickerView stickerView) {
        if (this.mCurrentView != null) {
            this.recycleEditText.setVisibility(View.INVISIBLE);
            this.mCurrentView.setInEdit(false);
            this.opacityThumbForSticker.setVisibility(View.GONE);
            this.opacity.setVisibility(View.INVISIBLE);
            this.opacityForText.setVisibility(View.INVISIBLE);
            this.secondDivider.setVisibility(View.INVISIBLE);
        }
    }


    public void setCurrentEditAtSave(BubbleTextView bubbleTextView) {
        if (this.mCurrentEditTextView != null) {
            this.recycleEditText.setVisibility(View.INVISIBLE);
            this.opacity.setVisibility(View.INVISIBLE);
            this.opacityForText.setVisibility(View.INVISIBLE);
            this.opacityThumbForSticker.setVisibility(View.GONE);
            this.mCurrentEditTextView.setInEdit(false);
            this.secondDivider.setVisibility(View.INVISIBLE);
        }
    }

    private float getHeight(float f) {
        return this.actualHeight * f;
    }

    private float getWidth(float f) {
        return this.actualWidth * f;
    }

    public static Bitmap createBitmapFromView(View view, int i, int i2) {
        if (i > 0 && i2 > 0) {
            view.measure(View.MeasureSpec.makeMeasureSpec(DynamicUnitUtils.convertDpToPixels((float) i), BasicMeasure.EXACTLY), View.MeasureSpec.makeMeasureSpec(DynamicUnitUtils.convertDpToPixels((float) i2), BasicMeasure.EXACTLY));
        }
        view.layout(0, 0, view.getMeasuredWidth(), view.getMeasuredHeight());
        view.setDrawingCacheEnabled(true);
        view.buildDrawingCache(true);
        Bitmap createBitmap = Bitmap.createBitmap(view.getDrawingCache());
        view.setDrawingCacheEnabled(false);
        return createBitmap;
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.item_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId != R.id.layer) {
            if (itemId == R.id.save) {
                showSaveImageDialog();
            } else if (itemId == R.id.undo && !this.mUndoViews.isEmpty()) {
                int size = this.mUndoViews.size() - 1;
                UndoViews undoViews = this.mUndoViews.get(size);
                if (undoViews.getViewModel().getView() instanceof StickerView) {
                    addStickerViewAtPosition(undoViews.getViewModel().getBitmap(), undoViews.getHeight(), undoViews.getWidth(), undoViews.getX(), undoViews.getY(), undoViews.getRotation(), undoViews.getPosition());
                } else {
                    addBubble(undoViews.getX(), undoViews.getY(), undoViews.getHeight(), undoViews.getWidth(), undoViews.getRotation(), "Enter Text", 0.1f);
                }
                this.mUndoViews.remove(size);
            }
        } else if (this.isAnimatedLayer) {
            endAnimation();
            if (this.linearLayout.getVisibility() == 4) {
                this.linearLayout.setVisibility(View.VISIBLE);
            }
        } else {
            if (this.linearLayout.getVisibility() == 4) {
                this.linearLayout.setVisibility(View.VISIBLE);
            }
            enterAnimation();
        }
        return super.onOptionsItemSelected(menuItem);
    }

    public void removeViewFromModel(View view) {
        for (int i = 0; i < this.mViewModels.size(); i++) {
            if (this.mViewModels.get(i).getView() == view) {
                this.mViewModels.remove(i);
                this.mLayerAdapter.notifyDataSetChanged();
                return;
            }
        }
    }

    public void enterAnimation() {
        this.isAnimatedLayer = true;
        AnimatorSet animatorSet = new AnimatorSet();
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat(this.linearLayout, "translationX", -200.0f, 0.0f);
        ObjectAnimator ofFloat2 = ObjectAnimator.ofFloat(this.linearLayout, "alpha", 0.0f, 1.0f);
        animatorSet.setDuration(250);
        animatorSet.playTogether(ofFloat, ofFloat2);
        animatorSet.start();
    }

    public void endAnimation() {
        this.isAnimatedLayer = false;
        AnimatorSet animatorSet = new AnimatorSet();
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat(this.linearLayout, "translationX", 0.0f, -200.0f);
        ObjectAnimator ofFloat2 = ObjectAnimator.ofFloat(this.linearLayout, "alpha", 1.0f, 0.0f);
        animatorSet.setDuration(250);
        animatorSet.playTogether(ofFloat, ofFloat2);
        animatorSet.start();
    }

    public Bitmap getBitmap(String str) {
        Bitmap[] bitmapArr = new Bitmap[1];
        new Thread(new Runnable() {


            public final void run() {
                lambda$getBitmap$16(str, bitmapArr);
            }
        }).start();
        return bitmapArr[0];
    }

    static void lambda$getBitmap$16(String str, Bitmap[] bitmapArr) {
        try {
            bitmapArr[0] = BitmapFactory.decodeStream(new URI(str).toURL().openConnection().getInputStream());
        } catch (IOException e) {
            System.out.println(e);
        } catch (URISyntaxException e2) {
            e2.printStackTrace();
        }
    }

    public void setBackground() {
        String overlay_image = this.rootTemplate.getOverlay_image();
        this.rootTemplate.getOverlay_image_coordinate().getWidth();
        this.rootTemplate.getOverlay_image_coordinate().getWidth();
        new Thread(new Runnable() {


            public final void run() {
                lambda$setBackground$17$EditorActivity(overlay_image, new Bitmap[1]);
            }
        }).start();
        this.mLayerAdapter.notifyDataSetChanged();
    }

    public void lambda$setBackground$17$EditorActivity(String str, final Bitmap[] bitmapArr) {
        try {
            bitmapArr[0] = BitmapFactory.decodeStream(new URI(str).toURL().openConnection().getInputStream());
            runOnUiThread(new Runnable() {
                public void run() {

                    actualWidth = (float) displayMetrics.widthPixels;
                    bitmapArr[0].getWidth();
                    bitmapArr[0].getHeight();
                    actualHeight = (((float) bitmapArr[0].getHeight()) * actualWidth) / ((float) bitmapArr[0].getWidth());

                    bitmapArr[0] = Bitmap.createScaledBitmap(bitmapArr[0], (int) actualWidth, (int) actualHeight, true);
                    backgroundImg.setImageBitmap(bitmapArr[0]);
                    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams((int) actualWidth, (int) actualHeight);
                    layoutParams.addRule(3, R.id.title);
                    layoutParams.addRule(2, R.id.bottomLinear);
                    layoutParams.addRule(13, -1);
                    container.setLayoutParams(layoutParams);
                    rootStickers.getLayoutParams().height = (int) actualHeight;
                    rootStickers.getLayoutParams().width = (int) actualWidth;
                    mViews.add(backgroundImg);
                    setStickers();
                    setCutout();
                }
            });
        } catch (IOException e) {
            System.out.println(e);
        } catch (URISyntaxException e2) {
            e2.printStackTrace();
        }
    }


    public void setStickers() {
        for (int i = 0; i < this.template_layers.size(); i++) {
            TempleteLayer templeteLayer = this.template_layers.get(i);
            this.template_layers_obj = templeteLayer;
            if (templeteLayer.getSticker() != null) {
                String analyticsId = this.template_layers_obj.getSticker().getAnalyticsId();
                if (!analyticsId.contains("Cutouts_Foreground") && !analyticsId.contains("Cutout_Foreground") && !analyticsId.contains("MRinge_foreground")) {
                    load(2, this.template_layers_obj.getSticker().getStickerUrl(), getHeight((float) this.template_layers_obj.getCoordinate().getHeight()), getWidth((float) this.template_layers_obj.getCoordinate().getWidth()), getWidth((float) this.template_layers_obj.getCoordinate().getX()), getHeight((float) this.template_layers_obj.getCoordinate().getY()), (float) this.template_layers_obj.getCoordinate().getAngle(), false);
                }
            } else if (this.template_layers.get(i).getPlaceholderImageUrl() != null) {
                if (this.template_layers.get(i).getDynamicLayout() == null && this.template_layers.get(i).getText() == null) {
                    Bitmap bitmap2 = cutOuts;
                    setCutoutImg(bitmap2, (float) bitmap2.getHeight(), (float) cutOuts.getWidth(), getWidth((float) this.template_layers_obj.getCoordinate().getX()), getHeight((float) this.template_layers_obj.getCoordinate().getY()), (float) this.template_layers_obj.getCoordinate().getAngle(), true);
                }
            } else if (this.template_layers.get(i).getPlaceholderImageUrl() == null && this.template_layers.get(i).getDynamicLayout() == null && this.template_layers.get(i).getText() == null) {
                if (cutOuts != null) {
                    int height = (int) getHeight((float) this.template_layers_obj.getCoordinate().getHeight());
                    int width = (int) getWidth((float) this.template_layers_obj.getCoordinate().getWidth());
                    int height2 = cutOuts.getHeight() / cutOuts.getWidth();
                    float f = this.actualHeight;
                    if (((float) (height / width)) == (f / 2.0f) / ((((float) width) * (f / 2.0f)) / ((float) height))) {
                        Toast.makeText(this, "same ratio", Toast.LENGTH_SHORT).show();
                    }
                    Bitmap bitmap3 = cutOuts;
                    float f2 = this.actualHeight;
                    setCutoutImg(bitmap3, f2 / 2.0f, ((f2 / 2.0f) * ((float) bitmap3.getWidth())) / ((float) cutOuts.getHeight()), getWidth((float) this.template_layers_obj.getCoordinate().getX()), getHeight((float) this.template_layers_obj.getCoordinate().getY()), (float) this.template_layers_obj.getCoordinate().getAngle(), true);
                } else {
                    setCutoutImg(Constant.Cutout_portrait, getHeight((float) this.template_layers_obj.getCoordinate().getHeight()), getWidth((float) this.template_layers_obj.getCoordinate().getWidth()), getWidth((float) this.template_layers_obj.getCoordinate().getX()), getHeight((float) this.template_layers_obj.getCoordinate().getY()), (float) this.template_layers_obj.getCoordinate().getAngle(), true);
                }
            }
            if (i == this.template_layers.size() - 1 && this.isCutoutLoaded && this.loading.isShowing()) {
                this.loading.dismiss();
            }
        }
    }


    public void setCutout() {
        for (int i = 0; i < this.template_layers.size(); i++) {
            TempleteLayer templeteLayer = this.template_layers.get(i);
            this.template_layers_obj = templeteLayer;
            if (templeteLayer.getSticker() != null) {
                String analyticsId = this.template_layers_obj.getSticker().getAnalyticsId();
                if (analyticsId.contains("Cutout_Foreground") || analyticsId.contains("Cutouts_Foreground") || analyticsId.contains("MRinge_foreground")) {
                    ImageView imageView = new ImageView(this);
                    Glide.with(this).load(this.template_layers_obj.getSticker().getStickerUrl()).addListener(new RequestListener<Drawable>() {
                        public boolean onLoadFailed(GlideException glideException, Object obj, @NonNull Target<Drawable> target, boolean z) {
                            return false;
                        }

                        public boolean onResourceReady(@NonNull Drawable drawable, @NonNull Object obj, Target<Drawable> target, @NonNull DataSource dataSource, boolean z) {
                            isCutoutLoaded = true;
                            loading.dismiss();
                            return false;
                        }
                    }).into(imageView);
                    this.rootStickers.addView(imageView);
                    RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) imageView.getLayoutParams();
                    imageView.getLayoutParams().height = (int) getHeight((float) this.template_layers_obj.getCoordinate().getHeight());
                    imageView.getLayoutParams().width = (int) getWidth((float) this.template_layers_obj.getCoordinate().getWidth());
                    layoutParams.setMargins(0, (int) getHeight((float) this.template_layers_obj.getCoordinate().getY()), 0, 0);
                    imageView.setLayoutParams(layoutParams);
                } else {
                    this.isCutoutLoaded = true;
                    this.loading.dismiss();
                }
            } else {
                this.loading.dismiss();
            }
        }
    }

    private void setFrame() {
        String overlay_image = this.rootTemplate.getOverlay_image();
        this.bitmap = new Bitmap[1];
        new Thread(new Runnable() {

            public void run() {
                setFrameData(overlay_image);
            }
        }).start();
    }

    public void setFrameData(String str) {
        try {
            this.bitmap[0] = BitmapFactory.decodeStream(new URI(str).toURL().openConnection().getInputStream());
            runOnUiThread(new Runnable() {
                public final void run() {
                    bitmap[0].getWidth();
                    bitmap[0].getHeight();
                    actualWidth = (float) displayMetrics.widthPixels;
                    float height = (((float) bitmap[0].getHeight()) * actualWidth) / ((float) bitmap[0].getWidth());
                    actualHeight = height;
                    float f = maxFitMargin;
                    if (height > f) {
                        actualHeight = f;
                        actualWidth = (((float) bitmap[0].getWidth()) * actualHeight) / ((float) bitmap[0].getHeight());
                    } else {
                        RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) container.getLayoutParams();
                        layoutParams.addRule(13, -1);
                        container.setLayoutParams(layoutParams);
                        actualWidth = (float) displayMetrics.widthPixels;
                        actualHeight = (((float) bitmap[0].getHeight()) * actualWidth) / ((float) bitmap[0].getWidth());
                    }
                    Bitmap[] bitmapArr = bitmap;
                    bitmapArr[0] = Bitmap.createScaledBitmap(bitmapArr[0], (int) actualWidth, (int) actualHeight, true);
                    rootFrame.setImageBitmap(bitmap[0]);
                    RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams((int) actualWidth, (int) actualHeight);
                    layoutParams2.addRule(3, R.id.title);
                    layoutParams2.addRule(2, R.id.bottomLinear);
                    layoutParams2.addRule(13, -1);
                    container.setLayoutParams(layoutParams2);
                    rootFrame.getLayoutParams().height = (int) actualHeight;
                    rootFrame.getLayoutParams().width = (int) actualWidth;
                    rootImages.getLayoutParams().height = (int) actualHeight;
                    rootImages.getLayoutParams().width = (int) actualWidth;
                    rootStickers.getLayoutParams().height = (int) actualHeight;
                    rootStickers.getLayoutParams().width = (int) actualWidth;
                    setImagesForFrame();
                }
            });
        } catch (IOException e) {
            System.out.println(e);
        } catch (URISyntaxException e2) {
            e2.printStackTrace();
        }
    }


    public void onBackPressed() {
        showBackHomeDialog();
    }

    private void setImagesForFrame() {
        for (int i = 0; i < this.rootTemplate.getImages().size() && this.rootTemplate.getImages().size() <= this.selectedImg.getSelectedImg().size(); i++) {
            FrameLayout frameLayout = new FrameLayout(this);
            this.rootImages.addView(frameLayout);
            frameLayout.getLayoutParams().height = (int) getHeight((float) this.rootTemplate.getImages().get(i).getCoordinate().getHeight());
            frameLayout.getLayoutParams().width = (int) getWidth((float) this.rootTemplate.getImages().get(i).getCoordinate().getWidth());
            frameLayout.setX((float) ((int) getWidth((float) this.rootTemplate.getImages().get(i).getCoordinate().getX())));
            frameLayout.setY((float) ((int) getHeight((float) this.rootTemplate.getImages().get(i).getCoordinate().getY())));
            frameLayout.setRotation((float) this.rootTemplate.getImages().get(i).getCoordinate().getAngle());
            ImageView imageView = new ImageView(this);
            Glide.with(this).load(this.selectedImg.getSelectedImg().get(i)).into(imageView);
            frameLayout.addView(imageView);
            imageView.getLayoutParams().height = (int) getHeight((float) this.rootTemplate.getImages().get(i).getCoordinate().getHeight());
            imageView.getLayoutParams().width = (int) getWidth((float) this.rootTemplate.getImages().get(i).getCoordinate().getWidth());
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            imageView.setRotation((float) this.rootTemplate.getImages().get(i).getCoordinate().getAngle());
            imageView.setOnTouchListener(new MultiTouchListener());
            if (i == this.rootTemplate.getImages().size() - 1) {
                this.loading.dismiss();
            }
        }
    }


    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        int REQUEST_CODE = 77;
        if (i2 == -1 && i == REQUEST_CODE && intent != null) {
            try {
                MediaStore.Images.Media.getBitmap(getContentResolver(), intent.getData());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if (i2 == -1 && i == 2 && intent != null) {
            String photo = intent.getStringExtra("selectedSticker");
            if (!photo.equalsIgnoreCase("")) {
                this.shadowParent.setVisibility(View.GONE);
                this.shadowChild.setVisibility(View.INVISIBLE);
                Glide.with(this).asBitmap().load(photo).into(new CustomTarget<Bitmap>() {
                    public void onLoadCleared(Drawable drawable) {
                    }

                    public void onResourceReady(@NonNull Bitmap bitmap, Transition<? super Bitmap> transition) {
                        if (bitmap != null) {
                            setCutoutImg(bitmap, 250.0f, 250.0f, 0.0f, 0.0f, 0.0f, false);
                        }
                    }
                });
            }
        }
        if (i2 == -1 && i == 12 && intent != null) {
            intent.getStringExtra("selectedImg");
            Bitmap bitmap2 = Constant.Cutout;
            float f = this.actualHeight;
            setCutoutImg(bitmap2, f / 2.0f, ((f / 2.0f) * ((float) Constant.Cutout.getWidth())) / ((float) Constant.Cutout.getHeight()), 0.0f, 0.0f, 0.0f, true);
        }
        if (i2 == -1 && i == 10 && intent != null) {
            intent.getStringExtra("selectedImg");
            if (this.isForFront) {
                setCutoutImg(Constant.Cutout, 600.0f, 600.0f, 0.0f, 0.0f, 0.0f, false);
                this.isForFront = false;
            } else {
                this.backgroundImg.setImageBitmap(Constant.Cutout);
                this.backgroundImg.getLayoutParams().height = (int) this.actualHeight;
                this.backgroundImg.getLayoutParams().width = (int) this.actualWidth;
            }
        }

        if (i2 == -1 && i == 11) {
            Bitmap bitmapFromPath = getBitmapFromPath(getFilesDir() + "/temp.png");
            if (this.isForFront) {
                setCutoutImg(bitmapFromPath, 600.0f, 600.0f, 0.0f, 0.0f, 0.0f, false);
                this.isForFront = false;
            } else {
                this.backgroundImg.setImageBitmap(bitmapFromPath);
                this.backgroundImg.getLayoutParams().height = (int) this.actualHeight;
                this.backgroundImg.getLayoutParams().width = (int) this.actualWidth;
            }
        }

    }


    public void onSaveInstanceState(@NonNull Bundle bundle) {
        super.onSaveInstanceState(bundle);
    }


    public void onRestoreInstanceState(@NonNull Bundle bundle) {
        super.onRestoreInstanceState(bundle);
    }


    public void onDestroy() {
        Glide.with(getApplicationContext()).pauseRequests();
        super.onDestroy();
    }

    public void init() {
        adFrame = findViewById(R.id.adSpace);
        rootStickers = findViewById(R.id.rootStickers);
        innerContainer = findViewById(R.id.innerContainer);
        mRecyclerView = findViewById(R.id.recyclerView);
        linearLayout = findViewById(R.id.linearLayout);
        backgroundImg = findViewById(R.id.background);
        rootImages = findViewById(R.id.rootImages);
        rootFrame = findViewById(R.id.rootFrame);
        container = findViewById(R.id.container);
        opacity = findViewById(R.id.opacity);
        opacityForText = findViewById(R.id.opacityForText);
        mSeekBar = findViewById(R.id.opacitySeekBar);
        mSeekBarForText = findViewById(R.id.opacitySeekBarForText);
        addStickerBtn = findViewById(R.id.addSticker);
        recycleEditText = findViewById(R.id.editTextRecycle);
        colorThumbForText = findViewById(R.id.colorThumbForText);
        fontFamilyThumbForText = findViewById(R.id.fontFamilyThumbForText);
        opacityThumbForText = findViewById(R.id.opacityThumbForText);
        letterSpacing = findViewById(R.id.letterSpacing);
        letterSpacingSeekBar = findViewById(R.id.letterSpacingSeekBar);
        letterSpacingThumbForText = findViewById(R.id.letterSpacingThumbForText);
        editThumbForText = findViewById(R.id.editThumbForText);
        lineSpacingThumbForText = findViewById(R.id.editThumbForLineSpacing);
        lineSpacingSeekBarForText = findViewById(R.id.lineSpacingSeekBarForText);
        lineSpacingForText = findViewById(R.id.lineSpacingForText);
        undoBtn = findViewById(R.id.undoBtn);
        erase = findViewById(R.id.erase);
        downloadBtn = findViewById(R.id.downloadBtn);
        btnBack = findViewById(R.id.btnBack);
        layer_ic = findViewById(R.id.layers_ic);
        bubbleNavigation = findViewById(R.id.bubble_view_linear);
        secondDivider = findViewById(R.id.secondDivider);
        shadowImage = findViewById(R.id.shadowImage);
        shadowParent = findViewById(R.id.shadowParent);
        shadowChild = findViewById(R.id.shadowChild);
        bottomLinear = findViewById(R.id.bottomLinear);
        opacityThumbForSticker = findViewById(R.id.opacityThumbForSticker);
        addCutout = findViewById(R.id.addCutout);
        addBackground = findViewById(R.id.addBackground);
        addStickerBtn = findViewById(R.id.addSticker);
        addTextSticker = findViewById(R.id.addTextSticker);
    }

    public Bitmap viewToBitmap(View view) {
        view.setDrawingCacheEnabled(true);
        return view.getDrawingCache();
    }

    public void saveImage(Bitmap bitmap2, String str, Boolean bool) {
        if (bool) {
            this.saveLoader.show();
        }
        new Thread(new Runnable() {


            public final void run() {
                try {
                    if (Build.VERSION.SDK_INT > 29) {
                        String saveBitmapOnAboveQ = FileUtils.saveBitmapOnAboveQ(str, bitmap2, EditorActivity.this);
                        if (saveBitmapOnAboveQ == null) {
                            runOnUiThread(new Runnable() {
                                public final void run() {
                                    saveLoader.dismiss();
                                    Toast.makeText(EditorActivity.this, "Failed to Save to image", Toast.LENGTH_SHORT).show();
                                }
                            });
                        } else if (bool) {
                            runOnUiThread(new Runnable() {


                                public final void run() {
                                    saveLoader.dismiss();
                                    Intent intent = new Intent(getBaseContext(), SaveActivity.class);
                                    intent.putExtra("fromWhere", "edit");
                                    intent.putExtra("filePath", saveBitmapOnAboveQ);
                                    startActivity(intent);
                                    finish();
                                }
                            });
                        }
                    } else {
                        FileOutputStream fileOutputStream = new FileOutputStream(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/" + getString(R.string.app_name) + "/" + str + ".png");
                        bitmap2.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
                        fileOutputStream.close();
                        boolean[] zArr = {false};
                        MediaScannerConnection.scanFile(EditorActivity.this, new String[]{Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/" + getString(R.string.app_name) + "/" + str + ".png"}, (String[]) null, new MediaScannerConnection.OnScanCompletedListener() {


                            public final void onScanCompleted(String str, Uri uri) {
                                zArr[0] = true;
                            }
                        });

                        if (bool) {
                            runOnUiThread(new Runnable() {


                                public final void run() {
                                    saveLoader.dismiss();
                                    Intent intent = new Intent(getBaseContext(), SaveActivity.class);
                                    intent.putExtra("fromWhere", "edit");
                                    intent.putExtra("filePath", Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/" + getString(R.string.app_name) + "/" + str + ".png");
                                    startActivity(intent);
                                    finish();
                                }
                            });
                        }
                    }
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e2) {
                    e2.printStackTrace();
                }
            }
        }).start();
    }


    public void setVisibilityMainEditList(View view) {
        if (view == null) {
            setViewInvisible(recycleEditText);
            setViewInvisible(opacityForText);
            setViewInvisible(opacity);
            setViewInvisible(letterSpacing);
            setViewInvisible(lineSpacingForText);
            this.opacity.setVisibility(View.INVISIBLE);
            this.opacityThumbForText.setVisibility(View.GONE);
            this.bubbleNavigation.setVisibility(View.INVISIBLE);
        } else if (view instanceof BubbleTextView) {
            this.opacity.setVisibility(View.INVISIBLE);
            this.opacityThumbForText.setVisibility(View.GONE);
            this.bubbleNavigation.setVisibility(View.VISIBLE);
        } else if (view instanceof StickerView) {
            this.opacityForText.setVisibility(View.INVISIBLE);
            this.letterSpacing.setVisibility(View.INVISIBLE);
            this.opacityThumbForText.setVisibility(View.VISIBLE);
            setViewInvisible(this.lineSpacingForText);
            setViewInvisible(this.recycleEditText);
            this.opacity.setVisibility(View.VISIBLE);
            this.bubbleNavigation.setVisibility(View.INVISIBLE);
        }
    }

    public void setViewInvisible(View view) {
        view.setVisibility(View.INVISIBLE);
    }

    public void showEditTextDialog(final boolean z) {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.edit_text_bottom_sheet);
        dialog.getWindow().setFlags(8, 8);
        dialog.show();
        dialog.getWindow().getDecorView().setSystemUiVisibility(getWindow().getDecorView().getSystemUiVisibility());
        dialog.getWindow().clearFlags(8);
        dialog.getWindow().setLayout(-1, -1);
        final android.widget.EditText editText = (android.widget.EditText) dialog.findViewById(R.id.textInput);
        editText.setTypeface(Constant.TYPEFACE);
        editText.requestFocus();
        new Handler(Looper.myLooper()).postDelayed(new Runnable() {


            public final void run() {
                ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(editText, 1);
            }
        }, 200);
        ((android.widget.TextView) dialog.findViewById(R.id.txtDone)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).toggleSoftInput(1, 0);
                String trim = editText.getText().toString().trim();
                if (trim.equals("")) {
                    Toast.makeText(EditorActivity.this, "Please enter text..", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (z) {
                    shadowParent.setVisibility(View.VISIBLE);
                    addBubble(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, trim, 0.1f);
                } else {
                    mCurrentEditTextView.setText(trim);
                }
                dialog.dismiss();
            }
        });
        dialog.findViewById(R.id.txtCancel).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).toggleSoftInput(1, 0);
                dialog.dismiss();
            }
        });
        dialog.getWindow().setBackgroundDrawableResource(R.color.transparent);
    }


    public void showSaveImageDialog() {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_save);
        dialog.getWindow().setFlags(8, 8);
        dialog.show();
        dialog.getWindow().getDecorView().setSystemUiVisibility(getWindow().getDecorView().getSystemUiVisibility());
        dialog.getWindow().clearFlags(8);
        dialog.getWindow().setLayout(-1, -1);

        dialog.findViewById(R.id.btnSave).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                dialog.dismiss();

                setCurrentEditAtSave(mCurrentView);

                setCurrentEditAtSave(mCurrentEditTextView);
                saveImageAtStorage(true);
            }
        });
        dialog.findViewById(R.id.btnDismiss).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.getWindow().setBackgroundDrawableResource(R.color.transparent);
    }

    public void showBackHomeDialog() {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.discard_work_dialog);
        dialog.getWindow().setFlags(8, 8);
        dialog.show();
        dialog.getWindow().getDecorView().setSystemUiVisibility(getWindow().getDecorView().getSystemUiVisibility());
        dialog.getWindow().clearFlags(8);
        dialog.getWindow().setLayout(-1, -1);
        ((ImageView) dialog.findViewById(R.id.close)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.findViewById(R.id.btnSaveAndBack).setOnClickListener(new View.OnClickListener() {


            public final void onClick(View view) {
                setCurrentEditAtSave(mCurrentView);
                setCurrentEditAtSave(mCurrentEditTextView);
                saveImageAtStorage(false);
                dialog.dismiss();
                finish();
            }
        });
        dialog.findViewById(R.id.btnDismiss).setOnClickListener(new View.OnClickListener() {


            public final void onClick(View view) {
                dialog.dismiss();
                finish();
            }
        });
        dialog.getWindow().setBackgroundDrawableResource(R.color.transparent);
    }


    public void showAddImageDialog() {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.image_chooser_dialog);
        dialog.getWindow().setFlags(8, 8);
        dialog.show();
        dialog.getWindow().getDecorView().setSystemUiVisibility(getWindow().getDecorView().getSystemUiVisibility());
        dialog.getWindow().clearFlags(8);
        dialog.getWindow().setLayout(-1, -1);

        dialog.findViewById(R.id.closeBtn).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.findViewById(R.id.frontImages).setOnClickListener(new View.OnClickListener() {


            public void onClick(View view) {
                isForFront = true;
                setCurrentEditAtSave(mCurrentView);
                setCurrentEditAtSave(mCurrentEditTextView);

                Intent intent = new Intent(getApplicationContext(), SelectImageActivity.class);
                intent.putExtra("from", "EditFront");
                intent.putExtra("forCrop", "no");
                startActivityForResult(intent, 10);

                dialog.dismiss();
            }
        });
        dialog.findViewById(R.id.backImages).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                isForFront = false;
                dialog.dismiss();

                Intent intent = new Intent(getApplicationContext(), SelectImageActivity.class);
                intent.putExtra("from", TAG);
                intent.putExtra("forCrop", "no");
                startActivityForResult(intent, 10);

            }
        });
        dialog.getWindow().setBackgroundDrawableResource(R.color.transparent);
    }

    public Bitmap TrimBitmap(Bitmap bitmap2) {
        int height = bitmap2.getHeight();
        int width = bitmap2.getWidth();
        int i = 0;
        for (int i2 = 0; i2 < width && i == 0; i2++) {
            int i3 = 0;
            while (true) {
                if (i3 >= height) {
                    break;
                } else if (bitmap2.getPixel(i2, i3) != 0) {
                    i = i2;
                    break;
                } else {
                    i3++;
                }
            }
        }
        int i4 = 0;
        for (int i5 = width - 1; i5 >= 0 && i4 == 0; i5--) {
            int i6 = 0;
            while (true) {
                if (i6 >= height) {
                    break;
                } else if (bitmap2.getPixel(i5, i6) != 0) {
                    i4 = i5;
                    break;
                } else {
                    i6++;
                }
            }
        }
        int i7 = 0;
        for (int i8 = 0; i8 < height && i7 == 0; i8++) {
            int i9 = 0;
            while (true) {
                if (i9 >= width) {
                    break;
                } else if (bitmap2.getPixel(i9, i8) != 0) {
                    i7 = i8;
                    break;
                } else {
                    i9++;
                }
            }
        }
        int i10 = 0;
        for (int i11 = height - 1; i11 >= 0 && i10 == 0; i11--) {
            int i12 = 0;
            while (true) {
                if (i12 >= width) {
                    break;
                } else if (bitmap2.getPixel(i12, i11) != 0) {
                    i10 = i11;
                    break;
                } else {
                    i12++;
                }
            }
        }
        return Bitmap.createBitmap(bitmap2, i, i7, i4 - i, i10 - i7);
    }


    public Bitmap stackMaskingProcess(Bitmap bitmap2, Bitmap bitmap3) {
        Bitmap[] bitmapArr = {null};
        Bitmap[] bitmapArr2 = new Bitmap[1];
        if (bitmap2 != null) {
            try {
                int width = bitmap2.getWidth();
                int height = bitmap2.getHeight();
                bitmapArr[0] = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                bitmapArr2[0] = Bitmap.createScaledBitmap(bitmap3, width, height, true);
                Canvas canvas = new Canvas(bitmapArr[0]);
                Paint paint = new Paint(1);
                paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
                canvas.drawBitmap(bitmap2, 0.0f, 0.0f, (Paint) null);
                canvas.drawBitmap(bitmapArr2[0], 0.0f, 0.0f, paint);
                paint.setXfermode((Xfermode) null);
                paint.setStyle(Paint.Style.STROKE);
            } catch (OutOfMemoryError e) {
                e.printStackTrace();
            }
        }
        return bitmapArr[0];
    }

    public Bitmap getBitmapFromPath(String str) {
        try {
            Bitmap decodeSampledBitmap = decodeSampledBitmap(new File(str), 1080, 768);
            int attributeInt = new ExifInterface(str).getAttributeInt(androidx.exifinterface.media.ExifInterface.TAG_ORIENTATION, 1);
            Matrix matrix = new Matrix();
            if (attributeInt == 6) {
                matrix.postRotate(90.0f);
                return Bitmap.createBitmap(decodeSampledBitmap, 0, 0, decodeSampledBitmap.getWidth(), decodeSampledBitmap.getHeight(), matrix, true);
            } else if (attributeInt == 3) {
                matrix.postRotate(180.0f);
                return Bitmap.createBitmap(decodeSampledBitmap, 0, 0, decodeSampledBitmap.getWidth(), decodeSampledBitmap.getHeight(), matrix, true);
            } else if (attributeInt != 8) {
                return decodeSampledBitmap;
            } else {
                matrix.postRotate(270.0f);
                return Bitmap.createBitmap(decodeSampledBitmap, 0, 0, decodeSampledBitmap.getWidth(), decodeSampledBitmap.getHeight(), matrix, true);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public Bitmap decodeSampledBitmap(File file, int i, int i2) throws FileNotFoundException {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeStream(new FileInputStream(file), (Rect) null, options);
        options.inSampleSize = calculateInSampleSize(options, i, i2);
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeStream(new FileInputStream(file), (Rect) null, options);
    }

    public int calculateInSampleSize(BitmapFactory.Options options, int i, int i2) {
        int i3 = options.outHeight;
        int i4 = options.outWidth;
        int i5 = 1;
        if (i3 > i2 || i4 > i) {
            int i6 = i3 / 2;
            int i7 = i4 / 2;
            while (i6 / i5 >= i2 && i7 / i5 >= i) {
                i5 *= 2;
            }
        }
        return i5;
    }
}
