package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.myAds;


public class Log {
	public static final boolean isDebugMode = true;
	public static final boolean showAds=true;

	// log some debug info
	public static void d(String tag, String message) {
		if (isDebugMode) {
			android.util.Log.d(tag, "" + message);
		}
	}

	// log some debug info
	public static void d(String tag, String message, Throwable e) {
		if (isDebugMode) {
			android.util.Log.d(tag, "" + message, e);
		}
	}

	// log some error
	public static void e(String tag, String message) {
		if (isDebugMode) {
			android.util.Log.e(tag, "" + message);
		}
	}

	// log some debug info
	public static void e(String tag, String message, Throwable e) {
		if (isDebugMode) {
			android.util.Log.e(tag, "" + message, e);
		}
	}

	// log some information
	public static void i(String tag, String message) {
		if (isDebugMode) {
			android.util.Log.i(tag, "" + message);
		}
	}
	public static void i( String message) {
		if (isDebugMode) {
			android.util.Log.i("VVB", "" + message);
		}
	}
	// log some information
	public static void i(String tag, String message, Throwable e) {
		if (isDebugMode) {
			android.util.Log.i(tag, "" + message, e);
		}
	}

	// log some waring
	public static void w(String tag, String message) {
		if (isDebugMode) {
			android.util.Log.w(tag, "" + message);
		}
	}

	// log some debug info
	public static void w(String tag, String message, Throwable e) {
		if (isDebugMode) {
			android.util.Log.w(tag, "" + message, e);
		}
	}

	// log verbose
	public static void v(String tag, String message) {
		if (isDebugMode) {
			android.util.Log.v(tag, "" + message);
		}
	}

	// log some debug info
	public static void v(String tag, String message, Throwable e) {
		if (isDebugMode) {
			android.util.Log.v(tag, "" + message, e);
		}
	}

}
