package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.eraser.eraser;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import androidx.core.app.NotificationCompat;

import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.activity.SplashScreen;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.application.MyApplication;

import java.lang.Thread;

public class MyExceptionHandlerPix implements Thread.UncaughtExceptionHandler {
    private final Activity activity;

    public MyExceptionHandlerPix(Activity activity2) {
        this.activity = activity2;
    }

    public void uncaughtException(Thread thread, Throwable th) {
        Intent intent;
        if (this.activity != null) {
            intent = new Intent(this.activity, SplashScreen.class);
        } else {
            intent = MyApplication.getContext() != null ? new Intent(MyApplication.getContext(), SplashScreen.class) : null;
        }
        intent.putExtra("crash", true);
        intent.addFlags(335577088);
        ((AlarmManager) MyApplication.getContext().getSystemService(NotificationCompat.CATEGORY_ALARM)).set(1, System.currentTimeMillis() + 10, PendingIntent.getActivity(MyApplication.getContext(), 0, intent, 1073741824));
        System.exit(2);
    }
}
