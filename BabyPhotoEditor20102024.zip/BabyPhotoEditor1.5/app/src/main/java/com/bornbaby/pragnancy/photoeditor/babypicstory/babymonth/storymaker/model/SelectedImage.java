package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model;

import java.io.Serializable;
import java.util.ArrayList;

public class SelectedImage implements Serializable {
    ArrayList<String> selectedImg;

    public SelectedImage(ArrayList<String> arrayList) {
        this.selectedImg = arrayList;
    }

    public ArrayList<String> getSelectedImg() {
        return this.selectedImg;
    }

    public void setSelectedImg(ArrayList<String> arrayList) {
        this.selectedImg = arrayList;
    }
}
