package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.myAds;

import android.content.Context;
import android.content.SharedPreferences;

public class AdSDKPref {

    public static final String splash_open_ads = "splash_open_ads";
    public static final String TAG_AOA_SPASH_ONOFF = "tag_aoa_spash_onoff";
    public static final String TAG_NATIVE_LANGUAGE_2_ONOFF = "tag_native_language_2_onoff";
    public static final String TAG_NATIVE_LANGUAGE_1_ONOFF = "tag_native_language_1_onoff";
    public static final String TAG_AOA_RESUME_ONOFF = "tag_aoa_resume_onoff";
    public static final String TAG_NATIVE_ONBOARDING_1_ONOFF = "tag_native_onboarding_1_onoff";
    public static final String TAG_NATIVE_ONBOARDING_2_ONOFF = "tag_native_onboarding_2_onoff";
    public static final String TAG_NATIVE_ONBOARDING_3_ONOFF = "tag_native_onboarding_3_onoff";
    public static final String TAG_INTER_HOME_ONOFF = "tag_inter_home_onoff";
    public static final String TAG_INTER_TEMPLATE_ONOFF = "tag_inter_template_onoff";
    public static final String TAG_BANNER_HOME_ONOFF = "tag_banner_home_onoff";
    public static final String TAG_NATIVE_SEE_ALL_ONOFF = "tag_native_welcome_onoff";
    public static final String TAG_BANNER_SPLASH_ONOFF = "tag_banner_splash_onoff";
    public static final String TAG_INTER_PREVIEW_ONOFF = "tag_inter_back_result_onoff";
    public static final String TAG_NATIVE_CREATION_ONOFF = "tag_native_creation_onoff";
    public static final String TAG_NATIVE_EXIT_ONOFF = "tag_native_exit_onoff";
    public static final String TAG_INTER_SELECT_IMAGE_ONOFF = "tag_inter_click_open_media_onoff";
    public static final String TAG_NATIVE_SAVE_MEDIA_ONOFF = "tag_native_save_media_onoff";
    public static final String TAG_NATIVE_MYCREATION_ONOFF = "tag_native_facechoose_onoff";
    public static final String TAG_NATIVE_PREVIEW_ONOFF = "tag_native_preview_onoff";
    public static final String TAG_NATIVE_SELECTIMAGE_ONOFF = "tag_native_selectimage_onoff";
    public static final String TAG_NATIVE_SELECTTEMPLATE_ONOFF = "tag_native_selecttemplate_onoff";
    public static final String TAG_NATIVE_CREATIONVIEWIMAGE_ONOFF = "tag_native_creationviewimage_onoff";
    public static final String TAG_GENRATE_REWORD_ONOFF = "tag_genrate_reword_onoff";
    public static final String TAG_WATERMARK_REWORD_ONOFF = "tag_watermark_reword_onoff";
    public static final String TAG_TEMPLATE_WATERMARK_REWORD_ONOFF = "tag_template_watermark_reword_onoff";
    public static String TAG_NAITVE_LANGUAGE_HIGH_FLOW = "naitve_language_high_flow";
    public static String TAG_EXAPTION_HANDLE = "tag_exaption_handle";


    private static final String PREF_NAME = "pixa_pref";


    private SharedPreferences m_csPref;
    private static final int MODE_PRIVATE = 0;


    public static final String TAG_ALL_AD_OFF = "tag_all_ad_off";


    public static AdSDKPref getInstance(Context context) {
        try {
            return new AdSDKPref(context, PREF_NAME, MODE_PRIVATE);
        } catch (Exception e) {

        }

        return null;
    }

    private AdSDKPref(final Context context, final String pref_name,
                      final int mode) {
        super();
        this.m_csPref = context.getSharedPreferences(pref_name, mode);
    }

    public String getString(final String key, final String defaultValue) {
        return this.m_csPref.getString(key, defaultValue);
    }

    public void setString(String key, String value) {
        final SharedPreferences.Editor edit = this.m_csPref.edit();
        edit.putString(key, value);
        edit.apply();
    }

    public int getInt(final String key, final int defaultValue) {
        return this.m_csPref.getInt(key, defaultValue);
    }

    public void clear(String key) {
        m_csPref.edit().remove(key).commit();
    }

    public boolean getBoolean(final String key, final boolean defaultValue) {
        return this.m_csPref.getBoolean(key, defaultValue);
    }

    public int putBoolean(final String key, final boolean defaultValue) {
        final SharedPreferences.Editor edit = this.m_csPref.edit();
        edit.putBoolean(key, defaultValue);
        edit.apply();
        return 0;
    }

    public int putInt(final String key, final int defaultValue) {
        final SharedPreferences.Editor edit = this.m_csPref.edit();
        edit.putInt(key, defaultValue);
        edit.apply();
        return 0;
    }

    public int putString(final String key, final String defaultValue) {
        final SharedPreferences.Editor edit = this.m_csPref.edit();
        edit.putString(key, defaultValue);
        edit.apply();
        return 0;
    }
}
