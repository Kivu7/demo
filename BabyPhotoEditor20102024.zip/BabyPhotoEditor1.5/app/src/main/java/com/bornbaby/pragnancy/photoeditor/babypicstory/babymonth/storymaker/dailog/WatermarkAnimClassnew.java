package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.dailog;

import android.animation.ValueAnimator;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.fragment.app.FragmentActivity;

import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.R;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.application.MyApplication;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.myAds.Log;


public class WatermarkAnimClassnew implements ValueAnimator.AnimatorUpdateListener {

    public final ProgressBar progressBar;
    DialogFinishListner adListner;
    public final TextView textView;
    public final FragmentActivity fragmentActivity;
    WatermarkAlertDialog dailogWatermark;
    public WatermarkAnimClassnew(FragmentActivity editorTemplateActivity, ProgressBar progressBar, TextView textView, WatermarkAlertDialog dailogWatermark, DialogFinishListner adListner) {
        this.fragmentActivity = editorTemplateActivity;
        this.progressBar = progressBar;
        this.textView = textView;
        this.dailogWatermark = dailogWatermark;
        this.adListner = adListner;
    }

    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        FragmentActivity editorTemplateActivity = this.fragmentActivity;
        ProgressBar progressBar = this.progressBar;
        TextView textView = this.textView;
        editorTemplateActivity.getClass();
        int intValue = (Integer) valueAnimator.getAnimatedValue();
        progressBar.setProgress(intValue);
        int i10 = 5;
        int i11 = i10 - ((intValue * i10) / 100);
        textView.setText(String.format(editorTemplateActivity.getResources().getString(R.string.video_starting_in_seconds), i11));
        if (i11 <= 0) {
            Log.d("RewaredInt", "Call Show For Premium Item : " + i11);

            if (MyApplication.getInstance().mTemplateListActivity != null && MyApplication.getInstance().mTemplateListActivity.isVideoAdsLoaded && !MyApplication.getInstance().mTemplateListActivity.isWatermarkdailogClose) {
                if (dailogWatermark!=null && dailogWatermark.isVisible()){
                    dailogWatermark.dismiss();
                }
                Log.d("RewaredInt", "Call Show  Premium Item  1");
                MyApplication.getInstance().mTemplateListActivity.isVideoAdsLoaded = false;
                MyApplication.getInstance().mTemplateListActivity.showRewarededIntForPremiumItem();
            } else {
                fragmentActivity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                      //  Toast.makeText(fragmentActivity, "Video Ad not load, try again!", Toast.LENGTH_SHORT).show();
                        try {
                            if (dailogWatermark!=null && dailogWatermark.isVisible()){
                                dailogWatermark.dismiss();
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });


            }
        }
 




    }

}



