package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.content.res.Resources;
import android.net.ConnectivityManager;
import android.util.Base64;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class Utils {

    public Utils() {

    }



    public static float dp2px(Resources resources, float dp) {
        final float scale = resources.getDisplayMetrics().density;
        return dp * scale + 0.5f;
    }

    public static float sp2px(Resources resources, float sp) {
        final float scale = resources.getDisplayMetrics().scaledDensity;
        return sp * scale;
    }


    public static boolean isNetworkConnected(Context lCon) {
        ConnectivityManager cm = null;
        try {
            cm = (ConnectivityManager) lCon
                    .getSystemService(Context.CONNECTIVITY_SERVICE);


        } catch (Exception e) {
            e.printStackTrace();
        }
        return cm.getActiveNetworkInfo() != null;
    }

    public static String getAssetJsonData(Context context, String name) throws IOException {

        try {
            return doCrypFromAsset(context.getAssets().open(name), context);
        } catch (Exception ex) {
            ex.printStackTrace();
            return "";
        }



    }
    private static String doCrypFromAsset(InputStream inputStream, Context context) throws Exception {

        Key secretKey = new SecretKeySpec(printHashKey(context).getBytes(), "Blowfish");
        Cipher cipher = Cipher.getInstance("Blowfish");
        cipher.init(Cipher.DECRYPT_MODE, secretKey);


        byte[] inputBytes = new byte[(int) inputStream.available()];
        inputStream.read(inputBytes);

        byte[] outputBytes = cipher.doFinal(inputBytes);

        return new String(outputBytes, StandardCharsets.UTF_8);
    }

    public static String printHashKey(Context context) {
        try {
            String hashKey = "";
            PackageInfo info = context.getPackageManager().getPackageInfo(context.getPackageName(), PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                hashKey = new String(Base64.encode(md.digest(), 0));

            }
            return "data/app";
        } catch (NoSuchAlgorithmException e) {
        } catch (Exception e) {
        }
        return "data/app";
    }
}
