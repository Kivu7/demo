package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model;

public class UndoViews {
    private float X;
    private float Y;
    private float height;
    private ViewModel mViewModel;
    private int position;
    private float rotation;
    private float width;

    public UndoViews(ViewModel viewModel, float f, float f2, float f3, int i, float f4, float f5) {
        this.mViewModel = viewModel;
        this.X = f;
        this.Y = f2;
        this.rotation = f3;
        this.position = i;
        this.height = f4;
        this.width = f5;
    }

    public ViewModel getViewModel() {
        return this.mViewModel;
    }

    public void setViewModel(ViewModel viewModel) {
        this.mViewModel = viewModel;
    }

    public float getX() {
        return this.X;
    }

    public void setX(int i) {
        this.X = (float) i;
    }

    public float getY() {
        return this.Y;
    }

    public void setY(int i) {
        this.Y = (float) i;
    }

    public float getRotation() {
        return this.rotation;
    }

    public void setRotation(float f) {
        this.rotation = f;
    }

    public int getPosition() {
        return this.position;
    }

    public void setPosition(int i) {
        this.position = i;
    }

    public float getWidth() {
        return this.width;
    }

    public void setWidth(float f) {
        this.width = f;
    }

    public float getHeight() {
        return this.height;
    }

    public void setHeight(float f) {
        this.height = f;
    }
}
