package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.method.LinkMovementMethod;
import android.text.style.URLSpan;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.AcknowledgePurchaseResponseListener;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.ProductDetailsResponseListener;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesResponseListener;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryPurchasesParams;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.R;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.Constants;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.EPreferences;

import java.util.List;
import java.util.Objects;

import kotlin.collections.CollectionsKt;


public   class PremiumActivity extends AppCompatActivity {
    private BillingClient billingClient;
    private ProductDetails mSubProductDetails1;
    private ProductDetails mSubProductDetails2;
    private ProductDetails mSubProductDetails3;
     
    private int mIndex = 2;


    @Override  
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_premium);
        initData();
        handleEvents();
    }

    @Override  
    public void onResume() {
        super.onResume();
        BillingClient billingClient = this.billingClient;
        if (billingClient == null) {
            billingClient = null;
        }
        billingClient.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType("subs").build(), new PurchasesResponseListener() {
            @Override 
            public void onQueryPurchasesResponse(BillingResult billingResult, List list) {
                if (billingResult.getResponseCode() == 0) {
                    for (Object o : list) {
                        Purchase purchase = (Purchase) o;
                        if (purchase.getPurchaseState() == 1 && !purchase.isAcknowledged()) {
                            handleBuyCodePurchase(purchase);
                        }
                    }
                }
            }
        });
    }



    private void initData() {
        String string = getString(R.string.txt_google_play_subscription);
        SpannableString spannableString = new SpannableString(string);
        spannableString.setSpan(new URLSpan("https://play.google.com/store/account/subscriptions"), 0, string.length(), 33);
        ((TextView) findViewById(R.id.txtGoogleSubCenter)).setText(spannableString);
        ((TextView) findViewById(R.id.txtGoogleSubCenter)).setMovementMethod(LinkMovementMethod.getInstance());
        ((TextView) findViewById(R.id.txtGoogleSubCenter)).setHighlightColor(0);
        this.billingClient = BillingClient.newBuilder(this).enablePendingPurchases().setListener(new PurchasesUpdatedListener() {
            @Override
            public void onPurchasesUpdated(BillingResult billingResult, List list) {
                if (billingResult.getResponseCode() != 0 || list == null) {
                    return;
                }
                for (Object o : list) {
                    Purchase purchase = (Purchase) o;
                    handleBuyCodePurchase(purchase);
                }
            }
        }).build();
        establishConnection();
    }



    private void handleEvents() {
        findViewById(R.id.btnClose).setOnClickListener(new View.OnClickListener() {
            @Override 
            public void onClick(View view) {
                finish();
            }
        });
        findViewById(R.id.btnWeekly).setOnClickListener(new View.OnClickListener() {
            @Override 
            public void onClick(View view) {
                mIndex = 1;
                resetSelectPrice();
                findViewById(R.id.btnWeekly).setBackgroundResource(R.drawable.bg_price_selected);
            }
        });
        findViewById(R.id.btnMonthly).setOnClickListener(new View.OnClickListener() {
            @Override 
            public void onClick(View view) {
                mIndex = 2;
                resetSelectPrice();
                findViewById(R.id.btnMonthly).setBackgroundResource(R.drawable.bg_price_selected);
            }
        });
        findViewById(R.id.btnYearly).setOnClickListener(new View.OnClickListener() {
            @Override 
            public void onClick(View view) {
                mIndex = 3;
                resetSelectPrice();
                findViewById(R.id.btnYearly).setBackgroundResource(R.drawable.bg_price_selected);
            }
        });
        findViewById(R.id.btnSub).setOnClickListener(new View.OnClickListener() {
            @Override 
            public  void onClick(View view) {
                int i = mIndex;
                if (i == 1) {
                    ProductDetails productDetails = mSubProductDetails1;
                    if (productDetails != null) {
                        launchPurchaseFlowSub(productDetails);
                    }
                } else if (i == 2) {
                    ProductDetails productDetails2 = mSubProductDetails2;
                    if (productDetails2 != null) {
                        launchPurchaseFlowSub(productDetails2);
                    }
                } else {
                    ProductDetails productDetails3 = mSubProductDetails3;
                    if (productDetails3 != null) {
                        launchPurchaseFlowSub(productDetails3);
                    }
                }
            }
        });
    }


    private void resetSelectPrice() {
        findViewById(R.id.btnWeekly).setBackgroundResource(R.drawable.bg_price_regular);
        findViewById(R.id.btnMonthly).setBackgroundResource(R.drawable.bg_price_regular);
        findViewById(R.id.btnYearly).setBackgroundResource(R.drawable.bg_price_regular);
    }

    public void establishConnection() {
        BillingClient billingClient = this.billingClient;
        if (billingClient == null) {
            billingClient = null;
        }
        billingClient.startConnection(new BillingClientStateListener() {
            @Override
            public void onBillingSetupFinished(BillingResult billingResult) {
                if (billingResult.getResponseCode() == 0) {
                    PremiumActivity.this.showSubProducts();
                }
            }

            @Override
            public void onBillingServiceDisconnected() {
                establishConnection();
            }
        });
    }

    private void launchPurchaseFlow(ProductDetails productDetails) {
        BillingFlowParams build = BillingFlowParams.newBuilder().setProductDetailsParamsList(CollectionsKt.listOf(BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(productDetails).build())).build();
        BillingClient billingClient = this.billingClient;
        if (billingClient == null) {
            billingClient = null;
        }
        billingClient.launchBillingFlow(this, build);
    }

    private void launchPurchaseFlowSub(ProductDetails productDetails) {
        productDetails.getSubscriptionOfferDetails();
        BillingFlowParams.ProductDetailsParams.Builder productDetails2 = BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(productDetails);
        List<ProductDetails.SubscriptionOfferDetails> subscriptionOfferDetails = productDetails.getSubscriptionOfferDetails();
        BillingFlowParams build = BillingFlowParams.newBuilder().setProductDetailsParamsList(CollectionsKt.listOf(productDetails2.setOfferToken(subscriptionOfferDetails.get(0).getOfferToken()).build())).build();
        BillingClient billingClient = this.billingClient;
        if (billingClient == null) {
            billingClient = null;
        }
        billingClient.launchBillingFlow(this, build);
    }

    public void handleBuyCodePurchase(final Purchase purchase) {
        if (purchase.isAcknowledged()) {
            return;
        }
        BillingClient billingClient = this.billingClient;
        if (billingClient == null) {
            billingClient = null;
        }
        billingClient.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder().setPurchaseToken(purchase.getPurchaseToken()).build(), new AcknowledgePurchaseResponseListener() {
            @Override 
            public void onAcknowledgePurchaseResponse(BillingResult billingResult) {

                if (billingResult.getResponseCode() == 0) {
                    String str = purchase.getProducts().get(0);
                    if (str.equals(Constants.KEY_SUB_1) || str.equals(Constants.KEY_SUB_2) || str.equals(Constants.KEY_SUB_3)) {
                        purchaseSuccess();
                    }
                }
            }
        });
    }


    private void purchaseSuccess() {
        Objects.requireNonNull(EPreferences.getInstance(PremiumActivity.this)).setString(EPreferences.PREF_IS_PERCHASE, "1");
        startActivity(new Intent(this, HomeActivity.class));
        finish();
    }

    public void showSubProducts() {
        QueryProductDetailsParams build = QueryProductDetailsParams.newBuilder().setProductList(CollectionsKt.listOf(QueryProductDetailsParams.Product.newBuilder().setProductId(Constants.KEY_SUB_1).setProductType("subs").build(), QueryProductDetailsParams.Product.newBuilder().setProductId(Constants.KEY_SUB_2).setProductType("subs").build(), QueryProductDetailsParams.Product.newBuilder().setProductId(Constants.KEY_SUB_3).setProductType("subs").build())).build();
        BillingClient billingClient2 = this.billingClient;
        if (billingClient2 == null) {
            billingClient2 = null;
        }
        billingClient2.queryProductDetailsAsync(build, new ProductDetailsResponseListener() {
            @Override
            public void onProductDetailsResponse(@NonNull BillingResult billingResult, @NonNull List<ProductDetails> list) {
                for (ProductDetails productDetails : list) {
                    String productId = productDetails.getProductId();
                    int hashCode = productId.hashCode();
                    if (hashCode != 734563888) {
                        if (hashCode != 791709753) {
                            if (hashCode == 1306409022 && productId.equals(Constants.KEY_SUB_2)) {

                                mSubProductDetails2 = productDetails;
                                findViewById(R.id.txtMonthlyPrice).post(new Runnable() {
                                    @Override
                                    public void run() {
                                        ProductDetails productDetails = mSubProductDetails2;
                                        List<ProductDetails.SubscriptionOfferDetails> subscriptionOfferDetails = productDetails.getSubscriptionOfferDetails();
                                        ((TextView) findViewById(R.id.txtMonthlyPrice)).setText(subscriptionOfferDetails.get(0).getPricingPhases().getPricingPhaseList().get(0).getFormattedPrice());
                                    }
                                });
                            }
                        } else if (productId.equals(Constants.KEY_SUB_3)) {
                            mSubProductDetails3 = productDetails;
                            findViewById(R.id.txtYearlyPrice).post(new Runnable() {
                                @Override
                                public void run() {
                                    ProductDetails productDetails = mSubProductDetails3;
                                    List<ProductDetails.SubscriptionOfferDetails> subscriptionOfferDetails = productDetails.getSubscriptionOfferDetails();
                                    ((TextView) findViewById(R.id.txtYearlyPrice)).setText(subscriptionOfferDetails.get(0).getPricingPhases().getPricingPhaseList().get(0).getFormattedPrice());
                                }
                            });
                        }
                    } else if (productId.equals(Constants.KEY_SUB_1)) {

                        mSubProductDetails1 = productDetails;
                        findViewById(R.id.txtWeeklyPrice).post(new Runnable() {
                            @Override
                            public void run() {
                                ProductDetails productDetails = mSubProductDetails1;
                                List<ProductDetails.SubscriptionOfferDetails> subscriptionOfferDetails = productDetails.getSubscriptionOfferDetails();
                                ((TextView) findViewById(R.id.txtWeeklyPrice)).setText(subscriptionOfferDetails.get(0).getPricingPhases().getPricingPhaseList().get(0).getFormattedPrice());
                            }
                        });
                    }
                }

            }
        });
    }




    @Override
    public void onDestroy() {
        super.onDestroy();
        try {
            BillingClient billingClient = this.billingClient;
            if (billingClient == null) {
                billingClient = null;
            }
            billingClient.endConnection();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}