package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.activity;


import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ProgressBar;

import androidx.appcompat.app.AppCompatActivity;

import com.ads.rn.admob.Admob;
import com.ads.rn.admob.AdsConsentManager;
import com.ads.rn.admob.AppOpenManager;
import com.ads.rn.ads.RNAd;
import com.ads.rn.funtion.AdCallback;
import com.ads.rn.funtion.UMPResultListener;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.R;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.application.MyApplication;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.myAds.AdSDKPref;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.EPreferences;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.PrefManager;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Locale;

public class SplashScreenActivity extends AppCompatActivity {



    SharedPreferences sharedPreferences;

    FrameLayout ad_view_container;



    public String md5(final String s) {
        try {
            // Create MD5 Hash
            MessageDigest digest = MessageDigest
                    .getInstance("MD5");
            digest.update(s.getBytes());
            byte messageDigest[] = digest.digest();

            // Create Hex String
            StringBuffer hexString = new StringBuffer();
            for (int i = 0; i < messageDigest.length; i++) {
                String h = Integer.toHexString(0xFF & messageDigest[i]);
                while (h.length() < 2)
                    h = "0" + h;
                hexString.append(h);
            }
            return hexString.toString();

        } catch (NoSuchAlgorithmException e) {
        }
        return "";
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        setContentView(R.layout.activity_splash_screen);
        startProgressChange();

        Bundle bundle = new Bundle();
        MyApplication.getInstance().EventRegister("splash_view", bundle);



        init();
        bindView();
        splAnimation();
    }
    AdsConsentManager adsConsentManager;
    private void init() {
        sharedPreferences = getSharedPreferences("first_time_preference", MODE_PRIVATE);

        String androidId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        String deviceId = md5(androidId).toUpperCase(Locale.getDefault());
        adsConsentManager = new AdsConsentManager(this);

        adsConsentManager.requestUMP(new UMPResultListener() {
            @Override
            public void onCheckUMPSuccess(boolean var1) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        loadSplash();
                    }
                });
            }


        });
    }
    private void startProgressChange() {

    }
    private void loadSplash() {
        loadAdaptiveBanner();
        Handler handler = new Handler(Looper.getMainLooper());
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {

                if (EPreferences.getInstance(SplashScreenActivity.this).getBoolean(EPreferences.SET_FASTTIME_LANGUAGE, true)) {
                    MyApplication.getInstance().preloadLangugeOne(SplashScreenActivity.this);
                }

                if (AdSDKPref.getInstance(SplashScreenActivity.this).getString(AdSDKPref.TAG_ALL_AD_OFF, "0").equals("off") || AdSDKPref.getInstance(SplashScreenActivity.this).getString(AdSDKPref.TAG_AOA_SPASH_ONOFF, "0").equalsIgnoreCase("off")) {
                    MyApplication.getInstance().isSpashScreenAdLoad = true;
                    loadMainActivity();
                } else {

                    if (AdSDKPref.getInstance(SplashScreenActivity.this).getString(AdSDKPref.splash_open_ads, "0").equals("0")) {

                        loadMainActivity();

                    } else {
                        manageCondition();
                    }
//                            MyApplication.getInstance().initAppOpenSplash(SplashScreenActivity.this);
                }

            }
        }, 5000);
    }
    private void bindView() {



    }

    private void splAnimation() {

    }
    private boolean isLanguageSet() {
        String languageCode = new PrefManager(this).getLanguageCode();
        return languageCode != null && !languageCode.trim().isEmpty();
    }

    public void launchLanguageSelectionScreen() {
        Intent intent = new Intent(this, LanguageSelectActivity.class);

        startActivity(intent);
        finish();
    }


    public void launchContentListScreen() {
        Intent intent = new Intent(this, HomeActivity.class);
        startActivity(intent);
        finish();
    }
    public void loadMainActivity() {
        if (!isLanguageSet()) {
            launchLanguageSelectionScreen();
        } else {
            MyApplication.getInstance().preloadintersial_home();
            launchContentListScreen();
        }
        finish();


        MyApplication.getInstance().isSpashScreenAdLoad = true;




    }


    protected void onStop() {
        super.onStop();
    }

    protected void onDestroy() {
        System.gc();
        super.onDestroy();
    }


    private void loadAdaptiveBanner() {
        FrameLayout ad_view_container = findViewById(R.id.bannerView);


        if (AdSDKPref.getInstance(this).getString(AdSDKPref.TAG_ALL_AD_OFF, "0").equals("off") || AdSDKPref.getInstance(this).getString(AdSDKPref.TAG_BANNER_SPLASH_ONOFF, "0").equals("off")) {

            ad_view_container.setVisibility(View.GONE);
        } else {
            RNAd.getInstance().loadBanner(this, getString(R.string.banner_splash));

        }
    }





    private void manageCondition() {
        boolean isLanguageFinish = sharedPreferences.getBoolean("first_time_ads", true);
        String tagCheck = AdSDKPref.getInstance(SplashScreenActivity.this).getString(AdSDKPref.splash_open_ads, "1");
        Admob.getInstance().setNumToShowAds(0);
        if (tagCheck.equals("1")) {
            appOpenManger();
        } else if (tagCheck.equals("2")) {
            LoadInterstitialAdForSplash();
        } else if (tagCheck.equals("3")) {
            if (!isLanguageFinish) {
                LoadInterstitialAdForSplash();
            } else {
                appOpenManger();
            }
        } else if (tagCheck.equals("4")) {
            if (!isLanguageFinish) {
                appOpenManger();
            } else {
                LoadInterstitialAdForSplash();
            }

        }else {
            appOpenManger();
        }
    }

    private void appOpenManger() {

//        MyApplication.getInstance().initAppOpenSplash(SplashScreenActivity.this);
        AppOpenManager.getInstance().loadOpenAppAdSplash(
                this,
                getString(R.string.aoa_spash),
                1000,
                20000,
                false,
                new AdCallback() {
                    @Override
                    public void onAdSplashReady() {
                        super.onAdSplashReady();
                        Log.e("EEEEEEE", "==> onAdSplashReady");
                        if (isDestroyed() || isFinishing()) return;
                        showAdsOpenAppSplash();
                    }

                    @Override
                    public void onNextAction() {
                        super.onNextAction();
                        Log.e("EEEEEEE", "==> onNextAction");
                        if (isDestroyed() || isFinishing()) return;
                        loadMainActivity();
                    }
                }
        );
    }

    @Override
    protected void onResume() {
        super.onResume();
        AppOpenManager.getInstance().disableAppResume();
    }

    private void showAdsOpenAppSplash() {
        Log.e("AAAA", "showAdsOpenAppSplash");
        AppOpenManager.getInstance().showAppOpenSplash(
                this,
                new AdCallback() {
                    @Override
                    public void onNextAction() {
                        super.onNextAction();
                        if (isDestroyed() || isFinishing()) return;
                        loadMainActivity();
                    }
                }
        );
    }

    private void LoadInterstitialAdForSplash() {
        RNAd.getInstance().loadSplashInterstitialAds(
                this,
                getString(R.string.inter_splash),
                5000,
                2000,
                new AdCallback() {
                    @Override
                    public void onNextAction() {
                        super.onNextAction();
                        if (isDestroyed() || isFinishing()) return;
                        loadMainActivity();
                    }
                }
        );
    }
}