package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.fragments;

import android.content.Context;
import android.content.Intent;
import android.graphics.Rect;
import android.net.ConnectivityManager;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.R;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.activity.SelectImageActivity;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.adapter.TemplateAdapter;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.adapter.ThumbListAdapter;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.TemplateJason.RootTemplate;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.Constant;

import java.util.ArrayList;

public class GenralFragment extends Fragment {
    private static final String ARG_PARAM = "key";
    private ArrayList<RootTemplate> mPortraitTemplates = new ArrayList<>();
    private RecyclerView mRecyclerView;
    int type;
    private View view;
    FragmentActivity fragmentActivity;

    public GenralFragment newInstance(int i) {
        GenralFragment categoryListFragment = new GenralFragment();
        Bundle bundle = new Bundle();
        bundle.putInt(ARG_PARAM, i);
        categoryListFragment.setArguments(bundle);
        return categoryListFragment;
    }

    public boolean isNetworkAvailable(Context lCon) {
        ConnectivityManager cm = null;
        try {
            cm = (ConnectivityManager) lCon.getSystemService(Context.CONNECTIVITY_SERVICE);
        } catch (Exception e) {

        }

        return cm.getActiveNetworkInfo() != null;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (getActivity() != null) {
            this.fragmentActivity = getActivity();
        }
        if (getArguments() != null) {
            this.type = getArguments().getInt(ARG_PARAM);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        this.view = inflater.inflate(R.layout.fragment_genral, container, false);
        int i = this.type;
        if (i == 1) {
            this.mPortraitTemplates = Constant.category.get("general");
        } else if (i == 2) {
            this.mPortraitTemplates = Constant.category.get("frame");
        } else if (i == 3) {
            this.mPortraitTemplates = Constant.category.get("collage");
        }
        initView();
        initAdapter();
        return view;
    }

    private void initAdapter() {
        final GridLayoutManager gridLayoutManager = new GridLayoutManager(this.fragmentActivity, 2, 1, false);
        this.mRecyclerView.setLayoutManager(gridLayoutManager);
        mRecyclerView.addItemDecoration(new GridSpacingItemDecoration(2, 20, true));
        TemplateAdapter mThumbListAdapter = new TemplateAdapter(this.fragmentActivity, this.mPortraitTemplates, new TemplateAdapter.onThumbClickInterface() {
            public final void onThumbClick(RootTemplate rootTemplate) {
                if (isNetworkAvailable(fragmentActivity)) {
                    Intent intent = new Intent(fragmentActivity, SelectImageActivity.class);
                    intent.putExtra("from", "Category");
                    intent.putExtra("forCrop", "Category");
                    intent.putExtra("rootTemplate", rootTemplate);
                    fragmentActivity.startActivity(intent);
                    return;
                }

                Toast.makeText(fragmentActivity, fragmentActivity.getString(R.string.internet_error), Toast.LENGTH_SHORT).show();
            }
        });
        this.mRecyclerView.setAdapter(mThumbListAdapter);
        this.mRecyclerView.setHasFixedSize(true);
//        this.mRecyclerView.setItemViewCacheSize(this.mPortraitTemplates.size());
    }

    private void initView() {
        this.mRecyclerView = this.view.findViewById(R.id.categoryListRecycle);
    }

    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.fragmentActivity = (FragmentActivity) context;
    }
    public  class GridSpacingItemDecoration extends RecyclerView.ItemDecoration {

        private final int spanCount;
        private final int spacing;
        private final boolean includeEdge;

        public GridSpacingItemDecoration(int spanCount, int spacing, boolean includeEdge) {
            this.spanCount = spanCount;
            this.spacing = spacing;
            this.includeEdge = includeEdge;
        }

        @Override
        public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
            int position = parent.getChildAdapterPosition(view); // item position
            int column = position % spanCount; // item column


            if (includeEdge) {
                outRect.left = spacing - column * spacing / spanCount; // spacing - column * ((1f / spanCount) * spacing)
                outRect.right = (column + 1) * spacing / spanCount; // (column + 1) * ((1f / spanCount) * spacing)

                if (position < spanCount) { // top edge
                    outRect.top = spacing;
                }
                outRect.bottom = spacing; // item bottom
            } else {
                outRect.left = column * spacing / spanCount; // column * ((1f / spanCount) * spacing)
                outRect.right = spacing - (column + 1) * spacing / spanCount; // spacing - (column + 1) * ((1f /    spanCount) * spacing)
                if (position >= spanCount) {
                    outRect.top = spacing; // item top
                }
            }
        }
    }
}