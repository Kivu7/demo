package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils;

public interface FilterClick {
    void clickFilter(int i);
}
