package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;


import android.widget.RadioButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatRadioButton;
import androidx.recyclerview.widget.RecyclerView;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.R;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.Language;
import java.util.List;

public class LanguageSelectionAdapter extends RecyclerView.Adapter<LanguageSelectionAdapter.ImageViewHolder> {
    Context context;
    List<Language> languageList;

    public LanguageSelectionAdapter(Context context2, List<Language> list) {
        this.context = context2;
        this.languageList = list;
    }

    @NonNull
    public ImageViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ImageViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_language_select, viewGroup, false));
    }

    public void onBindViewHolder(ImageViewHolder imageViewHolder, int i) {
        Language language = this.languageList.get(i);
        imageViewHolder.imgLanguage.setImageResource(language.getLanguageResourceId());
        imageViewHolder.txtLanguageName.setText(language.getLanguageName());
        imageViewHolder.radioSelected.setChecked(language.isSelected());
    }

    public int getItemCount() {
        List<Language> list = this.languageList;
        if (list != null) {
            return list.size();
        }
        return 0;
    }

    public Language getSelectedItem() {
        List<Language> list = this.languageList;
        if (list == null || list.size() <= 0) {
            return null;
        }
        for (Language next : this.languageList) {
            if (next.isSelected()) {
                return next;
            }
        }
        return null;
    }

    public class ImageViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        
        public final ImageView imgLanguage;
        
        public final AppCompatRadioButton radioSelected;
        
        public final TextView txtLanguageName;

        public ImageViewHolder(View view) {
            super(view);
            this.imgLanguage = view.findViewById(R.id.imgLanguage);
            this.txtLanguageName = view.findViewById(R.id.txtLanguageName);
            this.radioSelected = view.findViewById(R.id.radioSelected);
            view.setOnClickListener(this);
        }

        public void onClick(View view) {
            for (Language selected : languageList) {
                selected.setSelected(false);
            }
            languageList.get(getAdapterPosition()).setSelected(true);
            notifyDataSetChanged();
        }
    }
}
