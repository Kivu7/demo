package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.TemplateJason;

import java.io.Serializable;

public class Coordinate implements Serializable {
    private double angle;
    private double height;
    private double width;
    private double x;
    private double y;

    public void setX(double d) {
        this.x = d;
    }

    public double getX() {
        return this.x;
    }

    public void setY(double d) {
        this.y = d;
    }

    public double getY() {
        return this.y;
    }

    public void setWidth(double d) {
        this.width = d;
    }

    public double getWidth() {
        return this.width;
    }

    public void setHeight(double d) {
        this.height = d;
    }

    public double getHeight() {
        return this.height;
    }

    public void setAngle(double d) {
        this.angle = d;
    }

    public double getAngle() {
        return this.angle;
    }
}
