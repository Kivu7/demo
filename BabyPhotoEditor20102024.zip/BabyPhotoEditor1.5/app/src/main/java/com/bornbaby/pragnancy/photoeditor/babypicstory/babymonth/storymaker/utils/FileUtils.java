package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;


import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.R;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Locale;

public class FileUtils {
    private static final String APP_DIR = "Abner";
    private static final String TEMP_DIR = "Abner/.TEMP";
    private static FileUtils instance;
    private static Context mContext;

    public static FileUtils getInstance(Context context) {
        if (instance == null) {
            synchronized (FileUtils.class) {
                if (instance == null) {
                    mContext = context.getApplicationContext();
                    instance = new FileUtils();
                }
            }
        }
        return instance;
    }

    private static String getLocalPath() {
        return mContext.getFilesDir().getAbsolutePath() + "/";
    }

    public boolean isSDCanWrite() {
        return Environment.getExternalStorageState().equals("mounted") && Environment.getExternalStorageDirectory().canWrite() && Environment.getExternalStorageDirectory().canRead();
    }

    private FileUtils() {
        if (isSDCanWrite()) {
            creatSDDir(APP_DIR);
            creatSDDir(TEMP_DIR);
        }
    }

    public File creatSDDir(String str) {
        File file = new File(getLocalPath() + str);
        file.mkdirs();
        return file;
    }

    public static String saveBitmapOnAboveQ(String str, Bitmap bitmap, Context context) {
        ContentResolver contentResolver = context.getContentResolver();
        String str2 = Environment.DIRECTORY_PICTURES + File.separator + context.getString(R.string.app_name);
        try {
            ContentValues contentValues = new ContentValues();
            contentValues.put("_display_name", str);
            contentValues.put("mime_type", "image/png");
            contentValues.put("relative_path", str2);
            Uri insert = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);
            FileOutputStream fileOutputStream = (FileOutputStream) contentResolver.openOutputStream(insert);
            try {
                if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream)) {
                    fileOutputStream.flush();
                }
                return getPath(insert, context);
            } catch (IOException e) {
                e.printStackTrace();
                if (fileOutputStream != null) {
                    try {
                        fileOutputStream.close();
                    } catch (IOException e2) {
                        e2.printStackTrace();
                        if (fileOutputStream != null) {
                            try {
                                fileOutputStream.close();
                            } catch (IOException e3) {
                                e3.printStackTrace();
                            }
                        }
                        return null;
                    }
                }
                if (fileOutputStream != null) {
                    try {
                        fileOutputStream.close();
                    } catch (IOException e4) {
                        e4.printStackTrace();
                    }
                }
                return null;
            } catch (Throwable th) {
                if (fileOutputStream != null) {
                    try {
                        fileOutputStream.close();
                    } catch (IOException e5) {
                        e5.printStackTrace();
                    }
                }
                throw th;
            }
        } catch (FileNotFoundException e6) {
            e6.printStackTrace();
            return null;
        }
    }

    public static String getPath(Uri uri, Context context) {
        Cursor query = context.getContentResolver().query(uri, new String[]{"_data"}, null, null, null);
        if (query == null) {
            return null;
        }
        int columnIndexOrThrow = query.getColumnIndexOrThrow("_data");
        query.moveToFirst();
        String string = query.getString(columnIndexOrThrow);
        query.close();
        return string;
    }

    public static ArrayList<String> getImagesFromFolder(Activity activity, String str) {
        ArrayList<String> arrayList = new ArrayList<>();
        Uri contentUri = MediaStore.Files.getContentUri("external");
        Cursor query = activity.getContentResolver().query(contentUri, new String[]{"_id", "_data", "date_added", "media_type", "mime_type", "title", "bucket_display_name", "_display_name", "_size", "date_modified", "bucket_id", "duration"}, "bucket_display_name=?", new String[]{str}, "LOWER(date_modified) DESC");
        new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault());
        if (query != null) {
            while (query.moveToNext()) {
                try {
                    if (query.getInt(query.getColumnIndexOrThrow("media_type")) == 1 && query.getLong(query.getColumnIndexOrThrow("_size")) != 0) {
                        arrayList.add(query.getString(query.getColumnIndexOrThrow("_data")));
                    }
                } catch (Exception e) {
                }
            }
            query.close();
        }
        return arrayList;
    }
}
