package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.R;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.ViewModel;
import java.util.ArrayList;
import java.util.List;

public class LayerAdapter extends RecyclerView.Adapter<LayerAdapter.ViewHolder> {

    public Context context;
    
    public List<ViewModel> layers;
    
    public onClick mOnClick;
    private View selectedView;

    public interface onClick {
        void onClick(int i, int i2);
    }

    public LayerAdapter(Context context2, ArrayList<ViewModel> arrayList, onClick onclick) {
        this.layers = arrayList;
        this.context = context2;
        this.mOnClick = onclick;
    }

    @NonNull
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        LayoutInflater from = LayoutInflater.from(viewGroup.getContext());
        if (i == 3) {
            return new ViewHolder(from.inflate(R.layout.no_layers_layout, (ViewGroup) null));
        }
        return new ViewHolder(from.inflate(R.layout.single_layer_item, (ViewGroup) null));
    }

    public void onBindViewHolder(@NonNull final ViewHolder viewHolder, int i) {
        if (getItemViewType(i) == 7) {
            if (this.selectedView == null) {
                viewHolder.mLinearLayout.setBackgroundColor(this.context.getResources().getColor(R.color.transparentWhite));
            } else if (this.layers.get(viewHolder.getAdapterPosition()).getView() == this.selectedView) {
                viewHolder.mLinearLayout.setBackgroundColor(this.context.getResources().getColor(R.color.gradeint_start));
            } else {
                viewHolder.mLinearLayout.setBackgroundColor(this.context.getResources().getColor(R.color.transparentWhite));
            }
            viewHolder.mImageView.setImageBitmap(Bitmap.createScaledBitmap(this.layers.get(viewHolder.getAdapterPosition()).getBitmap(), 100, 100, true));
            viewHolder.mVisibilityImg.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    if (LayerAdapter.this.layers.get(viewHolder.getAdapterPosition()).isVisible()) {
                        viewHolder.mVisibilityImg.setImageResource(LayerAdapter.this.context.getResources().getIdentifier("ic_eye_close", "drawable", LayerAdapter.this.context.getPackageName()));
                    } else {
                        viewHolder.mVisibilityImg.setImageResource(LayerAdapter.this.context.getResources().getIdentifier("ic_eye_open", "drawable", LayerAdapter.this.context.getPackageName()));
                    }
                    LayerAdapter.this.mOnClick.onClick(viewHolder.getAdapterPosition(), 1);
                }
            });
            viewHolder.mLockImg.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    if (((ViewModel) LayerAdapter.this.layers.get(viewHolder.getAdapterPosition())).isClickable()) {
                        viewHolder.mLockImg.setImageResource(LayerAdapter.this.context.getResources().getIdentifier("ic_locked", "drawable", LayerAdapter.this.context.getPackageName()));
                    } else {
                        viewHolder.mLockImg.setImageResource(LayerAdapter.this.context.getResources().getIdentifier("ic_unlocked", "drawable", LayerAdapter.this.context.getPackageName()));
                    }
                    LayerAdapter.this.mOnClick.onClick(viewHolder.getAdapterPosition(), 2);
                }
            });
        }
    }

    public int getItemViewType(int i) {
        return this.layers.isEmpty() ? 3 : 7;
    }

    public int getItemCount() {
        if (this.layers.isEmpty()) {
            return 1;
        }
        return this.layers.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView mImageView;
        LinearLayout mLinearLayout;
        ImageView mLockImg;
        ImageView mVisibilityImg;

        public ViewHolder(View view) {
            super(view);
            if (getItemViewType() != 3) {
                this.mLinearLayout = view.findViewById(R.id.linearLayout);
                this.mImageView = view.findViewById(R.id.singleImg);
                this.mVisibilityImg = view.findViewById(R.id.visibility);
                this.mLockImg = view.findViewById(R.id.lock);
            }
        }
    }

    public void setSelected(View view) {
        this.selectedView = view;
        notifyDataSetChanged();
    }
}
