package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.TemplateJason;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;

public class Sticker implements Serializable {
    @SerializedName("alpha_crop_aspect_ratio")
    private Double alphaCropAspectRatio;
    @SerializedName("analytics_id")
    private String analyticsId;
    @SerializedName("aspect_ratio")
    private Double aspectRatio;
    @SerializedName("formats")
    private Integer formats;
    @SerializedName("freemium_locked")
    private Boolean freemiumLocked;
    @SerializedName("id")
    private Integer id;
    @SerializedName("image_text")
    private String imageText;
    @SerializedName("stickerUrl")
    private String stickerUrl;
    @SerializedName("use_thumbs")
    private Boolean useThumbs;
    @SerializedName("use_tint")
    private Boolean useTint;

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer num) {
        this.id = num;
    }

    public String getAnalyticsId() {
        return this.analyticsId;
    }

    public void setAnalyticsId(String str) {
        this.analyticsId = str;
    }

    public Boolean getUseTint() {
        return this.useTint;
    }

    public void setUseTint(Boolean bool) {
        this.useTint = bool;
    }

    public Boolean getUseThumbs() {
        return this.useThumbs;
    }

    public void setUseThumbs(Boolean bool) {
        this.useThumbs = bool;
    }

    public Integer getFormats() {
        return this.formats;
    }

    public void setFormats(Integer num) {
        this.formats = num;
    }

    public Double getAspectRatio() {
        return this.aspectRatio;
    }

    public void setAspectRatio(Double d) {
        this.aspectRatio = d;
    }

    public Double getAlphaCropAspectRatio() {
        return this.alphaCropAspectRatio;
    }

    public void setAlphaCropAspectRatio(Double d) {
        this.alphaCropAspectRatio = d;
    }

    public Boolean getFreemiumLocked() {
        return this.freemiumLocked;
    }

    public void setFreemiumLocked(Boolean bool) {
        this.freemiumLocked = bool;
    }

    public String getImageText() {
        return this.imageText;
    }

    public void setImageText(String str) {
        this.imageText = str;
    }

    public String getStickerUrl() {
        return this.stickerUrl;
    }

    public void setStickerUrl(String str) {
        this.stickerUrl = str;
    }
}
