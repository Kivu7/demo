package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.adapter;

import android.app.Activity;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.R;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.TemplateJason.RootTemplate;
import com.bumptech.glide.Glide;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class TemplateAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public Activity mContext;
    private onThumbClickInterface mOnThumbClickInterface;
    private List<RootTemplate> mRootTemplates;


    public interface onThumbClickInterface {
        void onThumbClick(RootTemplate rootTemplate);
    }

    public TemplateAdapter(Activity activity, ArrayList<RootTemplate> arrayList, onThumbClickInterface onthumbclickinterface) {
        this.mRootTemplates = arrayList;
        this.mContext = activity;
        this.mOnThumbClickInterface = onthumbclickinterface;
        DisplayMetrics displayMetrics2 = new DisplayMetrics();
        this.mContext.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics2);
    }

    @NonNull
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        LayoutInflater from = LayoutInflater.from(viewGroup.getContext());

        return new ViewHolder(from.inflate(R.layout.temlate_item, (ViewGroup) null));


    }

    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int i) {

        final ViewHolder viewHolder2 = (ViewHolder) viewHolder;
        String preview_thumbnail = this.mRootTemplates.get(viewHolder2.getAdapterPosition()).getPreview_thumbnail();
        if (preview_thumbnail == null) {
            preview_thumbnail = this.mRootTemplates.get(viewHolder2.getAdapterPosition()).getOverlay_image();
        }
        Glide.with(mContext).load(preview_thumbnail).into(viewHolder2.mImageView);
        Picasso.get().load(preview_thumbnail).into(viewHolder2.mImageView);

//        if (EPreferences.getInstance(mContext).getString(EPreferences.PREF_IS_PERCHASE, "0").equals("1")) {
            viewHolder2.ivLock.setVisibility(View.GONE);
//        } else {
//            boolean lock = mRootTemplates.get(viewHolder2.getAdapterPosition()).getFreemium_locked();
//
//            if (lock) {
//                viewHolder2.ivLock.setVisibility(View.VISIBLE);
//            } else {
//                viewHolder2.ivLock.setVisibility(View.GONE);
//                Log.i("VVBB", "template NAme : " + mRootTemplates.get(viewHolder2.getAdapterPosition()).getTitle());
//            }
//        }
        viewHolder2.mImageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

//                if (EPreferences.getInstance(mContext).getString(EPreferences.PREF_IS_PERCHASE, "0").equals("1")) {
                    mOnThumbClickInterface.onThumbClick(mRootTemplates.get(viewHolder.getAdapterPosition()));
//                }else {
//                    WatermarkAlertDialog watermarkDialog = WatermarkAlertDialog.newInstance(mRootTemplates.get(viewHolder2.getAdapterPosition()).getTitle());
//                    watermarkDialog.setVideoListner(new DialogFinishListner() {
//                        @Override
//                        public void CloseDialog() {
//
//                            try {
//                                watermarkDialog.dismiss();
//                            } catch (Exception e) {
//
//                            }
//                            mOnThumbClickInterface.onThumbClick(mRootTemplates.get(viewHolder.getAdapterPosition()));
//                        }
//                    });
//                    watermarkDialog.setCancelable(false);
//                    watermarkDialog.show(((AppCompatActivity) mContext).getSupportFragmentManager(), "WatermarkAlertDialogTag");
//                }
            }
        });


    }


    public int getItemCount() {
        return this.mRootTemplates.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView mImageView;
        ImageView ivLock;


        public ViewHolder(View view) {
            super(view);
            this.mImageView = view.findViewById(R.id.thumbImg);
            this.ivLock = view.findViewById(R.id.ivLock);

            DisplayMetrics displayMetrics = new DisplayMetrics();
            mContext.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
            this.mImageView.getLayoutParams().width = (displayMetrics.widthPixels / 2) - mContext.getResources().getDimensionPixelSize(R.dimen._15sdp);
        }
    }

}
