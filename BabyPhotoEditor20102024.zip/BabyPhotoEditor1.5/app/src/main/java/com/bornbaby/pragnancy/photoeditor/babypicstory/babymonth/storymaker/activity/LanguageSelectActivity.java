package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.activity;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ads.rn.ads.RNAd;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.R;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.adapter.LanguageSelectionAdapter;


import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.application.MyApplication;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.Language;


import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.myAds.AdSDKPref;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.CommonUtils;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.Constant;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.PrefManager;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.LoadAdError;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Locale;

public class LanguageSelectActivity extends AppCompatActivity {


    Boolean isActivityPause = false;
    private boolean isFromSetting = false;
    Context mContext;
    private PrefManager prefManager;
    public void LoadNativeAds() {
        FrameLayout frAds;
        ShimmerFrameLayout shimmerAds;
        frAds = findViewById(R.id.fr_ads);
        shimmerAds = findViewById(R.id.shimmer_native);
        if (AdSDKPref.getInstance(this).getString(AdSDKPref.TAG_ALL_AD_OFF, "0").equals("off") || AdSDKPref.getInstance(this).getString(AdSDKPref.TAG_NATIVE_CREATION_ONOFF, "0").equals("off")) {
            frAds.setVisibility(View.GONE);
            shimmerAds.setVisibility(View.GONE);
        } else {
            MyApplication.nativeAdsLanguage.observe(this, apNativeAd -> {
                if (apNativeAd != null) {
                    RNAd.getInstance().populateNativeAdView(
                            this,
                            apNativeAd,
                            frAds,
                            shimmerAds
                    );
                } else {
                    frAds.setVisibility(View.GONE);
                    shimmerAds.setVisibility(View.GONE);
                }
            });
        }

    }



    public void onCreate(Bundle bundle) {
        boolean z;
        super.onCreate(bundle);
        CommonUtils.updateLanguage(this);
        setContentView(R.layout.activity_language_select);
        LoadNativeAds();
        this.mContext = this;
        if (getIntent() != null) {
            ImageView imageView = findViewById(R.id.img_back);
            if (getIntent().getBooleanExtra("isShowBack", false)) {
                imageView.setOnClickListener(new View.OnClickListener() {
                    public final void onClick(View view) {
                        onBackPressed();
                    }
                });
                imageView.setVisibility(View.VISIBLE);
            } else {
                imageView.setVisibility(View.GONE);
            }
        }
        boolean booleanExtra = getIntent().getBooleanExtra(Constant.IS_FROM_SETTINGS, false);
        this.isFromSetting = booleanExtra;


        PrefManager prefManager2 = new PrefManager(this);
        this.prefManager = prefManager2;
        String languageCode2 = this.prefManager.getLanguageCode();
        String language = Locale.getDefault().getLanguage();
        if (languageCode2 == null || languageCode2.trim().isEmpty()) {
            try {
                languageCode2 = getResources().getConfiguration().locale.getLanguage();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        ArrayList<Language> arrayList = new ArrayList<>();
        arrayList.add(new Language("English", "en", R.drawable.country_united_america));
        arrayList.add(new Language("Hindi", "hi", R.drawable.country_india));
        arrayList.add(new Language("Spanish", "es", R.drawable.country_argentina));
        arrayList.add(new Language("Portuguese", "pt", R.drawable.country_brazil));
        arrayList.add(new Language("Indonesian", "in", R.drawable.country_indonesia));
        arrayList.add(new Language("French", "fr", R.drawable.country_canada));
        arrayList.add(new Language("Turkish", "tr", R.drawable.country_turkey));
        arrayList.add(new Language("German", "de", R.drawable.country_germany));
        arrayList.add(new Language("Bengali", "bn", R.drawable.country_bangladesh));
        arrayList.add(new Language("Filipino", "fil", R.drawable.country_philippines));
        arrayList.add(new Language("Russian", "tr", R.drawable.country_russian));
        arrayList.add(new Language("Italian", "it", R.drawable.country_italian));
        arrayList.add(new Language("Thai", "th", R.drawable.country_thai));
        arrayList.add(new Language("Polish", "pl", R.drawable.country_polish));
        arrayList.add(new Language("Dutch", "nl", R.drawable.country_dutch));
        arrayList.add(new Language("Romanian", "ro", R.drawable.country_romanian));
        Language language2 = null;
        if (languageCode2 == null || languageCode2.trim().isEmpty()) {
            z = false;
        } else {
            z = false;
            for (Language language3 : arrayList) {
                if (languageCode2.equals(language3.getLanguageCode())) {
                    language3.setSelected(true);
                    z = true;
                } else {
                    language3.setSelected(false);
                }
                if (language != null && !language.trim().isEmpty() && language.equals(language3.getLanguageCode())) {
                    language2 = language3;
                }
            }
        }
        if (!z) {
            Iterator it = arrayList.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Language language4 = (Language) it.next();
                if (language4.getLanguageCode().equals("en")) {
                    language4.setSelected(true);
                    language2 = language4;
                    break;
                }
            }
        }
        if (language2 != null) {
            arrayList.remove(language2);
            arrayList.add(0, language2);
        }
        RecyclerView recyclerView = findViewById(R.id.listLanguages);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, 1, false));
        LanguageSelectionAdapter languageSelectionAdapter = new LanguageSelectionAdapter(this, arrayList);
        recyclerView.setAdapter(languageSelectionAdapter);
        findViewById(R.id.imgRight).setOnClickListener(new View.OnClickListener() {


            public final void onClick(View view) {
                Language selectedItem = languageSelectionAdapter.getSelectedItem();
                if (selectedItem != null) {
                    prefManager.setLanguageCode(selectedItem.getLanguageCode());
                } else {
                    prefManager.setLanguageCode("");
                }
                updateLanguage();
                gotoFinalActivity();
            }
        });
    }

    public void updateLanguage() {
        String languageCode2 = this.prefManager.getLanguageCode();
        Configuration configuration = getResources().getConfiguration();
        if (languageCode2 == null || languageCode2.trim().isEmpty()) {
            try {
                languageCode2 = configuration.locale.getLanguage();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (languageCode2 != null && !languageCode2.trim().isEmpty()) {
            Locale locale = new Locale(languageCode2.toLowerCase());
            Locale.setDefault(locale);
            Configuration configuration2 = getResources().getConfiguration();
            configuration2.setLocale(locale);
            configuration.setLayoutDirection(locale);
            getResources().updateConfiguration(configuration2, getResources().getDisplayMetrics());
        }
    }

    private void gotoFinalActivity() {
        if (!this.isFromSetting) {
            launchNextScreen();
            return;
        }
        Intent intent = new Intent(this, HomeActivity.class);
        intent.setFlags(335544320);
        startActivity(intent);
        finishAffinity();
    }

    public void onBackPressed() {
        if (!this.isFromSetting) {
            launchNextScreen();
        } else {
            super.onBackPressed();
        }
    }


    public void launchContentListScreen() {
        Intent intent = new Intent(this, HomeActivity.class);
        intent.setFlags(67108864);
        startActivity(intent);
        finish();
    }



    private void launchNextScreen() {
        launchContentListScreen();

    }


    public void onPause() {
        super.onPause();
        this.isActivityPause = true;
    }


    public void onResume() {
        super.onResume();
        this.isActivityPause = false;
    }
}
