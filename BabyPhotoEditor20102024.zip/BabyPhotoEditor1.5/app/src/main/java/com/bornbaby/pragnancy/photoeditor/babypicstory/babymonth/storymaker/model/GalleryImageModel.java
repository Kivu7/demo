package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model;

public class GalleryImageModel {
    private String date;
    private String mPath;

    public GalleryImageModel(String str, String str2) {
        this.mPath = str;
        this.date = str2;
    }

    public String getPath() {
        return this.mPath;
    }

    public void setPath(String str) {
        this.mPath = str;
    }

    public String getDate() {
        return this.date;
    }

    public void setDate(String str) {
        this.date = str;
    }
}
