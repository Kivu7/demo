package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils;

import android.content.Context;
import android.content.res.Configuration;
import java.util.Locale;

public class CommonUtils {
    public static long calculateLength(CharSequence charSequence) {
        double d = 0.0d;
        for (int i = 0; i < charSequence.length(); i++) {
            char charAt = charSequence.charAt(i);
            d += (charAt <= 0 || charAt >= 127) ? 1.0d : 0.5d;
        }
        return Math.round(d);
    }

    public static void updateLanguage(Context context) {
        String languageCode = new PrefManager(context).getLanguageCode();
        Configuration configuration = context.getResources().getConfiguration();
        if (languageCode == null || languageCode.trim().isEmpty()) {
            try {
                languageCode = configuration.locale.getLanguage();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (languageCode != null && !languageCode.trim().isEmpty()) {
            Locale locale = new Locale(languageCode.toLowerCase());
            Locale.setDefault(locale);
            Configuration configuration2 = context.getResources().getConfiguration();
            configuration2.setLocale(locale);
            configuration.setLayoutDirection(locale);
            context.getResources().updateConfiguration(configuration2, context.getResources().getDisplayMetrics());
        }
    }
}
