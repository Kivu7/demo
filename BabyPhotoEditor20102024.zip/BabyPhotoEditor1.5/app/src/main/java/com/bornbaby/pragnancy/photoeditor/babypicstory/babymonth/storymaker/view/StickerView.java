package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.core.view.MotionEventCompat;

import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.R;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.StickerPropertyModel;

public class StickerView extends AppCompatImageView {
    private float MAX_SCALE;
    private float MIN_SCALE;
    private final Context context;
    private Bitmap deleteBitmap;
    private int deleteBitmapHeight;
    private int deleteBitmapWidth;
    private Rect dst_delete;
    private Rect dst_flipV;
    private Rect dst_resize;
    private Rect dst_top;
    private Bitmap flipVBitmap;
    private int flipVBitmapHeight;
    private int flipVBitmapWidth;
    private double halfDiagonalLength;
    private float height;
    private float initialRotation;
    private boolean isClickable;
    private boolean isHorizonMirror;
    private boolean isInEdit;
    private boolean isInResize;
    private boolean isInSide;
    private boolean isPointerDown;
    private float lastLength;
    private float lastRotateDegree;
    private float lastX;
    private float lastY;
    private Paint localPaint;
    private Bitmap mBitmap;
    private int mScreenWidth;
    private Matrix matrix;
    private PointF mid;
    private float oldDis;
    private OperationListener operationListener;
    private float oringinWidth;
    private Bitmap resizeBitmap;
    private int resizeBitmapHeight;
    private int resizeBitmapWidth;
    private float rotation;
    private final long stickerId;
    private Bitmap topBitmap;
    private int topBitmapHeight;
    private int topBitmapWidth;
    private float width;
    private float xLength;
    private float yLength;

    public interface OperationListener {
        void onDeleteClick();

        void onEdit(StickerView stickerView);

        void onTop(StickerView stickerView);
    }

    public StickerView(Context context) {
        super(context);
        this.isClickable = true;
        this.mid = new PointF();
        this.isPointerDown = false;
        this.isInResize = false;
        this.matrix = new Matrix();
        this.isInEdit = true;
        this.MIN_SCALE = 0.5f;
        this.MAX_SCALE = 1.2f;
        this.oringinWidth = 0.0f;
        this.isHorizonMirror = false;
        this.rotation = 0.0f;
        this.context = context;
        this.stickerId = 0L;
        init();
    }

    public StickerView(Context context, AttributeSet attributeSet, int i, Context context2) {
        super(context, attributeSet, i);
        this.isClickable = true;
        this.mid = new PointF();
        this.isPointerDown = false;
        this.isInResize = false;
        this.matrix = new Matrix();
        this.isInEdit = true;
        this.MIN_SCALE = 0.5f;
        this.MAX_SCALE = 1.2f;
        this.oringinWidth = 0.0f;
        this.isHorizonMirror = false;
        this.rotation = 0.0f;
        this.context = context2;
        this.stickerId = 0L;
        init();
    }

    public StickerView(Context context, AttributeSet attributeSet, Context context2) {
        super(context, attributeSet);
        this.isClickable = true;
        this.mid = new PointF();
        this.isPointerDown = false;
        this.isInResize = false;
        this.matrix = new Matrix();
        this.isInEdit = true;
        this.MIN_SCALE = 0.5f;
        this.MAX_SCALE = 1.2f;
        this.oringinWidth = 0.0f;
        this.isHorizonMirror = false;
        this.rotation = 0.0f;
        this.context = context2;
        this.stickerId = 0L;
        init();
    }

    private float diagonalLength(MotionEvent motionEvent) {
        return (float) Math.hypot(motionEvent.getX(0) - this.mid.x, motionEvent.getY(0) - this.mid.y);
    }

    private void init() {
        this.dst_delete = new Rect();
        this.dst_resize = new Rect();
        this.dst_flipV = new Rect();
        this.dst_top = new Rect();
        Paint paint = new Paint();
        this.localPaint = paint;
        paint.setColor(getResources().getColor(R.color.background));
        this.localPaint.setAntiAlias(true);
        this.localPaint.setDither(true);
        this.localPaint.setStyle(Paint.Style.STROKE);
        this.localPaint.setStrokeWidth(2.0f);
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        this.mScreenWidth = displayMetrics.widthPixels;
        int mScreenHeight = displayMetrics.heightPixels;
    }

    private void initBitmaps() {
        if (this.mBitmap.getWidth() >= this.mBitmap.getHeight()) {
            float f = (float) this.mScreenWidth / 8;
            if (this.mBitmap.getWidth() < f) {
                this.MIN_SCALE = 1.0f;
            } else {
                this.MIN_SCALE = (f * 1.0f) / this.mBitmap.getWidth();
            }
            int width = this.mBitmap.getWidth();
            int i = this.mScreenWidth;
            if (width > i) {
                this.MAX_SCALE = 1.0f;
            } else {
                this.MAX_SCALE = (i * 1.0f) / this.mBitmap.getWidth();
            }
        } else {
            float f2 = (float) this.mScreenWidth / 8;
            if (this.mBitmap.getHeight() < f2) {
                this.MIN_SCALE = 1.0f;
            } else {
                this.MIN_SCALE = (f2 * 1.0f) / this.mBitmap.getHeight();
            }
            int height = this.mBitmap.getHeight();
            int i2 = this.mScreenWidth;
            if (height > i2) {
                this.MAX_SCALE = 1.0f;
            } else {
                this.MAX_SCALE = (i2 * 1.0f) / this.mBitmap.getHeight();
            }
        }
        this.deleteBitmap = drawableToBitmap(this.context.getResources().getDrawable(R.drawable.sticker_close));
        this.flipVBitmap = drawableToBitmap(this.context.getResources().getDrawable(R.drawable.sticker_flip_horizontal));
        this.resizeBitmap = drawableToBitmap(this.context.getResources().getDrawable(R.drawable.sticker_zoom));
        this.topBitmap = drawableToBitmap(this.context.getResources().getDrawable(R.drawable.ic_flip_vertical));
        this.deleteBitmapWidth = (int) (this.deleteBitmap.getWidth() * 0.1f);
        this.deleteBitmapHeight = (int) (this.deleteBitmap.getHeight() * 0.1f);
        this.resizeBitmapWidth = (int) (this.resizeBitmap.getWidth() * 0.1f);
        this.resizeBitmapHeight = (int) (this.resizeBitmap.getHeight() * 0.1f);
        this.flipVBitmapWidth = (int) (this.flipVBitmap.getWidth() * 0.1f);
        this.flipVBitmapHeight = (int) (this.flipVBitmap.getHeight() * 0.1f);
        this.topBitmapWidth = (int) (this.topBitmap.getWidth() * 0.1f);
        this.topBitmapHeight = (int) (this.topBitmap.getHeight() * 0.1f);
    }

    private boolean isInBitmap(MotionEvent motionEvent) {
        float[] fArr = new float[9];
        this.matrix.getValues(fArr);
        float f = fArr[0];
        float f2 = fArr[1];
        float f3 = fArr[2];
        float f4 = fArr[3];
        float f5 = fArr[4];
        float f6 = fArr[5];
        float f7 = fArr[0];
        float width = this.mBitmap.getWidth();
        float f8 = fArr[1];
        float f9 = fArr[2];
        float f10 = fArr[3];
        float width2 = this.mBitmap.getWidth();
        float f11 = fArr[4];
        float f12 = fArr[5];
        float f13 = fArr[0];
        float f14 = fArr[1];
        float height = this.mBitmap.getHeight();
        float f15 = fArr[2];
        float f16 = fArr[3];
        float f17 = fArr[4];
        float height2 = this.mBitmap.getHeight();
        float f18 = fArr[5];
        float f19 = fArr[0];
        float width3 = this.mBitmap.getWidth();
        float f20 = fArr[1];
        float height3 = this.mBitmap.getHeight();
        return pointInRect(new float[]{(f * 0.0f) + (f2 * 0.0f) + f3, (f7 * width) + (f8 * 0.0f) + f9, (f19 * width3) + (f20 * height3) + fArr[2], (f13 * 0.0f) + (f14 * height) + f15}, new float[]{(f4 * 0.0f) + (f5 * 0.0f) + f6, (f10 * width2) + (f11 * 0.0f) + f12, (fArr[3] * this.mBitmap.getWidth()) + (fArr[4] * this.mBitmap.getHeight()) + fArr[5], (f16 * 0.0f) + (f17 * height2) + f18}, motionEvent.getX(0), motionEvent.getY(0));
    }

    private boolean isInButton(MotionEvent motionEvent, Rect rect) {
        int i = rect.left;
        int i2 = rect.right;
        int i3 = rect.top;
        int i4 = rect.bottom;
        boolean z = false;
        if (motionEvent.getX(0) >= i) {
            z = false;
            if (motionEvent.getX(0) <= i2) {
                z = false;
                if (motionEvent.getY(0) >= i3) {
                    z = false;
                    if (motionEvent.getY(0) <= i4) {
                        z = true;
                    }
                }
            }
        }
        return z;
    }

    private boolean isInResize(MotionEvent motionEvent) {
        int left = this.dst_resize.left - 20;
        int top = this.dst_resize.top - 20;
        int right = this.dst_resize.right + 20;
        int bottom = this.dst_resize.bottom + 20;
        boolean z = false;
        if (motionEvent.getX(0) >= left) {
            z = false;
            if (motionEvent.getX(0) <= right) {
                z = false;
                if (motionEvent.getY(0) >= top) {
                    z = false;
                    if (motionEvent.getY(0) <= bottom) {
                        z = true;
                    }
                }
            }
        }
        return z;
    }

    private void midDiagonalPoint(PointF pointF) {
        float[] fArr = new float[9];
        this.matrix.getValues(fArr);
        float f = fArr[0];
        float f2 = fArr[1];
        float f3 = fArr[2];
        float f4 = fArr[3];
        float f5 = fArr[4];
        float f6 = fArr[5];
        pointF.set(((((f * 0.0f) + (f2 * 0.0f)) + f3) + (((fArr[0] * this.mBitmap.getWidth()) + (fArr[1] * this.mBitmap.getHeight())) + fArr[2])) / 2.0f, ((((f4 * 0.0f) + (f5 * 0.0f)) + f6) + (((fArr[3] * this.mBitmap.getWidth()) + (fArr[4] * this.mBitmap.getHeight())) + fArr[5])) / 2.0f);
    }

    private void midPointToStartPoint(MotionEvent motionEvent) {
        float[] fArr = new float[9];
        this.matrix.getValues(fArr);
        float f = fArr[0];
        float f2 = fArr[1];
        float f3 = fArr[2];
        float f4 = fArr[3];
        float f5 = fArr[4];
        float f6 = fArr[5];
        this.mid.set(((((f * 0.0f) + (f2 * 0.0f)) + f3) + motionEvent.getX(0)) / 2.0f, ((((f4 * 0.0f) + (f5 * 0.0f)) + f6) + motionEvent.getY(0)) / 2.0f);
    }

    private boolean pointInRect(float[] fArr, float[] fArr2, float f, float f2) {
        double hypot = Math.hypot(fArr[0] - fArr[1], fArr2[0] - fArr2[1]);
        double hypot2 = Math.hypot(fArr[1] - fArr[2], fArr2[1] - fArr2[2]);
        double hypot3 = Math.hypot(fArr[3] - fArr[2], fArr2[3] - fArr2[2]);
        double hypot4 = Math.hypot(fArr[0] - fArr[3], fArr2[0] - fArr2[3]);
        double hypot5 = Math.hypot(f - fArr[0], f2 - fArr2[0]);
        double hypot6 = Math.hypot(f - fArr[1], f2 - fArr2[1]);
        double hypot7 = Math.hypot(f - fArr[2], f2 - fArr2[2]);
        double hypot8 = Math.hypot(f - fArr[3], f2 - fArr2[3]);
        double d = ((hypot + hypot5) + hypot6) / 2.0d;
        double d2 = ((hypot2 + hypot6) + hypot7) / 2.0d;
        double d3 = ((hypot3 + hypot7) + hypot8) / 2.0d;
        double d4 = ((hypot4 + hypot8) + hypot5) / 2.0d;
        return Math.abs((hypot * hypot2) - (((Math.sqrt((((d - hypot) * d) * (d - hypot5)) * (d - hypot6)) + Math.sqrt((((d2 - hypot2) * d2) * (d2 - hypot6)) * (d2 - hypot7))) + Math.sqrt((((d3 - hypot3) * d3) * (d3 - hypot7)) * (d3 - hypot8))) + Math.sqrt((((d4 - hypot4) * d4) * (d4 - hypot8)) * (d4 - hypot5)))) < 0.5d;
    }

    private float rotationToStartPoint(MotionEvent motionEvent) {
        float[] fArr = new float[9];
        this.matrix.getValues(fArr);
        float f = fArr[0];
        float f2 = fArr[1];
        float f3 = fArr[2];
        float f4 = fArr[3];
        float f5 = fArr[4];
        return (float) Math.toDegrees(Math.atan2(motionEvent.getY(0) - (((f4 * 0.0f) + (f5 * 0.0f)) + fArr[5]), motionEvent.getX(0) - (((f * 0.0f) + (f2 * 0.0f)) + f3)));
    }

    private void setDiagonalLength() {
        this.halfDiagonalLength = Math.hypot(this.mBitmap.getWidth(), this.mBitmap.getHeight()) / 2.0d;
    }

    private float spacing(MotionEvent motionEvent) {
        if (motionEvent.getPointerCount() == 2) {
            float x = motionEvent.getX(0) - motionEvent.getX(1);
            float y = motionEvent.getY(0) - motionEvent.getY(1);
            return (float) Math.sqrt((x * x) + (y * y));
        }
        return 0.0f;
    }

    public StickerPropertyModel calculate(StickerPropertyModel stickerPropertyModel) {
        float[] fArr = new float[9];
        this.matrix.getValues(fArr);
        float f = fArr[2];
        float f2 = fArr[5];
        float f3 = fArr[0];
        float f4 = fArr[3];
        float sqrt = (float) Math.sqrt((double) ((f3 * f3) + (f4 * f4)));
        float round = (float) Math.round(Math.atan2((double) fArr[1], (double) fArr[0]) * 57.29577951308232d);
        PointF pointF = new PointF();
        midDiagonalPoint(pointF);
        float f5 = pointF.x;
        float f6 = pointF.y;
        stickerPropertyModel.setDegree((float) Math.toRadians((double) round));
        stickerPropertyModel.setScaling((((float) this.mBitmap.getWidth()) * sqrt) / ((float) this.mScreenWidth));
        stickerPropertyModel.setxLocation(f5 / ((float) this.mScreenWidth));
        stickerPropertyModel.setyLocation(f6 / ((float) this.mScreenWidth));
        stickerPropertyModel.setStickerId(this.stickerId);
        if (this.isHorizonMirror) {
            stickerPropertyModel.setHorizonMirror(1);
        } else {
            stickerPropertyModel.setHorizonMirror(2);
        }
        return stickerPropertyModel;
    }

    public Bitmap drawableToBitmap(Drawable drawable) {
        if (drawable instanceof BitmapDrawable) {
            return ((BitmapDrawable) drawable).getBitmap();
        }
        Bitmap createBitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(createBitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);
        return createBitmap;
    }

    public void flipX() {
        PointF pointF = new PointF();
        midDiagonalPoint(pointF);
        this.matrix.postScale(-1.0f, 1.0f, pointF.x, pointF.y);
        invalidate();
    }

    public void flipY() {
        PointF pointF = new PointF();
        midDiagonalPoint(pointF);
        this.matrix.postScale(1.0f, -1.0f, pointF.x, pointF.y);
        invalidate();
    }

    public float getH() {
        return this.height;
    }

    @Override
    public float getRotation() {
        return this.lastRotateDegree == 0.0f ? this.initialRotation : -this.rotation;
    }

    public float getW() {
        return this.width;
    }

    public float getx() {
        return this.xLength;
    }

    public float gety() {
        return this.yLength;
    }

    @Override // android.widget.ImageView, android.view.View
    protected void onDraw(Canvas canvas) {
        if (this.mBitmap != null) {
            float[] fArr = new float[9];
            this.matrix.getValues(fArr);
            this.xLength = fArr[2];
            this.yLength = fArr[5];
            float f = fArr[2] + (fArr[0] * 0.0f) + (fArr[1] * 0.0f);
            float f2 = (fArr[3] * 0.0f) + (fArr[4] * 0.0f) + fArr[5];
            float f3 = (fArr[0] * this.mBitmap.getWidth()) + (fArr[1] * 0.0f) + fArr[2];
            float width = (fArr[3] * this.mBitmap.getWidth()) + (fArr[4] * 0.0f) + fArr[5];
            float height = (fArr[0] * 0.0f) + (fArr[1] * this.mBitmap.getHeight()) + fArr[2];
            float f6 = (fArr[3] * 0.0f) + (fArr[4] * this.mBitmap.getHeight()) + fArr[5];
            float width2 = fArr[2] + (fArr[0] * this.mBitmap.getWidth()) + (fArr[1] * this.mBitmap.getHeight());
            float width3 = (fArr[3] * this.mBitmap.getWidth()) + (fArr[4] * this.mBitmap.getHeight()) + fArr[5];
            canvas.save();
            canvas.drawBitmap(this.mBitmap, this.matrix, null);
            this.rotation = (float) Math.round(Math.atan2(fArr[1], fArr[0]) * 57.29577951308232d);
            this.dst_delete.left = (int) (f3 - (this.deleteBitmapWidth / 2));
            this.dst_delete.right = (int) (f3 + (this.deleteBitmapWidth / 2));
            this.dst_delete.top = (int) (width - (this.deleteBitmapHeight / 2));
            this.dst_delete.bottom = (int) ((this.deleteBitmapHeight / 2) + width);
            this.dst_resize.left = (int) (width2 - (this.resizeBitmapWidth / 2));
            this.dst_resize.right = (int) ((this.resizeBitmapWidth / 2) + width2);
            this.dst_resize.top = (int) (width3 - (this.resizeBitmapHeight / 2));
            this.dst_resize.bottom = (int) ((this.resizeBitmapHeight / 2) + width3);
            this.dst_top.left = (int) (f - (this.topBitmapWidth / 2));
            this.dst_top.right = (int) ((this.topBitmapWidth / 2) + f);
            this.dst_top.top = (int) (f2 - (this.topBitmapHeight / 2));
            this.dst_top.bottom = (int) ((this.topBitmapHeight / 2) + f2);
            this.dst_flipV.left = (int) (height - (this.flipVBitmapWidth / 2));
            this.dst_flipV.right = (int) ((this.flipVBitmapWidth / 2) + height);
            this.dst_flipV.top = (int) (f6 - (this.flipVBitmapHeight / 2));
            this.dst_flipV.bottom = (int) (f6 + (this.flipVBitmapHeight / 2));
            if (this.isInEdit) {
                canvas.drawLine(f, f2, f3, width, this.localPaint);
                canvas.drawLine(f3, width, width2, width3, this.localPaint);
                canvas.drawLine(height, f6, width2, width3, this.localPaint);
                canvas.drawLine(height, f6, f, f2, this.localPaint);
                if (this.isClickable) {
                    canvas.drawBitmap(this.deleteBitmap, (Rect) null, this.dst_delete, (Paint) null);
                    canvas.drawBitmap(this.resizeBitmap, (Rect) null, this.dst_resize, (Paint) null);
                    canvas.drawBitmap(this.flipVBitmap, (Rect) null, this.dst_flipV, (Paint) null);
                    canvas.drawBitmap(this.topBitmap, (Rect) null, this.dst_top, (Paint) null);
                }
                canvas.restore();
            }
        }
    }

    public boolean onTouchEvent(MotionEvent var1) {
        boolean var11;
        OperationListener var14;
        label111: {
            int var10 = MotionEventCompat.getActionMasked(var1);
            var11 = this.isClickable;
            boolean var12 = true;
            if (var11) {
                float var7 = 1.0F;
                if (var10 != 0) {
                    if (var10 != 1) {
                        if (var10 == 2) {
                            float var6;
                            if (this.isPointerDown) {
                                var6 = this.spacing(var1);
                                if (var6 != 0.0F && !(var6 < 20.0F)) {
                                    var6 = (var6 / this.oldDis - 1.0F) * 0.09F + 1.0F;
                                } else {
                                    var6 = 1.0F;
                                }

                                float var8;
                                label116: {
                                    float var9 = (float)Math.abs(this.dst_flipV.left - this.dst_resize.left) * var6 / this.oringinWidth;
                                    if (var9 <= this.MIN_SCALE) {
                                        var8 = var7;
                                        if (var6 < 1.0F) {
                                            break label116;
                                        }
                                    }

                                    if (var9 >= this.MAX_SCALE && var6 > 1.0F) {
                                        var8 = var7;
                                    } else {
                                        this.lastLength = this.diagonalLength(var1);
                                        var8 = var6;
                                    }
                                }

                                this.matrix.postScale(var8, var8, this.mid.x, this.mid.y);
                                this.height *= var8;
                                this.width *= var8;
                                this.invalidate();
                                var11 = var12;
                            } else if (this.isInResize) {
                                label120: {
                                    this.matrix.postRotate((this.rotationToStartPoint(var1) - this.lastRotateDegree) * 3.0F, this.mid.x, this.mid.y);
                                    this.lastRotateDegree = this.rotationToStartPoint(var1);
                                    var6 = this.diagonalLength(var1) / this.lastLength;
                                    double var2 = (double)this.diagonalLength(var1);
                                    double var4 = this.halfDiagonalLength;
                                    Double.isNaN(var2);
                                    if (!(var2 / var4 <= (double)this.MIN_SCALE) || !(var6 < 1.0F)) {
                                        var2 = (double)this.diagonalLength(var1);
                                        var4 = this.halfDiagonalLength;
                                        Double.isNaN(var2);
                                        if (!(var2 / var4 >= (double)this.MAX_SCALE) || !(var6 > 1.0F)) {
                                            this.lastLength = this.diagonalLength(var1);
                                            break label120;
                                        }
                                    }

                                    var6 = var7;
                                    if (!this.isInResize(var1)) {
                                        this.isInResize = false;
                                        var6 = var7;
                                    }
                                }

                                this.matrix.postScale(var6, var6, this.mid.x, this.mid.y);
                                this.height *= var6;
                                this.width *= var6;
                                this.invalidate();
                                var11 = var12;
                            } else {
                                var11 = var12;
                                if (this.isInSide) {
                                    var6 = var1.getX(0);
                                    var7 = var1.getY(0);
                                    this.matrix.postTranslate(var6 - this.lastX, var7 - this.lastY);
                                    this.lastX = var6;
                                    this.lastY = var7;
                                    this.invalidate();
                                    var11 = var12;
                                }
                            }
                            break label111;
                        }

                        if (var10 != 3) {
                            if (var10 != 5) {
                                var11 = var12;
                            } else {
                                if (this.spacing(var1) > 20.0F) {
                                    this.oldDis = this.spacing(var1);
                                    this.isPointerDown = true;
                                    this.midPointToStartPoint(var1);
                                } else {
                                    this.isPointerDown = false;
                                }

                                this.isInSide = false;
                                this.isInResize = false;
                                var11 = var12;
                            }
                            break label111;
                        }
                    }

                    this.isInResize = false;
                    this.isInSide = false;
                    this.isPointerDown = false;
                    var11 = var12;
                    break label111;
                }

                if (this.isInButton(var1, this.dst_delete)) {
                    var14 = this.operationListener;
                    var11 = var12;
                    if (var14 != null) {
                        var14.onDeleteClick();
                        var11 = var12;
                    }
                    break label111;
                }

                if (this.isInResize(var1)) {
                    this.isInResize = true;
                    this.lastRotateDegree = this.rotationToStartPoint(var1);
                    this.midPointToStartPoint(var1);
                    this.lastLength = this.diagonalLength(var1);
                    var11 = var12;
                    break label111;
                }

                PointF var13;
                if (this.isInButton(var1, this.dst_flipV)) {
                    var13 = new PointF();
                    this.midDiagonalPoint(var13);
                    this.matrix.postScale(-1.0F, 1.0F, var13.x, var13.y);
                    this.invalidate();
                    var11 = var12;
                    break label111;
                }

                if (this.isInButton(var1, this.dst_top)) {
                    var13 = new PointF();
                    this.midDiagonalPoint(var13);
                    this.matrix.postScale(1.0F, -1.0F, var13.x, var13.y);
                    this.invalidate();
                    var11 = var12;
                    break label111;
                }

                if (this.isInBitmap(var1)) {
                    this.isInSide = true;
                    this.lastX = var1.getX(0);
                    this.lastY = var1.getY(0);
                    var11 = var12;
                    break label111;
                }
            }

            var11 = false;
        }

        if (var11) {
            var14 = this.operationListener;
            if (var14 != null) {
                var14.onEdit(this);
            }
        }

        return var11;
    }


    public void setBitmap(Bitmap bitmap, float f, float f2, float f3) {
        this.matrix.reset();
        float[] fArr = new float[9];
        this.matrix.getValues(fArr);
        float f4 = fArr[2];
        float f5 = fArr[5];
        this.mBitmap = bitmap;
        setDiagonalLength();
        initBitmaps();
        int width = this.mBitmap.getWidth();
        this.mBitmap.getHeight();
        this.oringinWidth = width;
        this.matrix.postRotate(f3);
        this.matrix.postScale(1.0f, 1.0f);
        this.matrix.postTranslate(f, f2);
        invalidate();
    }

    public void setImageBitmap(Bitmap bitmap, float f, float f2, float f3) {
        this.initialRotation = f3;
        this.width = bitmap.getWidth();
        this.height = bitmap.getHeight();
        setBitmap(bitmap, f, f2, f3);
    }

    public void setInEdit(boolean z) {
        this.isInEdit = z;
        invalidate();
    }

    public void setOperationListener(OperationListener operationListener) {
        this.operationListener = operationListener;
    }

    public void setStickerClickable(boolean z) {
        this.isClickable = z;
        invalidate();
    }
}