package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;

public class Photo implements Serializable {
    @SerializedName("description")
    private String description;
    @SerializedName("photo_auto_id")
    private String photoAutoId;
    @SerializedName("title")
    private String title;
    @SerializedName("url_o")
    private String urlO;

    public String getPhotoAutoId() {
        return this.photoAutoId;
    }

    public void setPhotoAutoId(String str) {
        this.photoAutoId = str;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String str) {
        this.title = str;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String str) {
        this.description = str;
    }

    public String getUrlO() {
        return this.urlO;
    }

    public void setUrlO(String str) {
        this.urlO = str;
    }
}
