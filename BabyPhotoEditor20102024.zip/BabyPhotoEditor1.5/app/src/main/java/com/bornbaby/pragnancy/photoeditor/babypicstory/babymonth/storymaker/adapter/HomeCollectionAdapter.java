package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.adapter;

import android.app.Activity;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.R;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.activity.DesignActivity;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.activity.HomeActivity;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import java.util.ArrayList;

public class HomeCollectionAdapter extends RecyclerView.Adapter<HomeCollectionAdapter.ViewHolder> {

    public ArrayList<String> images;

    public HomeActivity mActivity;

    public onImageClick mOnImageClick;

    public onLongImageClick mOnLongImageClick;

    public interface onImageClick {
        void onImageClick(String str);
    }

    public interface onLongImageClick {
        void onLongImageClick(String str);
    }

    public HomeCollectionAdapter(HomeActivity activity, ArrayList<String> arrayList, onImageClick onimageclick, onLongImageClick onlongimageclick) {
        this.mActivity = activity;
        this.images = arrayList;
        this.mOnImageClick = onimageclick;
        this.mOnLongImageClick = onlongimageclick;
    }

    @NonNull
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.home_collection_img, (ViewGroup) null));
    }

    public void onBindViewHolder(final ViewHolder viewHolder, int i) {
        Glide.with(this.mActivity).load(this.images.get(viewHolder.getAdapterPosition())).into(viewHolder.mImageView);


        viewHolder.mImageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                mOnImageClick.onImageClick(images.get(viewHolder.getAdapterPosition()));
            }
        });
        viewHolder.mImageView.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View view) {

                mOnLongImageClick.onLongImageClick(images.get(viewHolder.getAdapterPosition()));
                return true;
            }
        });
    }

    public int getItemCount() {
        return this.images.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView mImageView;


        public ViewHolder(View view) {
            super(view);
            this.mImageView = view.findViewById(R.id.singleGalleryImg);

            DisplayMetrics displayMetrics = new DisplayMetrics();
            mActivity.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
            int dimension = (displayMetrics.widthPixels / 2) - ((int) mActivity.getResources().getDimension(R.dimen._2sdp));
            this.mImageView.getLayoutParams().width = dimension;
            this.mImageView.getLayoutParams().height = dimension;
        }
    }


}
