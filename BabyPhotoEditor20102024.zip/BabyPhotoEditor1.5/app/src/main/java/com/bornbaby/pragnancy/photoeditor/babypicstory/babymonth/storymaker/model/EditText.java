package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model;

import java.util.ArrayList;

public class EditText {
    ArrayList<Integer> colorList;
    ArrayList<String> fontList;

    public EditText(ArrayList<Integer> arrayList, ArrayList<String> arrayList2) {
        this.colorList = arrayList;
        this.fontList = arrayList2;
    }

    public ArrayList<Integer> getColorList() {
        return this.colorList;
    }

    public void setColorList(ArrayList<Integer> arrayList) {
        this.colorList = arrayList;
    }

    public ArrayList<String> getFontList() {
        return this.fontList;
    }

    public void setFontList(ArrayList<String> arrayList) {
        this.fontList = arrayList;
    }
}
