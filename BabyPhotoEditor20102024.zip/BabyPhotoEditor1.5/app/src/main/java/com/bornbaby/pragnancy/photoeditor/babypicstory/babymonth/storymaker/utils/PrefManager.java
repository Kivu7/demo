package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class PrefManager {
    public static String IS_PRIVACY_ACCEPTED = "is_privacy_accepted";
    public static String SELECTED_LANGUAGE = "selected_language";
    static PrefManager prefManager;
    private SharedPreferences.Editor editor;
    private SharedPreferences sharedPreferences;

    public static PrefManager getInstance(Context context2) {
        if (prefManager == null) {
            prefManager = new PrefManager(context2);
        }
        return prefManager;
    }

    public PrefManager(Context context2) {
        SharedPreferences sharedPreferences2 = context2.getSharedPreferences("baby_pics", 0);
        this.sharedPreferences = sharedPreferences2;
        this.editor = sharedPreferences2.edit();
    }

    public void setPrivacyPolicyAccepted(Boolean bool) {
        this.editor.putBoolean(IS_PRIVACY_ACCEPTED, bool).commit();
    }

    public boolean isPrivacyPolicyAccepted() {
        return this.sharedPreferences.getBoolean(IS_PRIVACY_ACCEPTED, false);
    }

    public String getLanguageCode() {
        return this.sharedPreferences.getString(SELECTED_LANGUAGE, "");
    }

    public void setLanguageCode(String str) {
        this.editor.putString(SELECTED_LANGUAGE, str).commit();
    }
}
