package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model;

import android.net.Uri;

import java.util.ArrayList;
import java.util.Objects;

public class ImageDir {
    ArrayList<ImageInfo> arrayList = new ArrayList<>();
    String bucketId;
    String bucketPath;
    long count = 1;
    String dirName;
    long size;
    Uri uri = Uri.parse("");

    public ImageDir() {
    }

    public ImageDir(String str, String str2) {
        this.dirName = str;
        this.bucketId = str2;
    }

    public ImageDir(String str) {
        this.dirName = str;
    }

    public void addInfoVideo(ImageInfo imageInfo) {
        this.arrayList.add(imageInfo);
    }

    public ArrayList<ImageInfo> getArrayList() {
        return this.arrayList;
    }

    public void setArrayList(ArrayList<ImageInfo> arrayList2) {
        this.arrayList = arrayList2;
    }

    public String getDirName() {
        return this.dirName;
    }

    public void setDirName(String str) {
        this.dirName = str;
    }

    public Uri getUri() {
        return this.uri;
    }

    public void setUri(Uri uri2) {
        this.uri = uri2;
    }

    public long getCount() {
        return this.count;
    }

    public String getCountS() {
        return this.count + "";
    }

    public void setCount() {
        this.count++;
    }

    public void setCount(long j) {
        this.count = j;
    }

    public long getSize() {
        return this.size;
    }

    public void setSize(long j) {
        this.size = j;
    }

    public String getBucketId() {
        return this.bucketId;
    }

    public void setBucketId(String str) {
        this.bucketId = str;
    }

    public String getBucketPath() {
        return this.bucketPath;
    }

    public void setBucketPath(String str) {
        this.bucketPath = str;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        return Objects.equals(getBucketId(), ((ImageDir) obj).getBucketId());
    }
}
