package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.activity;

import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesResponseListener;
import com.android.billingclient.api.QueryPurchasesParams;

import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.Constants;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.EPreferences;

import java.util.Iterator;
import java.util.List;
import java.util.Objects;


public   class SplashActivityBilling implements BillingClientStateListener {
    final  BillingClient billingClient;
    final  SplashScreen this$0;

    @Override  
    public void onBillingServiceDisconnected() {
    }

    public SplashActivityBilling(BillingClient billingClient, SplashScreen splashActivity) {
        this.billingClient = billingClient;
        this.this$0 = splashActivity;
    }

    @Override
    public void onBillingSetupFinished(BillingResult billingResult) {

        if (billingResult.getResponseCode() != 0) {
            return;
        }
        BillingClient billingClient = this.billingClient;
        QueryPurchasesParams build = QueryPurchasesParams.newBuilder().setProductType("subs").build();
         billingClient.queryPurchasesAsync(build, new PurchasesResponseListener() {
            @Override
            public final void onQueryPurchasesResponse(BillingResult billingResult2, List list) {
                SplashActivityBilling.onBillingSetupFinished$lambda$0(this$0, billingResult2, list);
            }
        });
    }


    public static final void onBillingSetupFinished$lambda$0(SplashScreen this$0, BillingResult billingResult2, List inappList) {

        if (billingResult2.getResponseCode() == 0) {
            Iterator it = inappList.iterator();
            while (it.hasNext()) {
                Purchase purchase = (Purchase) it.next();
                String str = purchase.getProducts().get(0);
                if (purchase.getPurchaseState() == 1 && (str.equals(Constants.KEY_SUB_1) || str.equals(Constants.KEY_SUB_2) || str.equals(Constants.KEY_SUB_3))) {
                    Objects.requireNonNull(EPreferences.getInstance(this$0)).setString(EPreferences.PREF_IS_PERCHASE, "1");
                    break;
                }
            }
        }
}
}