package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;


import androidx.recyclerview.widget.RecyclerView;


import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.R;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.ImageDir;
import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class AlbumAdapter extends RecyclerView.Adapter<AlbumAdapter.ViewHolder> {
    Context context;
    ArrayList<ImageDir> imageDirs;
    OnAlbum onAlbum;

    public interface OnAlbum {
        void AlbumClick(int i);
    }

    public AlbumAdapter(Context context2, ArrayList<ImageDir> arrayList, OnAlbum onAlbum2) {
        this.context = context2;
        this.imageDirs = arrayList;
        this.onAlbum = onAlbum2;
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_audio_folder, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        Glide.with(this.context).load(this.imageDirs.get(i).getUri()).into(viewHolder.img);
        viewHolder.txtAudioName.setText(this.imageDirs.get(i).getDirName());
        viewHolder.txtTotalAudios.setText("" + this.imageDirs.get(i).getCountS());
    }

    public int getItemCount() {
        return this.imageDirs.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {


        LinearLayout llMain;
        TextView txtAudioName;
        TextView txtTotalAudios;
        ImageView img;
        public ViewHolder(View view) {
            super(view);
            llMain=view.findViewById(R.id.llMain);
            txtTotalAudios=view.findViewById(R.id.txtTotalAudios);
            txtAudioName=view.findViewById(R.id.txtAudioName);
            img=view.findViewById(R.id.img);
              llMain.setOnClickListener(new View.OnClickListener( ) {
                public void onClick(View view) {
                    onAlbum.AlbumClick(ViewHolder.this.getAdapterPosition());
                }
            });
        }
    }
}
