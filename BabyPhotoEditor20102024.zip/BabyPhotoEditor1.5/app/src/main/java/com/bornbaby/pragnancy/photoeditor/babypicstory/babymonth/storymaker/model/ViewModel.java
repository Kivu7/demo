package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model;

import android.graphics.Bitmap;
import android.view.View;

public class ViewModel {
    private String id;
    private boolean isClickable = true;
    private boolean isVisible = true;
    private Bitmap mBitmap;
    private View mView;

    public ViewModel(View view, Bitmap bitmap) {
        this.mView = view;
        this.mBitmap = bitmap;
    }

    public View getView() {
        return this.mView;
    }

    public void setView(View view) {
        this.mView = view;
    }

    public Bitmap getBitmap() {
        return this.mBitmap;
    }

    public void setBitmap(Bitmap bitmap) {
        this.mBitmap = bitmap;
    }

    public boolean isClickable() {
        return this.isClickable;
    }

    public void setClickable(boolean z) {
        this.isClickable = z;
    }

    public boolean isVisible() {
        return this.isVisible;
    }

    public void setVisible(boolean z) {
        this.isVisible = z;
    }
}
