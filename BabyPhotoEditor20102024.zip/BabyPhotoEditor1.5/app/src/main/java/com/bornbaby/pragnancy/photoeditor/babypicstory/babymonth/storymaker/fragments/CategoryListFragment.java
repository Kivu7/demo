package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.fragments;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;

import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.R;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.activity.TemplateListActivity;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.activity.SelectImageActivity;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.adapter.ThumbListAdapter;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.TemplateJason.RootTemplate;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.Constant;

import java.util.ArrayList;

public class CategoryListFragment extends Fragment {
    private static final String ARG_PARAM = "key";
    FragmentActivity fragmentActivity;
    
    public boolean loading = true;
    private ArrayList<RootTemplate> mPortraitTemplates = new ArrayList<>();
    private RecyclerView mRecyclerView;
    
    public ArrayList<RootTemplate> mRootTemplatesTemp = new ArrayList<>();
    private ThumbListAdapter mThumbListAdapter;
    
    public int pastVisiblesItems;
    private int subType;
    
    public int totalItemCount;
    private int type;
    private View view;
    
    public int visibleItemCount;

    public CategoryListFragment newInstance(int i) {
        CategoryListFragment categoryListFragment = new CategoryListFragment();
        Bundle bundle = new Bundle();
        bundle.putInt(ARG_PARAM, i);
        categoryListFragment.setArguments(bundle);
        return categoryListFragment;
    }
    public   boolean isNetworkAvailable(Context lCon) {
        ConnectivityManager cm = null;
        try {
            cm = (ConnectivityManager) lCon.getSystemService(Context.CONNECTIVITY_SERVICE);
        } catch (Exception e) {

        }

        return cm.getActiveNetworkInfo() != null;
    }
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (getActivity() != null) {
            this.fragmentActivity = getActivity();
        }
        if (getArguments() != null) {
            this.type = getArguments().getInt(ARG_PARAM);
        }
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.view = layoutInflater.inflate(R.layout.category_item_list_fragment, viewGroup, false);
        int i = this.type;
        if (i == 1) {
            this.mPortraitTemplates = Constant.category.get("general");
            this.subType = 1;
        } else if (i == 2) {
            this.subType = 2;
            this.mPortraitTemplates = Constant.category.get("frame");
        } else if (i == 3) {
            this.subType = 1;
            this.mPortraitTemplates = Constant.category.get("collage");
        }
        initView();
        initAdapter();
        return this.view;
    }

    private void initAdapter() {
        if (this.mPortraitTemplates != null) {
            for (int i = 0; i < 20; i++) {
                this.mRootTemplatesTemp.add(this.mPortraitTemplates.get(i));
            }
        }
        ArrayList<RootTemplate> arrayList = this.mRootTemplatesTemp;
        if (arrayList != null && arrayList.size() != 0) {
            this.mThumbListAdapter = new ThumbListAdapter(this.fragmentActivity, this.mRootTemplatesTemp, new ThumbListAdapter.onThumbClickInterface() {
                public final void onThumbClick(RootTemplate rootTemplate) {
                    if (isNetworkAvailable(fragmentActivity)) {
                        Intent intent = new Intent(fragmentActivity, SelectImageActivity.class);
                        intent.putExtra( "from", "Category");
                        intent.putExtra( "forCrop", "Category");
                        intent.putExtra("rootTemplate", rootTemplate);
                        fragmentActivity.startActivity(intent);
                        return;
                    }
                    FragmentActivity fragmentActivity2 = fragmentActivity;
                    Toast.makeText(fragmentActivity2, fragmentActivity2.getString(R.string.internet_error), Toast.LENGTH_SHORT).show();
                }
            }, this.subType);
            final GridLayoutManager gridLayoutManager = new GridLayoutManager(this.fragmentActivity, 2, 1, false);
            gridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
                public int getSpanSize(int i) {
                    return ((RootTemplate) mRootTemplatesTemp.get(i)).getType().equals("ad") ? 2 : 1;
                }
            });
            this.mRecyclerView.setLayoutManager(gridLayoutManager);
            this.mRecyclerView.setAdapter(this.mThumbListAdapter);
            this.mRecyclerView.setHasFixedSize(true);
            this.mRecyclerView.setItemViewCacheSize(this.mPortraitTemplates.size());
            ((SimpleItemAnimator) this.mRecyclerView.getItemAnimator()).setSupportsChangeAnimations(false);
            this.mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
                public void onScrolled(@NonNull RecyclerView recyclerView, int i, int i2) {
                    super.onScrolled(recyclerView, i, i2);
                    if (i2 > 0) {
                         visibleItemCount = gridLayoutManager.getChildCount();
                          totalItemCount = gridLayoutManager.getItemCount();
                          pastVisiblesItems = gridLayoutManager.findFirstVisibleItemPosition();
                        if (loading && visibleItemCount + pastVisiblesItems >= totalItemCount - 4) {
                              loading = false;
                            TemplateListActivity.customDialog.dismiss();
                        }
                        if (visibleItemCount + pastVisiblesItems >= totalItemCount - 4 && !loading) {
                            loadData();
                            loading = true;
                        }
                    }
                }
            });
        }
    }


    
    public void loadData() {
        int size = this.mRootTemplatesTemp.size();
        int i = size + 20;
        if (i >= this.mPortraitTemplates.size()) {
            i = this.mPortraitTemplates.size() - size;
        }
        for (int i2 = size; i2 < i; i2++) {
            this.mRootTemplatesTemp.add(this.mPortraitTemplates.get(i2));
        }
        this.mThumbListAdapter.notifyItemRangeChanged(size, this.mRootTemplatesTemp.size());
    }

    private void initView() {
        this.mRecyclerView = this.view.findViewById(R.id.categoryListRecycle);
    }

    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.fragmentActivity = (FragmentActivity) context;
    }

    public void refreshAds() {
        ArrayList<RootTemplate> arrayList;
        if (this.mRecyclerView != null && this.mThumbListAdapter != null && (arrayList = this.mRootTemplatesTemp) != null && arrayList.size() > 0) {
            this.mThumbListAdapter.refreshAds();
        }
    }
}
