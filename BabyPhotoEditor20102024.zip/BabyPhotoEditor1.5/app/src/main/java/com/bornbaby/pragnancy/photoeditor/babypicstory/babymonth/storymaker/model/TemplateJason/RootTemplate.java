package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.TemplateJason;

import java.io.Serializable;
import java.util.List;

public class RootTemplate implements Serializable {
    private List<String> allowed_country_list;
    private int app_day_of_month;
    private int app_month;
    private Double aspect_ratio;
    private String baby_gender;
    private String canonical_name;
    private String content_identifier;
    private String created_date;
    private boolean freemium_locked;
    private int general_order;
    private boolean great_images;
    private int id;
    private List<Images> images;
    private int light_angle;
    private String overlay_image;
    private Overlay_image_coordinate overlay_image_coordinate;
    private String overlay_image_thumbnail;
    private String presentation_style;
    private String preview_thumbnail;
    private List<String> prop_categories;
    private List<String> search_tags;
    private Starter_data starter_data;
    private String subtitle;
    private int subtype;
    private List<String> tags;
    private List<TempleteLayer> template_layers;
    private String title;
    private String type;
    private boolean unlisted;
    private String updated_date;

    public String getPreview_thumbnail() {
        return this.preview_thumbnail;
    }

    public void setPreview_thumbnail(String str) {
        this.preview_thumbnail = str;
    }

    public void setId(int i) {
        this.id = i;
    }

    public int getId() {
        return this.id;
    }

    public void setContent_identifier(String str) {
        this.content_identifier = str;
    }

    public String getContent_identifier() {
        return this.content_identifier;
    }

    public void setCanonical_name(String str) {
        this.canonical_name = str;
    }

    public String getCanonical_name() {
        return this.canonical_name;
    }

    public void setType(String str) {
        this.type = str;
    }

    public String getType() {
        return this.type;
    }

    public void setSubtype(int i) {
        this.subtype = i;
    }

    public int getSubtype() {
        return this.subtype;
    }

    public void setTags(List<String> list) {
        this.tags = list;
    }

    public List<String> getTags() {
        return this.tags;
    }

    public void setSearch_tags(List<String> list) {
        this.search_tags = list;
    }

    public List<String> getSearch_tags() {
        return this.search_tags;
    }

    public void setBaby_gender(String str) {
        this.baby_gender = str;
    }

    public String getBaby_gender() {
        return this.baby_gender;
    }

    public void setGreat_images(boolean z) {
        this.great_images = z;
    }

    public boolean getGreat_images() {
        return this.great_images;
    }

    public void setUnlisted(boolean z) {
        this.unlisted = z;
    }

    public boolean getUnlisted() {
        return this.unlisted;
    }

    public void setGeneral_order(int i) {
        this.general_order = i;
    }

    public int getGeneral_order() {
        return this.general_order;
    }

    public void setFreemium_locked(boolean z) {
        this.freemium_locked = z;
    }

    public boolean getFreemium_locked() {
        return this.freemium_locked;
    }

    public void setPresentation_style(String str) {
        this.presentation_style = str;
    }

    public String getPresentation_style() {
        return this.presentation_style;
    }

    public void setTitle(String str) {
        this.title = str;
    }

    public String getTitle() {
        return this.title;
    }

    public void setSubtitle(String str) {
        this.subtitle = str;
    }

    public String getSubtitle() {
        return this.subtitle;
    }

    public void setAspect_ratio(Double d) {
        this.aspect_ratio = d;
    }

    public Double getAspect_ratio() {
        return this.aspect_ratio;
    }

    public void setOverlay_image(String str) {
        this.overlay_image = str;
    }

    public String getOverlay_image() {
        return this.overlay_image;
    }

    public void setOverlay_image_thumbnail(String str) {
        this.overlay_image_thumbnail = str;
    }

    public String getOverlay_image_thumbnail() {
        return this.overlay_image_thumbnail;
    }

    public void setOverlay_image_coordinate(Overlay_image_coordinate overlay_image_coordinate2) {
        this.overlay_image_coordinate = overlay_image_coordinate2;
    }

    public Overlay_image_coordinate getOverlay_image_coordinate() {
        return this.overlay_image_coordinate;
    }

    public void setLight_angle(int i) {
        this.light_angle = i;
    }

    public int getLight_angle() {
        return this.light_angle;
    }

    public void setImages(List<Images> list) {
        this.images = list;
    }

    public List<Images> getImages() {
        return this.images;
    }

    public void setTemplate_layers(List<TempleteLayer> list) {
        this.template_layers = list;
    }

    public List<TempleteLayer> getTemplate_layers() {
        return this.template_layers;
    }

    public void setProp_categories(List<String> list) {
        this.prop_categories = list;
    }

    public List<String> getProp_categories() {
        return this.prop_categories;
    }

    public void setStarter_data(Starter_data starter_data2) {
        this.starter_data = starter_data2;
    }

    public Starter_data getStarter_data() {
        return this.starter_data;
    }

    public void setUpdated_date(String str) {
        this.updated_date = str;
    }

    public String getUpdated_date() {
        return this.updated_date;
    }

    public void setCreated_date(String str) {
        this.created_date = str;
    }

    public String getCreated_date() {
        return this.created_date;
    }

    public boolean isGreat_images() {
        return this.great_images;
    }

    public boolean isUnlisted() {
        return this.unlisted;
    }

    public int getApp_month() {
        return this.app_month;
    }

    public void setApp_month(int i) {
        this.app_month = i;
    }

    public int getApp_day_of_month() {
        return this.app_day_of_month;
    }

    public void setApp_day_of_month(int i) {
        this.app_day_of_month = i;
    }

    public boolean isFreemium_locked() {
        return this.freemium_locked;
    }

    public List<String> getAllowed_country_list() {
        return this.allowed_country_list;
    }

    public void setAllowed_country_list(List<String> list) {
        this.allowed_country_list = list;
    }
}
