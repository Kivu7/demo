package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils;

import android.content.Context;

import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.application.MyApplication;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;

import java.util.concurrent.TimeUnit;
import okhttp3.Cache;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;

public class Api {

    private static Retrofit retrofit = null;
    public static Retrofit getApiData() {

        retrofit = new Retrofit.Builder()
                .baseUrl(MyApplication.App_url)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        return retrofit;
    }
    public static Retrofit getClient(Context context) {
        GsonConverterFactory create = GsonConverterFactory.create(new GsonBuilder().setLenient().create());
        new HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY);
        return new Retrofit.Builder().baseUrl(MyApplication.BASE_URL).client(new OkHttpClient.Builder().cache(new Cache(FileUtil.getHttpCacheDir(context), 20971520)).connectTimeout(15000, TimeUnit.MILLISECONDS).readTimeout(20000, TimeUnit.MILLISECONDS).build()).addConverterFactory(create).addCallAdapterFactory(RxJavaCallAdapterFactory.create()).build();
    }
    public interface ApiInterface {

        @GET("template.json")
        Call<JsonObject> loadTemplateData();

        @GET("Stickerdata.json")
        Call<JsonObject> loadStickerList();


    }
}
