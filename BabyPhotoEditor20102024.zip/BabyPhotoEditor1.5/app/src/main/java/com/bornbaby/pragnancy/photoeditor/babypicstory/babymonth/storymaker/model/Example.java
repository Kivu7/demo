package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;
import java.util.List;

public class Example implements Serializable {
    @SerializedName("msg")
    private String msg;
    @SerializedName("photo")
    private List<Photo> photo = null;
    @SerializedName("status_code")
    private Integer statusCode;

    public List<Photo> getPhoto() {
        return this.photo;
    }

    public void setPhoto(List<Photo> list) {
        this.photo = list;
    }

    public String getMsg() {
        return this.msg;
    }

    public void setMsg(String str) {
        this.msg = str;
    }

    public Integer getStatusCode() {
        return this.statusCode;
    }

    public void setStatusCode(Integer num) {
        this.statusCode = num;
    }
}
