package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.net.MailTo;
import androidx.multidex.BuildConfig;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.Manifest;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.ads.rn.ads.RNAd;
import com.ads.rn.funtion.AdCallback;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.R;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.adapter.CollectionAdapter;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.adapter.HomeCollectionAdapter;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.adapter.SliderAdapterExample;


import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.application.MyApplication;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.ModelSliderData;


import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.myAds.AdSDKPref;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.Constant;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.FileUtils;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.GDPRChecker;
import com.bumptech.glide.Glide;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.LoadAdError;
import com.smarteist.autoimageslider.IndicatorView.animation.type.IndicatorAnimationType;
import com.smarteist.autoimageslider.SliderAnimations;
import com.smarteist.autoimageslider.SliderView;

import java.io.File;
import java.util.ArrayList;
import java.util.Objects;

public class HomeActivity extends BaseActivity {
    SliderView sliderView;
    private boolean SettingDialogShow = false, UserGoneToSetting = false, UserClickOnSetting = false;
    private ArrayList<String> collectionImages = new ArrayList<>();
    public static ArrayList<String> selectedSavedImage = new ArrayList<>();
    ImageView imSetting;
    ImageView imShopHome;
    LinearLayout flTemplate;
    LinearLayout flCollage;
    LinearLayout flFrame;
    TextView tvViewAllVideos;
    RecyclerView mRecyclerView;
    public HomeCollectionAdapter mCollectionAdapter;
    private SharedPreferences.Editor rateEditor;
    private SharedPreferences rateStatus;

    public static String getString(Context context, String str) {
        return context.getSharedPreferences("REEL_CRAFT", 0).getString(str, "0");
    }

    private void loadAdaptiveBaner() {
        FrameLayout ad_view_container = findViewById(R.id.bannerView);

        if (AdSDKPref.getInstance(this).getString(AdSDKPref.TAG_ALL_AD_OFF, "0").equals("off") || AdSDKPref.getInstance(this).getString(AdSDKPref.TAG_BANNER_HOME_ONOFF, "0").equals("off")) {
            ad_view_container.setVisibility(View.GONE);
        } else {
            ad_view_container.setVisibility(View.VISIBLE);
            RNAd.getInstance().loadBanner(this, getString(R.string.banner_home));
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        loadAdaptiveBaner();
        MyApplication.getInstance().preloadhomeExit(HomeActivity.this);

        sliderView = findViewById(R.id.imageSlider);
        imSetting = findViewById(R.id.imSetting);
        imShopHome = findViewById(R.id.imShopHome);
        flTemplate = findViewById(R.id.flTemplate);
        flCollage = findViewById(R.id.flCollage);
        flFrame = findViewById(R.id.flFrame);
        tvViewAllVideos = findViewById(R.id.tvViewAllVideos);
        mRecyclerView = findViewById(R.id.rcvProject);
        SharedPreferences sharedPreferences = getSharedPreferences("rate", 0);
        this.rateStatus = sharedPreferences;
        this.rateEditor = sharedPreferences.edit();
        if (!isNetworkConnected()) {
            showNetworkDialog();
        }
        imSetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                PopupMenu popupMenu = new PopupMenu(HomeActivity.this, imSetting);
                popupMenu.getMenuInflater().inflate(R.menu.menu, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    public final boolean onMenuItemClick(MenuItem menuItem) {
                        return menudata(menuItem);
                    }
                });
                popupMenu.show();


            }
        });
        flTemplate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), TemplateListActivity.class).putExtra("tag", "Template");
                funShowAds(intent);
//                AdsManager.INSTANCE.showAds(HomeActivity.this, new Runnable() {
//                    @Override
//                    public void run() {
//                        startActivity();
//                    }
//                }, getLoadingLauncher());

            }
        });
        flCollage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(), TemplateListActivity.class).putExtra("tag", "Collage");
                funShowAds(intent);
//                AdsManager.INSTANCE.showAds(HomeActivity.this, new Runnable() {
//                    @Override
//                    public void run() {
//                        startActivity();
//                    }
//                }, getLoadingLauncher());

            }
        });
        flFrame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), TemplateListActivity.class).putExtra("tag", "Frame");
                funShowAds(intent);
//                AdsManager.INSTANCE.showAds(HomeActivity.this, new Runnable() {
//                    @Override
//                    public void run() {
//                    }
//                }, getLoadingLauncher());

            }
        });
        tvViewAllVideos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyApplication.getInstance().preLoadNativeChooseFace(HomeActivity.this);
                startActivity(new Intent(getApplicationContext(), DesignActivity.class));
            }
        });
        imShopHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), PremiumActivity.class));
            }
        });

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if ((ContextCompat.checkSelfPermission(HomeActivity.this, android.Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED)) {
                getAllList();
            }
        } else {
            if ((ContextCompat.checkSelfPermission(HomeActivity.this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)) {
                getAllList();
            }
        }
        SliderShow();
    }

    private boolean isNetworkConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService("connectivity");
        return connectivityManager.getActiveNetworkInfo() != null && connectivityManager.getActiveNetworkInfo().isConnected();
    }

    @Override
    public void onResume() {
        super.onResume();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!SettingDialogShow || UserGoneToSetting) {
                UserGoneToSetting = false;
                UserClickOnSetting = false;
                getAllPermissions(false);
            }
        }
        if (UserClickOnSetting) {
            UserGoneToSetting = true;
        }

    }

    public void getAllPermissions(final boolean NeverAskAgain) {
        final String[] storage_permissions = {
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
                android.Manifest.permission.READ_EXTERNAL_STORAGE
        };

        final String[] storage_permissions_33 = {
                android.Manifest.permission.READ_MEDIA_IMAGES,
                android.Manifest.permission.POST_NOTIFICATIONS
        };

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if ((ContextCompat.checkSelfPermission(HomeActivity.this, android.Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED)
                    && (ContextCompat.checkSelfPermission(HomeActivity.this, android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED)) {
                getAllList();
//            init();
            } else {
                if (NeverAskAgain) {

                    final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                            HomeActivity.this, R.style.AppAlertDialogExit);
                    LayoutInflater inflater = (LayoutInflater) HomeActivity.this
                            .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                    View view = inflater.inflate(R.layout.dilog_permition, null);
                    alertDialogBuilder.setView(view);
                    alertDialogBuilder.setCancelable(false);
                    final AlertDialog dialog = alertDialogBuilder.create();
                    dialog.show();

                    TextView tvExit = view.findViewById(R.id.tvExit);
                    ImageView ivClose = view.findViewById(R.id.ivClose);

                    view.findViewById(R.id.btnRateUs).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            goToSettings();
                            dialog.dismiss();
                        }
                    });

                    tvExit.setOnClickListener(view1 -> {
                        ActivityCompat.finishAffinity(HomeActivity.this);

                        try {
                            finishAffinity();
                        } catch (Exception e) {
                            e.printStackTrace();
                            finish();
                        }
                    });

                    ivClose.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();
                            ActivityCompat.finishAffinity(HomeActivity.this);

                            try {
                                finishAffinity();
                            } catch (Exception e) {
                                e.printStackTrace();
                                finish();
                            }
                        }
                    });
                } else {
                    ActivityCompat.requestPermissions(HomeActivity.this, storage_permissions_33, 123);
                }
            }
        } else {
            if ((ContextCompat.checkSelfPermission(HomeActivity.this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)) {
                getAllList();
//            init();
            } else {
                if (NeverAskAgain) {

                    final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                            HomeActivity.this, R.style.AppAlertDialogExit);
                    LayoutInflater inflater = (LayoutInflater) HomeActivity.this
                            .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                    View view = inflater.inflate(R.layout.dilog_permition, null);
                    alertDialogBuilder.setView(view);
                    alertDialogBuilder.setCancelable(false);
                    final AlertDialog dialog = alertDialogBuilder.create();
                    dialog.show();

                    TextView tvExit = view.findViewById(R.id.tvExit);
                    ImageView ivClose = view.findViewById(R.id.ivClose);

                    view.findViewById(R.id.btnRateUs).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            goToSettings();
                            dialog.dismiss();
                        }
                    });

                    tvExit.setOnClickListener(view1 -> {
                        ActivityCompat.finishAffinity(HomeActivity.this);

                        try {
                            finishAffinity();
                        } catch (Exception e) {
                            e.printStackTrace();
                            finish();
                        }
                    });

                    ivClose.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();
                            ActivityCompat.finishAffinity(HomeActivity.this);

                            try {
                                finishAffinity();
                            } catch (Exception e) {
                                e.printStackTrace();
                                finish();
                            }
                        }
                    });
                } else {
                    ActivityCompat.requestPermissions(HomeActivity.this, storage_permissions, 123);
                }
            }
        }
    }

    private void goToSettings() {
        UserClickOnSetting = true;
        Intent myAppSettings = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));
        myAppSettings.addCategory(Intent.CATEGORY_DEFAULT);
        myAppSettings.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivityForResult(myAppSettings, 111);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 123:
                if (grantResults.length > 0) {
                    if ((grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                    } else {
                        if ((grantResults[0] == PackageManager.PERMISSION_DENIED && !ActivityCompat.shouldShowRequestPermissionRationale(HomeActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE))) {
                            SettingDialogShow = true;
                            getAllPermissions(true);
                        }
                    }
                }
                break;

        }
    }

    private boolean popUpRate = false;

    public void showRateDialog(Boolean bool) {
        Dialog dialog2 = new Dialog(this);
        dialog2.setContentView(R.layout.rate_us_dialog);
        dialog2.getWindow().setFlags(8, 8);
        dialog2.show();
        dialog2.getWindow().getDecorView().setSystemUiVisibility(getWindow().getDecorView().getSystemUiVisibility());
        dialog2.getWindow().clearFlags(8);
        dialog2.getWindow().setLayout(-1, -1);
        RatingBar ratingBar = dialog2.findViewById(R.id.ratingBar);
        ratingBar.setRating(0.0f);
        dialog2.findViewById(R.id.btnNoThanks).setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                dialog2.dismiss();
                if (!popUpRate) {
                    if (Build.VERSION.SDK_INT >= 21) {
                        finishAndRemoveTask();
                    }
                    finish();
                    finishAffinity();
                    return;
                }
                popUpRate = false;
            }
        });
        dialog2.findViewById(R.id.btnSubmit).setOnClickListener(new View.OnClickListener() {


            public final void onClick(View view) {

                if (ratingBar.getRating() != 0.0f) {
                    if (ratingBar.getRating() <= 3.0f) {
                        Intent intent = new Intent("android.intent.action.SENDTO", Uri.parse(MailTo.MAILTO_SCHEME + Uri.encode(getResources().getString(R.string.feedback_email))));
                        intent.putExtra("android.intent.extra.SUBJECT", getResources().getString(R.string.app_name));
                        try {
                            startActivity(Intent.createChooser(intent, "Send email via..."));
                        } catch (ActivityNotFoundException unused) {
                            Toast.makeText(getApplicationContext(), "There are no email clients installed.", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        String packageName = getPackageName();
                        try {
                            startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + packageName)));
                        } catch (ActivityNotFoundException unused2) {
                            startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=" + packageName)));
                        }
                    }
                    dialog2.dismiss();
                    if (bool) {
                        rateEditor.putBoolean("isRated", true);
                        rateEditor.apply();
                        if (Build.VERSION.SDK_INT >= 21) {
                            finishAndRemoveTask();
                        }
                        finish();
                        finishAffinity();
                        return;
                    }
                    return;
                }
                Toast.makeText(getApplicationContext(), "Please select stars for submitting ratings!", Toast.LENGTH_SHORT).show();
            }
        });
        dialog2.getWindow().setBackgroundDrawableResource(R.color.transparent);
    }

    public void showNetworkDialog() {
        Dialog dialog2 = new Dialog(this);
        dialog2.setContentView(R.layout.network_dialog);
        dialog2.getWindow().setFlags(8, 8);
        dialog2.show();
        dialog2.getWindow().getDecorView().setSystemUiVisibility(getWindow().getDecorView().getSystemUiVisibility());
        dialog2.getWindow().clearFlags(8);
        dialog2.getWindow().setLayout(-1, -1);
        dialog2.findViewById(R.id.btnRetry).setOnClickListener(new View.OnClickListener() {


            public final void onClick(View view) {
                dialog2.dismiss();
            }
        });
        dialog2.getWindow().setBackgroundDrawableResource(R.color.transparent);
    }

    public boolean menudata(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == R.id.change_language) {
            startActivity(new Intent(this, LanguageSelectActivity.class).putExtra("isShowBack", true).putExtra(Constant.IS_FROM_SETTINGS, true));
        } else if (itemId == R.id.myDesign) {
            MyApplication.getInstance().preLoadNativeChooseFace(HomeActivity.this);
            startActivity(new Intent(getApplicationContext(), DesignActivity.class));
        } else if (itemId == R.id.privacyPolicy) {
            startActivity(new Intent("android.intent.action.VIEW", Uri.parse(getString(R.string.privacy_policy_link))));
        } else if (itemId == R.id.rate) {
            showRateDialog(false);
            this.popUpRate = true;
        } else if (itemId == R.id.share) {
            try {
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("text/plain");
                intent.putExtra("android.intent.extra.SUBJECT", "Baby Photo");
                intent.putExtra("android.intent.extra.TEXT", "\nHey,Check out this Lovely Baby Photo Editor\n\n" + "https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID + "\n\n");
                startActivity(Intent.createChooser(intent, "choose one"));
                return true;
            } catch (Exception unused) {
                return true;
            }
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        if (!this.rateStatus.getBoolean("isRated", false)) {
            showRateDialog(true);
        } else {
            showExitDialog();
        }
    }

    private void showExitDialog() {
        Dialog dialog2 = new Dialog(this);
        dialog2.setContentView(R.layout.exit_dialog);
        dialog2.getWindow().setFlags(8, 8);
        dialog2.show();
        dialog2.getWindow().getDecorView().setSystemUiVisibility(getWindow().getDecorView().getSystemUiVisibility());
        dialog2.getWindow().clearFlags(8);
        dialog2.getWindow().setLayout(-1, -1);
        dialog2.findViewById(R.id.btnOk).setOnClickListener(new View.OnClickListener() {


            public final void onClick(View view) {
                dialog2.dismiss();
                moveTaskToBack(true);
                if (Build.VERSION.SDK_INT >= 21) {
                    finishAndRemoveTask();
                }
                finish();
                finishAffinity();
            }
        });
        dialog2.findViewById(R.id.btnCancel).setOnClickListener(new View.OnClickListener() {


            public void onClick(View view) {
                dialog2.dismiss();
            }
        });
        dialog2.getWindow().setBackgroundDrawableResource(R.color.transparent);
    }

    public void getAllList() {
        collectionImages.clear();
        if (Build.VERSION.SDK_INT > 29) {
            this.collectionImages = FileUtils.getImagesFromFolder(this, getString(R.string.app_name));
        } else {
            File[] listFiles = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/" + getString(R.string.app_name)).listFiles();
            if (listFiles != null) {
                for (File path : listFiles) {
                    this.collectionImages.add(path.getPath());
                }
            }
        }
        runOnUiThread(new Runnable() {
            public final void run() {
                initAdapter();
            }
        });
    }

    public void initAdapter() {
        HomeCollectionAdapter.onImageClick onImageClick = new HomeCollectionAdapter.onImageClick() {
            public void onImageClick(String str) {
                if (selectedSavedImage.isEmpty()) {
                    Intent intent = new Intent(HomeActivity.this, SaveActivity.class);
                    intent.putExtra("fromWhere", "design");
                    intent.putExtra("designImgPath", str);
                    startActivity(intent);
                } else if (!selectedSavedImage.contains(str)) {
                    selectedSavedImage.add(str);
                } else {
                    selectedSavedImage.remove(str);
                    if (selectedSavedImage.isEmpty()) {

                    }
                }
                if (selectedSavedImage.isEmpty()) {
                    mCollectionAdapter.notifyDataSetChanged();
                }
            }
        };
        this.mCollectionAdapter = new HomeCollectionAdapter(HomeActivity.this, this.collectionImages, onImageClick, new HomeCollectionAdapter.onLongImageClick() {
            public void onLongImageClick(String str) {

                if (!selectedSavedImage.contains(str)) {
                    selectedSavedImage.add(str);
                    if (selectedSavedImage.size() == 1) {
                        mCollectionAdapter.notifyDataSetChanged();
                        return;
                    }
                    return;
                }
                selectedSavedImage.remove(str);
            }
        });
        LinearLayoutManager staggeredGridLayoutManager = new LinearLayoutManager(HomeActivity.this, RecyclerView.HORIZONTAL, false);
        this.mRecyclerView.setLayoutManager(staggeredGridLayoutManager);
        this.mRecyclerView.setAdapter(this.mCollectionAdapter);
        this.mRecyclerView.setHasFixedSize(true);

//        RecyclerView.ItemAnimator itemAnimator = this.mRecyclerView.getItemAnimator();
//        Objects.requireNonNull(itemAnimator);
//        ((SimpleItemAnimator) itemAnimator).setSupportsChangeAnimations(false);
    }

    private void SliderShow() {
        SliderAdapterExample adapter = new SliderAdapterExample(this);
        ModelSliderData sliderItem;
        sliderItem = new ModelSliderData(MyApplication.App_url + "Slide/banner_one.png");
        adapter.addItem(sliderItem);
        sliderItem = new ModelSliderData(MyApplication.App_url + "Slide/banner_two.png");
        adapter.addItem(sliderItem);
        sliderItem = new ModelSliderData(MyApplication.App_url + "Slide/banner_three.png");
        adapter.addItem(sliderItem);
        sliderItem = new ModelSliderData(MyApplication.App_url + "Slide/banner_four.png");
        adapter.addItem(sliderItem);
        sliderItem = new ModelSliderData(MyApplication.App_url + "Slide/banner_five.png");
        adapter.addItem(sliderItem);
        sliderItem = new ModelSliderData(MyApplication.App_url + "Slide/banner_nine.png");
        adapter.addItem(sliderItem);
        sliderItem = new ModelSliderData(MyApplication.App_url + "Slide/banner_seven.png");
        adapter.addItem(sliderItem);
        sliderItem = new ModelSliderData(MyApplication.App_url + "Slide/banner_six.png");
        adapter.addItem(sliderItem);
        sliderItem = new ModelSliderData(MyApplication.App_url + "Slide/banner_ten.png");
        adapter.addItem(sliderItem);

        sliderView.setSliderAdapter(adapter);
        sliderView.setSliderTransformAnimation(SliderAnimations.SIMPLETRANSFORMATION);
        sliderView.setAutoCycleDirection(SliderView.AUTO_CYCLE_DIRECTION_BACK_AND_FORTH);
        sliderView.setIndicatorAnimation(IndicatorAnimationType.WORM);
        sliderView.setScrollTimeInSec(3);
        sliderView.setAutoCycle(true);
        sliderView.startAutoCycle();
        sliderView.setOnIndicatorClickListener(position -> Log.i("GGG", "onIndicatorClicked: " + sliderView.getCurrentPagePosition()));
    }

    private void showInterstitialAd(final Intent intent) {

        if (MyApplication.inter_home_action != null) {
            try {
                RNAd.getInstance().showintersialClickCount(
                        HomeActivity.this,
                        MyApplication.inter_home_action,
                        new AdCallback() {
                            @Override
                            public void onNextAction() {
                                super.onNextAction();
                                startActivity(intent);
                            }
                        }
                );

            } catch (Exception e) {

                RNAd.getInstance().showintersialClickCount(
                        HomeActivity.this,
                        MyApplication.inter_home_action,
                        new AdCallback() {
                            @Override
                            public void onNextAction() {
                                super.onNextAction();
                                startActivity(intent);
                                                 }
                        }
                );
            }
        } else {
            startActivity(intent);
        }

    }

    public static boolean isNetworkConnected(Context lCon) {
        ConnectivityManager cm = null;
        try {
            cm = (ConnectivityManager) lCon
                    .getSystemService(Context.CONNECTIVITY_SERVICE);


        } catch (Exception e) {
            e.printStackTrace();
        }
        return cm.getActiveNetworkInfo() != null;
    }

    public void funShowAds(Intent intent) {
        if (isNetworkConnected(this)) {

            showInterstitialAd(intent);
        } else {
            startActivity(intent);
        }
    }
}