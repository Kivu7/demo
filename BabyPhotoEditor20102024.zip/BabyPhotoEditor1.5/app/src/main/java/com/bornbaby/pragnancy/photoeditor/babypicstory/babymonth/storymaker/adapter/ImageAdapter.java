package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;


import androidx.recyclerview.widget.RecyclerView;


import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.R;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.ImageInfo;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.FilterClick;
import com.bumptech.glide.Glide;

import java.util.List;

public class ImageAdapter extends RecyclerView.Adapter<ImageAdapter.MyView> {
    FilterClick click;
    Context context;
    List<ImageInfo> uriList;

    public ImageAdapter(Context context2, List<ImageInfo> list, FilterClick filterClick) {
        this.context = context2;
        this.uriList = list;
        this.click = filterClick;
    }

    public MyView onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyView(LayoutInflater.from(this.context).inflate(R.layout.list_image, viewGroup, false));
    }

    public void onBindViewHolder(MyView myView, int i) {
        Glide.with(this.context).load(this.uriList.get(i).getUri()).into(myView.imgs);
    }

    public int getItemCount() {
        return this.uriList.size();
    }

    class MyView extends RecyclerView.ViewHolder {

        ImageView cardRemove;
        ImageView imgs;

        public MyView(View view) {
            super(view);
            cardRemove=view.findViewById(R.id.cardRemove);
            imgs=view.findViewById(R.id.imgs);

            cardRemove.setOnClickListener(new View.OnClickListener( ) {
                public void onClick(View view) {
                    ImageAdapter.this.click.clickFilter(MyView.this.getAdapterPosition());
                }
            });
        }
    }
}
