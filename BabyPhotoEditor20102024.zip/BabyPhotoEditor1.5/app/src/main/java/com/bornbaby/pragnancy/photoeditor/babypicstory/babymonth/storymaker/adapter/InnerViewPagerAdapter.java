package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.adapter;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import java.util.ArrayList;

public class InnerViewPagerAdapter extends FragmentPagerAdapter {
    public ArrayList<Fragment> fragmentsList;

    public int getCount() {
        return 3;
    }

    public CharSequence getPageTitle(int i) {
        if (i == 0) {
            return "Category";
        }
        if (i == 1) {
            return "Collection";
        }
        if (i == 2) {
            return "Collage";
        }
        return null;
    }

    public InnerViewPagerAdapter(FragmentManager fragmentManager, int i, ArrayList<Fragment> arrayList) {
        super(fragmentManager, i);
        this.fragmentsList = arrayList;
    }

    @NonNull
    public Fragment getItem(int i) {
        return this.fragmentsList.get(i);
    }
}
