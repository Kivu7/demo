package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils;

import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.R;

public class ScanCustomDialog extends Dialog {
    TextView mTextView;
    RelativeLayout mainRl;

    public void setMessage(String str) {
    }

    public ScanCustomDialog(Context context) {
        super(context);
        WindowManager.LayoutParams attributes = getWindow().getAttributes();
        attributes.gravity = 1;
        getWindow().setAttributes(attributes);
        setCancelable(false);
        setCanceledOnTouchOutside(false);
        View inflate = LayoutInflater.from(context).inflate(R.layout.custom_loading_dialog, (ViewGroup) null);
        getWindow().setBackgroundDrawableResource(17170445);
        setContentView(inflate);
    }
}
