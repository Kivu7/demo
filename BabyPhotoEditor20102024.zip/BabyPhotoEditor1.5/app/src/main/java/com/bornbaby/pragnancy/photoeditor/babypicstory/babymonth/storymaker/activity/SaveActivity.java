package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.ads.sdk.ads.SdkAd;
import com.ads.sdk.funtion.AdCallback;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.R;


import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.application.MyApplication;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.CommonUtils;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.Constant;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.CustomDialog;
import com.bumptech.glide.Glide;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.LoadAdError;

import java.io.File;

public class SaveActivity extends AppCompatActivity {


    private File file;
    private void bannerNativeAds() {
        FrameLayout frAds;
        ShimmerFrameLayout shimmerAds;

        frAds = findViewById(R.id.fr_ads);
        shimmerAds = findViewById(R.id.shimmer_native);



        SdkAd.getInstance().loadNativeAd(this, MyApplication.getApplication().nativeId, R.layout.native_medium, frAds, shimmerAds, new AdCallback() {
            @Override
            public void onAdFailedToLoad(@org.jetbrains.annotations.Nullable LoadAdError i) {
                super.onAdFailedToLoad(i);
                frAds.removeAllViews();
            }

            @Override
            public void onAdFailedToShow(@org.jetbrains.annotations.Nullable AdError adError) {
                super.onAdFailedToShow(adError);
                frAds.removeAllViews();
            }
        });
    }



    public void onCreate(Bundle bundle) {

        CommonUtils.updateLanguage(this);

        super.onCreate(bundle);
        setContentView(R.layout.activity_save);
        bannerNativeAds();
        CustomDialog customDialog2 = new CustomDialog(this);
        customDialog2.show();
        String stringExtra = getIntent().getStringExtra("fromWhere");
        stringExtra.equals("design");
        ImageView saveImg = findViewById(R.id.saveImg);
        ImageView share = findViewById(R.id.share);
        ImageView btnBack = findViewById(R.id.btnBack);

        ImageView btnHome = findViewById(R.id.btnHome);
        String filePath;
        if (stringExtra.equals("design")) {
            btnHome.setVisibility(View.INVISIBLE);
            btnBack.setVisibility(View.VISIBLE);
            filePath = getIntent().getStringExtra("designImgPath");
            this.file = new File(filePath);
        } else {
            filePath = getIntent().getStringExtra("filePath");
            this.file = new File(filePath);
        }
        Log.i("VVBB", "file : " + file);
        Glide.with(SaveActivity.this).load(filePath).into(saveImg);
//        saveImg.setImageBitmap(getBitmapFromURL(filePath));
        customDialog2.dismiss();
        btnBack.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                finish();
            }
        });
        btnHome.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                onBackPressed();
            }
        });
        Uri uriForFile = FileProvider.getUriForFile(this, getPackageName() + ".provider", this.file);
        Intent intent = new Intent();
        intent.setAction("android.intent.action.SEND");
        intent.setType("image/jpeg");
        intent.addFlags(1);
        intent.putExtra("android.intent.extra.SUBJECT", "subject");
        intent.putExtra("android.intent.extra.TEXT", uriForFile);
        intent.putExtra("android.intent.extra.STREAM", uriForFile);
        intent.setFlags(268435456);
        share.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                Intent intent = new Intent("android.intent.action.SEND");
                Uri uriForFile = FileProvider.getUriForFile(SaveActivity.this, getPackageName() + ".provider", file);
                intent.setType("image/*");
                intent.putExtra("android.intent.extra.STREAM", uriForFile);
                startActivity(Intent.createChooser(intent, "Share image using"));
            }
        });
//        new ClearGlideCacheAsyncTask ().execute();
    }
    private class ClearGlideCacheAsyncTask extends AsyncTask<Void, Void, Boolean> {

        private boolean result;

        @Override
        protected Boolean doInBackground(Void... params) {
            try {
                Glide.get(SaveActivity.this).clearDiskCache();
                result = true;
            }
            catch (Exception e){
            }
            return result;
        }

        @Override
        protected void onPostExecute(Boolean result) {
            super.onPostExecute(result);
            if(result)
                Toast.makeText(SaveActivity.this, "cache deleted", Toast.LENGTH_SHORT).show();
        }
    }

    public void onBackPressed() {
        Constant.Cutout = null;
        startActivity(new Intent(SaveActivity.this,HomeActivity.class));
        finishAffinity();
    }

    public static Bitmap getBitmapFromURL(String str) {
        return BitmapFactory.decodeFile(str, new BitmapFactory.Options());
    }
}
