package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils;

import android.app.Activity;
import android.app.Dialog;
import android.os.Build;
import android.view.Window;
import android.widget.TextView;


import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.R;

import java.lang.ref.WeakReference;
import java.util.Objects;

public class ProgressDialog {
    Activity activity;
    boolean isShowing = false;
    private Dialog progressDialog;
    TextView textView;
    WeakReference<Activity> weakReference;

    public ProgressDialog(Activity activity2) {
        this.progressDialog = new Dialog(activity2);
        this.activity = activity2;
        this.weakReference = new WeakReference<>(activity2);
        this.progressDialog.setContentView(R.layout.progress_dialog);
        if (Build.VERSION.SDK_INT >= 19) {
            ((Window) Objects.requireNonNull(this.progressDialog.getWindow())).setBackgroundDrawableResource(17170445);
        }
        this.textView  = this.progressDialog.findViewById(R.id.message);
        this.progressDialog.setCancelable(false);
    }

    public void showDialog() {
        try {
            if (this.progressDialog != null && !this.isShowing && this.weakReference.get() != null) {
                this.progressDialog.show();
                this.isShowing = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void dismissDialog() {
        Dialog dialog = this.progressDialog;
        if (dialog != null && dialog.isShowing() && this.weakReference.get() != null) {
            this.progressDialog.dismiss();
            this.isShowing = false;
        }
    }

    public void setMessage(String str) {
        this.textView.setText(str);
    }

    public boolean isShowing() {
        return this.isShowing;
    }
}
