package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.ads.sdk.ads.SdkAd;
import com.ads.sdk.funtion.AdCallback;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.R;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.adapter.FrameViewPagerAdaptor;


import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.application.MyApplication;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.fragments.StickerFragment;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.RingModel;


import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.Api;
import com.bumptech.glide.load.Key;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.material.tabs.TabLayout;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.io.InputStream;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class StickerActivity extends AppCompatActivity {
    public static int atIndex;
    FrameViewPagerAdaptor frameViePagerAdaptor;
    TabLayout tabLayout;
    ViewPager viewPager;

    ProgressBar progressBar;

    @Override
    protected void onResume() {
        super.onResume();


    }

    private void bannerNativeAds() {
        FrameLayout frAds;
        ShimmerFrameLayout shimmerAds;

        frAds = findViewById(R.id.fr_ads);
        shimmerAds = findViewById(R.id.shimmer_native);



        SdkAd.getInstance().loadNativeAd(this, MyApplication.getApplication().nativeId, R.layout.native_medium, frAds, shimmerAds, new AdCallback() {
            @Override
            public void onAdFailedToLoad(@org.jetbrains.annotations.Nullable LoadAdError i) {
                super.onAdFailedToLoad(i);
                frAds.removeAllViews();
            }

            @Override
            public void onAdFailedToShow(@org.jetbrains.annotations.Nullable AdError adError) {
                super.onAdFailedToShow(adError);
                frAds.removeAllViews();
            }
        });
    }

    RingModel ringModel;

    public void onCreate(Bundle bundle) {

        setContentView(R.layout.activity_sticker);
        super.onCreate(bundle);
        bannerNativeAds();
        this.viewPager = findViewById(R.id.framesViewPager);
        this.tabLayout = findViewById(R.id.tabLayout);
        this.progressBar = findViewById(R.id.progressBar);
//        String url;
//        try {
//            url = Utils.getAssetJsonData(StickerActivity.this,"Stickerdata.data");
//            ringModel = new Gson().fromJson(url, RingModel.class);
//        } catch (Exception e) {
//            e.printStackTrace();
//            ringModel = null;
//        }
        Api.ApiInterface apiInterface = Api.getApiData().create(Api.ApiInterface.class);

        Call<JsonObject> call = apiInterface.loadStickerList();
        progressBar.setVisibility(View.VISIBLE);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {

                if (response.isSuccessful()) {
                    progressBar.setVisibility(View.GONE);
                    try {
                        ringModel = new Gson().fromJson(response.body(), RingModel.class);
                        frameViePagerAdaptor = new FrameViewPagerAdaptor(getSupportFragmentManager());
                        for (int i = 0; i < ringModel.getData().size(); i++) {
                            frameViePagerAdaptor.addFragment(new StickerFragment(ringModel.getData().get(i), StickerActivity.this), ringModel.getData().get(i).getCatName());
                        }
                        viewPager.setAdapter(frameViePagerAdaptor);
                        tabLayout.setupWithViewPager(viewPager);

                        viewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                            public void onPageScrollStateChanged(int i) {
                            }

                            public void onPageScrolled(int i, float f, int i2) {
                            }

                            public void onPageSelected(int i) {
                                StickerActivity.atIndex = i;
                            }
                        });
                    } catch (Exception e) {

                        e.printStackTrace();
                    }

                }

            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Toast.makeText(StickerActivity.this, getString(R.string.no_internet_con), Toast.LENGTH_SHORT).show();
                progressBar.setVisibility(View.GONE);
            }
        });

        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    public String readDatFromJson() {
        try {
            InputStream open = getAssets().open("Stickerdata.json");
            byte[] bArr = new byte[open.available()];
            open.read(bArr);
            open.close();
            return new String(bArr, Key.STRING_CHARSET_NAME);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public void onBackPressed() {
        super.onBackPressed();
    }


}
