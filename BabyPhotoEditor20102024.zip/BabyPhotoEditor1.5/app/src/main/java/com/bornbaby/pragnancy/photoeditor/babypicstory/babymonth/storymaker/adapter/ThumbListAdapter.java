package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.adapter;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.R;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.TemplateJason.RootTemplate;

 
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.BaseRequestOptions;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.github.ybq.android.spinkit.SpinKitView;
import com.github.ybq.android.spinkit.sprite.Sprite;
import com.github.ybq.android.spinkit.style.Circle;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ThumbListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    public final int ITEM_AD = 2;
    public final int ITEM_THUMB = 1;

    public Activity mContext;
    private onThumbClickInterface mOnThumbClickInterface;
    private List<RootTemplate> mRootTemplates;
    private ColorDrawable[] vibrantLightColorList = {new ColorDrawable(Color.parseColor("#809ACCCD")), new ColorDrawable(Color.parseColor("#808FD8A0")), new ColorDrawable(Color.parseColor("#80CBD890")), new ColorDrawable(Color.parseColor("#80DACC8F")), new ColorDrawable(Color.parseColor("#80D9A790")), new ColorDrawable(Color.parseColor("#80D18FD9")), new ColorDrawable(Color.parseColor("#80FF6772")), new ColorDrawable(Color.parseColor("#80DDFB5C")), new ColorDrawable(Color.parseColor("#80BCB212")), new ColorDrawable(Color.parseColor("#80FBF37C")), new ColorDrawable(Color.parseColor("#80F2BF80")), new ColorDrawable(Color.parseColor("#80FF8C64"))};

    public interface onThumbClickInterface {
        void onThumbClick(RootTemplate rootTemplate);
    }

    public ThumbListAdapter(Activity activity, ArrayList<RootTemplate> arrayList, onThumbClickInterface onthumbclickinterface, int i) {
        this.mRootTemplates = arrayList;
        this.mContext = activity;
        this.mOnThumbClickInterface = onthumbclickinterface;
        DisplayMetrics displayMetrics2 = new DisplayMetrics();
        this.mContext.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics2);
    }

    @NonNull
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        LayoutInflater from = LayoutInflater.from(viewGroup.getContext());
        if (i == 1) {
            return new ViewHolder(from.inflate(R.layout.single_thumb_list_item, (ViewGroup) null));
        }
        return new AdViewHolder(from.inflate(R.layout.item_ad, (ViewGroup) null));
    }

    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int i) {
        if (getItemViewType(viewHolder.getAdapterPosition()) == 1) {
            final ViewHolder viewHolder2 = (ViewHolder) viewHolder;
            String preview_thumbnail = this.mRootTemplates.get(viewHolder2.getAdapterPosition()).getPreview_thumbnail();
            if (preview_thumbnail == null) {
                preview_thumbnail = this.mRootTemplates.get(viewHolder2.getAdapterPosition()).getOverlay_image();
            }
            ((RequestBuilder) Glide.with(this.mContext).load(preview_thumbnail).placeholder((Drawable) this.vibrantLightColorList[new Random().nextInt(11)])).apply((BaseRequestOptions<?>) new RequestOptions().diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)).listener(new RequestListener<Drawable>() {
                public boolean onLoadFailed(GlideException glideException, Object obj, @NonNull Target<Drawable> target, boolean z) {
                    return false;
                }

                public boolean onResourceReady(@NonNull Drawable drawable, @NonNull Object obj, Target<Drawable> target, @NonNull DataSource dataSource, boolean z) {
                    viewHolder2.mProgressBar.setVisibility(View.INVISIBLE);
                    return false;
                }
            }).into(viewHolder2.mImageView);
            viewHolder2.mImageView.setOnClickListener(new View.OnClickListener() {


                public final void onClick(View view) {
                    lambda$onBindViewHolder$0$ThumbListAdapter(viewHolder2, view);
                }
            });
            return;
        }


    }

    public  void lambda$onBindViewHolder$0$ThumbListAdapter(ViewHolder viewHolder, View view) {
        this.mOnThumbClickInterface.onThumbClick(this.mRootTemplates.get(viewHolder.getAdapterPosition()));
    }

    public int getItemCount() {
        return this.mRootTemplates.size();
    }

    public void refreshAds() {
        notifyItemChanged(0);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView mImageView;
        SpinKitView mProgressBar;

        public ViewHolder(View view) {
            super(view);
            this.mImageView = view.findViewById(R.id.thumbImg);
            this.mProgressBar = view.findViewById(R.id.porgressBar);
            this.mProgressBar.setIndeterminateDrawable(new Circle());
            DisplayMetrics displayMetrics = new DisplayMetrics();
            mContext.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
            this.mImageView.getLayoutParams().width = (displayMetrics.widthPixels / 2) - mContext.getResources().getDimensionPixelSize(R.dimen._15sdp);
        }
    }

    public static class AdViewHolder extends RecyclerView.ViewHolder {
        
        public FrameLayout adSpace;

        public AdViewHolder(View view) {
            super(view);
            this.adSpace = view.findViewById(R.id.adSpace);
        }
    }

    public int getItemViewType(int i) {
        return this.mRootTemplates.get(i).getType().equals("ad") ? 2 : 1;
    }

    public void addItem(RootTemplate rootTemplate) {
        this.mRootTemplates.add(rootTemplate);
        notifyItemInserted(this.mRootTemplates.size() - 1);
    }
}
