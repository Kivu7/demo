package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;

import java.util.Objects;

public class ImageInfo implements Parcelable {
    public static final Creator<ImageInfo> CREATOR = new Creator<ImageInfo>() {
        public ImageInfo createFromParcel(Parcel parcel) {
            return new ImageInfo(parcel);
        }

        public ImageInfo[] newArray(int i) {
            return new ImageInfo[i];
        }
    };
    long date;
    boolean isSelected;
    boolean isuri;
    String path;
    long size;
    Uri uri;

    public int describeContents() {
        return 0;
    }

    public ImageInfo() {
        this.isSelected = false;
        this.isuri = true;
    }

    public ImageInfo(Uri uri2, String str, boolean z) {
        this.isSelected = false;
        this.path = str;
        this.isuri = z;
        this.uri = uri2;
    }

    public ImageInfo(String str) {
        this.isSelected = false;
        this.isuri = true;
        this.path = str;
    }

    public ImageInfo(String str, Uri uri2, long j, long j2) {
        this.isSelected = false;
        this.isuri = true;
        this.path = str;
        this.uri = uri2;
        this.date = j;
        this.size = j2;
    }

    public ImageInfo(Uri uri2, long j, long j2) {
        this.isSelected = false;
        this.isuri = true;
        this.uri = uri2;
        this.date = j;
        this.size = j2;
    }

    protected ImageInfo(Parcel parcel) {
        boolean z = false;
        this.isSelected = false;
        this.isuri = true;
        this.path = parcel.readString();
        this.uri = (Uri) parcel.readParcelable(Uri.class.getClassLoader());
        this.date = parcel.readLong();
        this.size = parcel.readLong();
        this.isSelected = parcel.readByte() != 0;
        this.isuri = parcel.readByte() != 0 ? true : z;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.path);
        parcel.writeParcelable(this.uri, i);
        parcel.writeLong(this.date);
        parcel.writeLong(this.size);
        parcel.writeByte(this.isSelected ? (byte) 1 : 0);
        parcel.writeByte(this.isuri ? (byte) 1 : 0);
    }

    public String getPath() {
        return this.path;
    }

    public void setPath(String str) {
        this.path = str;
    }

    public long getDate() {
        return this.date;
    }

    public void setDate(long j) {
        this.date = j;
    }

    public Uri getUri() {
        return this.uri;
    }

    public void setUri(Uri uri2) {
        this.uri = uri2;
    }

    public long getSize() {
        return this.size;
    }

    public void setSize(long j) {
        this.size = j;
    }

    public boolean isSelected() {
        return this.isSelected;
    }

    public void setSelected(boolean z) {
        this.isSelected = z;
    }

    public boolean isIsuri() {
        return this.isuri;
    }

    public void setIsuri(boolean z) {
        this.isuri = z;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        return Objects.equals(getUri(), ((ImageInfo) obj).getUri());
    }
}
