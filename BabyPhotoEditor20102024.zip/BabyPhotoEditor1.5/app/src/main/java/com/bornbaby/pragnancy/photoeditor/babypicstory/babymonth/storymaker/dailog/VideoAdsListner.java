package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.dailog;

public interface VideoAdsListner {
    void videoAdsClose();

    void videoAdNotWatchComplate();

    void videoAdNotLoaded();
}
