package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model;

public class Language {
    private boolean isSelected = false;
    private final String languageCode;
    private final String languageName;
    private final int languageResourceId;

    public Language(String str, String str2, int i) {
        this.languageName = str;
        this.languageCode = str2;
        this.languageResourceId = i;
    }

    public String getLanguageName() {
        return this.languageName;
    }

    public int getLanguageResourceId() {
        return this.languageResourceId;
    }

    public boolean isSelected() {
        return this.isSelected;
    }

    public void setSelected(boolean z) {
        this.isSelected = z;
    }

    public String getLanguageCode() {
        return this.languageCode;
    }
}
