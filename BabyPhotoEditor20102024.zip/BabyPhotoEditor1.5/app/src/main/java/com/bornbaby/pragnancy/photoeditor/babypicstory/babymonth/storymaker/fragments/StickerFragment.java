package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.adapter.StickerAdaptor;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.R;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.activity.StickerActivity;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.Datum;


public class StickerFragment extends Fragment {
    StickerAdaptor customAdaptor;
    RecyclerView framesRecyclerView;
    Datum ringModel;
    StickerActivity stickerActivity;
    public StickerFragment(Datum datum, StickerActivity stickerActivity) {
        this.ringModel = datum;
        this.stickerActivity = stickerActivity;
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.sticker_fragment, viewGroup, false);
        this.framesRecyclerView = inflate.findViewById(R.id.framesRecyclerView);
        this.customAdaptor = new StickerAdaptor(stickerActivity, this.ringModel);
        this.framesRecyclerView.setLayoutManager(new GridLayoutManager(stickerActivity, 2));
        this.framesRecyclerView.setAdapter(this.customAdaptor);
        return inflate;
    }
}
