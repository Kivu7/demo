package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.dailog;

import android.animation.Animator;

import androidx.fragment.app.FragmentActivity;

public class WatermarkListenerNew implements Animator.AnimatorListener {

    public final FragmentActivity fragmentActivity;

    public final int anInt;

    public WatermarkListenerNew(FragmentActivity editorTemplateActivity, int i10) {

        this.anInt = i10;

        this.fragmentActivity = editorTemplateActivity;
    }

    public final void onAnimationCancel(Animator animator) {
    }

    public final void onAnimationEnd(Animator animator) {
    }

    public final void onAnimationRepeat(Animator animator) {

    }

    public final void onAnimationStart(Animator animator) {
    }
}