package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.adapter;

import android.app.Activity;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.activity.DesignActivity;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.R;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import java.util.ArrayList;

public class CollectionAdapter extends RecyclerView.Adapter<CollectionAdapter.ViewHolder> {
    
    public ArrayList<String> images;
    
    public Activity mActivity;
    
    public onImageClick mOnImageClick;
    
    public onLongImageClick mOnLongImageClick;

    public interface onImageClick {
        void onImageClick(String str);
    }

    public interface onLongImageClick {
        void onLongImageClick(String str);
    }

    public CollectionAdapter(Activity activity, ArrayList<String> arrayList, onImageClick onimageclick, onLongImageClick onlongimageclick) {
        this.mActivity = activity;
        this.images = arrayList;
        this.mOnImageClick = onimageclick;
        this.mOnLongImageClick = onlongimageclick;
    }

    @NonNull
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.single_collection_img, (ViewGroup) null));
    }

    public void onBindViewHolder(final ViewHolder viewHolder, int i) {
        ((RequestBuilder) Glide.with(this.mActivity).load(this.images.get(viewHolder.getAdapterPosition())).diskCacheStrategy(DiskCacheStrategy.DATA)).into(viewHolder.mImageView);
        if (!DesignActivity.selectedSavedImage.isEmpty()) {
            viewHolder.mUnTick.setVisibility(View.VISIBLE);
        } else {
            viewHolder.mUnTick.setVisibility(View.INVISIBLE);
        }
        if (DesignActivity.selectedSavedImage.contains(this.images.get(viewHolder.getAdapterPosition()))) {
            viewHolder.mTick.setVisibility(View.VISIBLE);
        } else {
            viewHolder.mTick.setVisibility(View.INVISIBLE);
        }
        viewHolder.mImageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (!DesignActivity.selectedSavedImage.isEmpty()) {
                    if (viewHolder.mTick.getVisibility() == 4) {
                        viewHolder.mTick.setVisibility(View.VISIBLE);
                    } else {
                        viewHolder.mTick.setVisibility(View.INVISIBLE);
                    }
                }
                mOnImageClick.onImageClick((String) images.get(viewHolder.getAdapterPosition()));
            }
        });
        viewHolder.mImageView.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View view) {
                if (viewHolder.mTick.getVisibility() == 4) {
                    viewHolder.mTick.setVisibility(View.VISIBLE);
                } else {
                    viewHolder.mTick.setVisibility(View.INVISIBLE);
                }
                mOnLongImageClick.onLongImageClick(images.get(viewHolder.getAdapterPosition()));
                return true;
            }
        });
    }

    public int getItemCount() {
        return this.images.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView mImageView;
        ImageView mTick;
        ImageView mUnTick;

        public ViewHolder(View view) {
            super(view);
            this.mImageView = view.findViewById(R.id.singleGalleryImg);
            this.mTick = view.findViewById(R.id.tick);
            this.mUnTick = view.findViewById(R.id.unTick);
            DisplayMetrics displayMetrics = new DisplayMetrics();
            mActivity.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
            int dimension = (displayMetrics.widthPixels / 2) - ((int) mActivity.getResources().getDimension(R.dimen._2sdp));
            this.mImageView.getLayoutParams().width = dimension;
            this.mImageView.getLayoutParams().height = dimension;
        }
    }

    public void removeItem(String str) {
        if (this.images.contains(str)) {
            int i = 0;
            for (int i2 = 0; i2 < this.images.size(); i2++) {
                if (this.images.get(i2).equals(str)) {
                    i = i2;
                }
            }
            this.images.remove(str);
            notifyItemRemoved(i);
        }
    }
}
