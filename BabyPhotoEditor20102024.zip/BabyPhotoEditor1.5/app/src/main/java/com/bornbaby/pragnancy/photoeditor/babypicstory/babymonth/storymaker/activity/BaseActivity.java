package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.activity;

import android.content.Intent;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class BaseActivity extends AppCompatActivity {

    private ActivityResultLauncher<Intent> loadingLauncher;

    public static  void $r8$lambda$s8UhhmJvaaRLV0S9KmnyJvfDS8c(BaseActivity baseActivity, ActivityResult activityResult) {
        loadingLauncher$lambda$0(baseActivity, activityResult);
    }




    public BaseActivity() {
        this.loadingLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() {
            @Override
            public void onActivityResult(Object obj) {
                BaseActivity.$r8$lambda$s8UhhmJvaaRLV0S9KmnyJvfDS8c(BaseActivity.this, (ActivityResult) obj);
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    public final ActivityResultLauncher<Intent> getLoadingLauncher() {
        return this.loadingLauncher;
    }

    public final void setLoadingLauncher(ActivityResultLauncher<Intent> activityResultLauncher) {
        this.loadingLauncher = activityResultLauncher;
    }

    public static void loadingLauncher$lambda$0(BaseActivity this$0, ActivityResult result) {

    }
}