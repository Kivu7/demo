package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.adapter;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import java.util.ArrayList;
import java.util.List;

public class FrameViewPagerAdaptor extends FragmentPagerAdapter {
    private final List<Fragment> mList = new ArrayList();
    private final List<String> mTitleList = new ArrayList();

    public FrameViewPagerAdaptor(FragmentManager fragmentManager) {
        super(fragmentManager);
    }

    public Fragment getItem(int i) {
        return this.mList.get(i);
    }

    public int getCount() {
        return this.mList.size();
    }

    public void addFragment(Fragment fragment, String str) {
        this.mList.add(fragment);
        this.mTitleList.add(str);
    }

    public CharSequence getPageTitle(int i) {
        return this.mTitleList.get(i);
    }
}
