package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Shader;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.ads.rn.ads.RNAd;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.R;


import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.application.MyApplication;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.eraser.eraser.EraseView;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.eraser.eraser.MyExceptionHandlerPix;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.myAds.AdSDKPref;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.touchListeners.MultiTouchListener;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.Constant;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.Constants;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.ImageUtils;


public class EraserBgActivity extends AppCompatActivity implements View.OnClickListener {


    public static Bitmap f4458b = null;
    public static Bitmap bgCircleBit = null;
    public static Bitmap bitmap = null;
    public static int curBgType = 1;
    public static int orgBitHeight;
    public static int orgBitWidth;
    public static BitmapShader patternBMPshader;
    public Animation animSlideDown;
    public Animation animSlideUp;
    public ImageView back_btn;
    public ImageView dv1;
    public EraseView eraseView;
    public int height;
    private ImageView imageViewAuto;
    public ImageView imageViewBackgroundCover;
    ImageView imageViewCutInSide;
    ImageView imageViewCutOutSide;
    private ImageView imageViewEraser;
    private ImageView imageViewLasso;
    private ImageView imageViewRestore;
    private ImageView imageViewZoom;
    public boolean isTutOpen = true;
    private LinearLayout lay_lasso_cut;
    private LinearLayout linearLayoutAuto;
    private LinearLayout linearLayoutEraser;
    public RelativeLayout main_rel;
    private String openFrom;
    public Bitmap orgBitmap;
    private SeekBar radius_seekbar;
    ImageView redo_btn;
    public RelativeLayout relativeLayoutSeekBar;
    RelativeLayout relative_layout_loading;
    public ImageView save_btn;
    public Animation scale_anim;
    private SeekBar seekBarBrushOffset;
    private SeekBar seekBarExtractOffset;
    private SeekBar seekBarOffset;
    private SeekBar seekBarThreshold;
    public boolean showDialog = false;
    private TextView textViewAuto;
    private TextView textViewEraser;
    private TextView textViewLasso;
    private TextView textViewRestore;
    private TextView textViewZoom;
    ImageView undo_btn;
    public int width;
    private void loadAdaptiveBaner() {
        FrameLayout ad_view_container = findViewById(R.id.bannerView);

        if (AdSDKPref.getInstance(this).getString(AdSDKPref.TAG_ALL_AD_OFF, "0").equals("off") || AdSDKPref.getInstance(this).getString(AdSDKPref.TAG_BANNER_HOME_ONOFF, "0").equals("off")) {
            ad_view_container.setVisibility(View.GONE);
        } else {
            ad_view_container.setVisibility(View.VISIBLE);
            RNAd.getInstance().loadBanner(this, getString(R.string.banner_home));
        }
    }
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.activity_eraser_bg);
        loadAdaptiveBaner();
        Thread.setDefaultUncaughtExceptionHandler(new MyExceptionHandlerPix(this));
        this.openFrom = getIntent().getStringExtra(Constants.KEY_OPEN_FROM);
        this.animSlideUp = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.anim_slide_up);
        this.animSlideDown = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.anim_slide_down);
        this.scale_anim = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.anim_scale_anim);
        initUI();
        this.isTutOpen = false;
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int i = displayMetrics.heightPixels;
        this.width = displayMetrics.widthPixels;
        this.height = i - ImageUtils.dpToPx(this, 120.0f);
        curBgType = 1;
        this.main_rel.postDelayed(new Runnable() {
            public void run() {
                if (isTutOpen) {
                    ImageView imageView = imageViewBackgroundCover;

                    imageView.setImageBitmap(ImageUtils.getTiledBitmap(EraserBgActivity.this, R.drawable.tbg3, width, height));
                    bgCircleBit = ImageUtils.getBgCircleBit(EraserBgActivity.this, R.drawable.tbg3);
                } else {
                    ImageView imageView2 = imageViewBackgroundCover;

                    imageView2.setImageBitmap(ImageUtils.getTiledBitmap(EraserBgActivity.this, R.drawable.tbg2, width, height));
                    bgCircleBit = ImageUtils.getBgCircleBit(EraserBgActivity.this, R.drawable.tbg2);
                }
                importImageFromUri();
            }
        }, 1000);
    }

    private void initUI() {
        this.relativeLayoutSeekBar = findViewById(R.id.relativeLayoutSeekBar);
        this.textViewEraser = findViewById(R.id.textViewEraser);
        this.textViewAuto = findViewById(R.id.textViewAuto);
        this.textViewLasso = findViewById(R.id.textViewLasso);
        this.textViewRestore = findViewById(R.id.textViewRestore);
        this.textViewZoom = findViewById(R.id.textViewZoom);
        this.imageViewEraser = findViewById(R.id.imageViewEraser);
        this.imageViewAuto = findViewById(R.id.imageViewAuto);
        this.imageViewLasso = findViewById(R.id.imageViewLasso);
        this.imageViewRestore = findViewById(R.id.imageViewRestore);
        this.imageViewZoom = findViewById(R.id.imageViewZoom);
        this.relative_layout_loading = findViewById(R.id.relative_layout_loading);
        this.main_rel = findViewById(R.id.main_rel);
        this.linearLayoutAuto = findViewById(R.id.linearLayoutAuto);
        this.linearLayoutEraser = findViewById(R.id.linearLayoutEraser);
        this.lay_lasso_cut = findViewById(R.id.lay_lasso_cut);
        this.imageViewCutInSide = findViewById(R.id.imageViewCutInSide);
        this.imageViewCutOutSide = findViewById(R.id.imageViewCutOutSide);
        this.undo_btn = findViewById(R.id.imageViewUndo);
        this.redo_btn = findViewById(R.id.imageViewRedo);
        this.back_btn = findViewById(R.id.btn_back);
        this.save_btn = findViewById(R.id.save_image_btn);
        this.imageViewBackgroundCover = findViewById(R.id.imageViewBackgroundCover);
        this.back_btn.setOnClickListener(this);
        this.undo_btn.setOnClickListener(this);
        this.redo_btn.setOnClickListener(this);
        this.undo_btn.setEnabled(false);
        this.redo_btn.setEnabled(false);
        this.save_btn.setOnClickListener(this);
        this.imageViewCutInSide.setOnClickListener(this);
        this.imageViewCutOutSide.setOnClickListener(this);
        this.seekBarBrushOffset = findViewById(R.id.seekBarBrushOffset);
        this.seekBarOffset = findViewById(R.id.seekBarOffset);
        this.seekBarExtractOffset = findViewById(R.id.seekBarExtractOffset);
        this.seekBarBrushOffset.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                if (eraseView != null) {
                    eraseView.setOffset(i - 150);
                    eraseView.invalidate();
                }
            }
        });
        this.seekBarOffset.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                if (eraseView != null) {
                    eraseView.setOffset(i - 150);
                    eraseView.invalidate();
                }
            }
        });
        this.seekBarExtractOffset.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                if (eraseView != null) {
                    eraseView.setOffset(i - 150);
                    eraseView.invalidate();
                }
            }
        });
        SeekBar seekBar = findViewById(R.id.seekBarSize);
        this.radius_seekbar = seekBar;
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                if (eraseView != null) {
                    eraseView.setRadius(i + 2);
                    eraseView.invalidate();
                }
            }
        });
        SeekBar seekBar2 = findViewById(R.id.seekBarThreshold);
        this.seekBarThreshold = seekBar2;
        seekBar2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
            }

            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
                if (eraseView != null) {
                    eraseView.setThreshold(seekBar.getProgress() + 10);
                    eraseView.updateThreshHold();
                }
            }
        });
    }

    public void onClick(View view) {
        if (this.eraseView != null || view.getId() == R.id.btn_back) {
            int id = view.getId();
            if (id == R.id.btn_back) {
                onBackPressed();
                return;
            } else if (id == R.id.imageViewCutInSide) {
                this.eraseView.enableInsideCut(true);
                this.imageViewCutInSide.clearAnimation();
                this.imageViewCutOutSide.clearAnimation();
                return;
            } else if (id == R.id.imageViewCutOutSide) {
                this.eraseView.enableInsideCut(false);
                this.imageViewCutInSide.clearAnimation();
                this.imageViewCutOutSide.clearAnimation();
                return;
            } else if (id == R.id.imageViewRedo) {
                this.relative_layout_loading.setVisibility(View.VISIBLE);
                new Thread(new Runnable() {
                    public void run() {
                        try {
                            runOnUiThread(new Runnable() {
                                public void run() {
                                    eraseView.redoChange();
                                }
                            });
                            Thread.sleep(500);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        relative_layout_loading.setVisibility(View.GONE);
                    }
                }).start();
                return;
            } else if (id == R.id.imageViewUndo) {
                this.relative_layout_loading.setVisibility(View.VISIBLE);
                new Thread(new Runnable() {
                    public void run() {
                        try {
                            runOnUiThread(new Runnable() {
                                public void run() {
                                    eraseView.undoChange();
                                }
                            });
                            Thread.sleep(500);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        relative_layout_loading.setVisibility(View.GONE);
                    }
                }).start();
                return;
            } else if (id == R.id.relativeLayoutAuto) {
                eraseView.enableTouchClear(true);
                main_rel.setOnTouchListener(null);
                eraseView.setMODE(2);
                eraseView.invalidate();
                imageViewAuto.setColorFilter(getResources().getColor(R.color.mainColor));
                imageViewEraser.setColorFilter(getResources().getColor(R.color.iconColor));
                imageViewLasso.setColorFilter(getResources().getColor(R.color.iconColor));
                imageViewRestore.setColorFilter(getResources().getColor(R.color.iconColor));
                imageViewZoom.setColorFilter(getResources().getColor(R.color.iconColor));
                textViewAuto.setTextColor(getResources().getColor(R.color.mainColor));
                textViewEraser.setTextColor(getResources().getColor(R.color.iconColor));
                textViewLasso.setTextColor(getResources().getColor(R.color.iconColor));
                textViewRestore.setTextColor(getResources().getColor(R.color.iconColor));
                textViewZoom.setTextColor(getResources().getColor(R.color.iconColor));
                seekBarOffset.setProgress(this.eraseView.getOffset() + 150);
                linearLayoutEraser.setVisibility(View.GONE);
                linearLayoutAuto.setVisibility(View.VISIBLE);
                lay_lasso_cut.setVisibility(View.GONE);
                return;
            } else if (id == R.id.relativeLayoutBackground) {
                changeBG();
                return;
            } else if (id == R.id.relativeLayoutEraser) {
                eraseView.enableTouchClear(true);
                main_rel.setOnTouchListener((View.OnTouchListener) null);
                eraseView.setMODE(1);
                eraseView.invalidate();
                imageViewAuto.setColorFilter(getResources().getColor(R.color.iconColor));
                imageViewEraser.setColorFilter(getResources().getColor(R.color.mainColor));
                imageViewLasso.setColorFilter(getResources().getColor(R.color.iconColor));
                imageViewRestore.setColorFilter(getResources().getColor(R.color.iconColor));
                imageViewZoom.setColorFilter(getResources().getColor(R.color.iconColor));
                textViewAuto.setTextColor(getResources().getColor(R.color.iconColor));
                textViewEraser.setTextColor(getResources().getColor(R.color.mainColor));
                textViewLasso.setTextColor(getResources().getColor(R.color.iconColor));
                textViewRestore.setTextColor(getResources().getColor(R.color.iconColor));
                textViewZoom.setTextColor(getResources().getColor(R.color.iconColor));
                seekBarBrushOffset.setProgress(this.eraseView.getOffset() + 150);
                linearLayoutEraser.setVisibility(View.VISIBLE);
                linearLayoutAuto.setVisibility(View.GONE);
                lay_lasso_cut.setVisibility(View.GONE);
                return;
            } else if (id == R.id.relativeLayoutLasso) {
                eraseView.enableTouchClear(true);
                main_rel.setOnTouchListener((View.OnTouchListener) null);
                eraseView.setMODE(3);
                eraseView.invalidate();
                imageViewAuto.setColorFilter(getResources().getColor(R.color.iconColor));
                imageViewEraser.setColorFilter(getResources().getColor(R.color.iconColor));
                imageViewLasso.setColorFilter(getResources().getColor(R.color.mainColor));
                imageViewRestore.setColorFilter(getResources().getColor(R.color.iconColor));
                imageViewZoom.setColorFilter(getResources().getColor(R.color.iconColor));
                textViewAuto.setTextColor(getResources().getColor(R.color.iconColor));
                textViewEraser.setTextColor(getResources().getColor(R.color.iconColor));
                textViewLasso.setTextColor(getResources().getColor(R.color.mainColor));
                textViewRestore.setTextColor(getResources().getColor(R.color.iconColor));
                textViewZoom.setTextColor(getResources().getColor(R.color.iconColor));
                seekBarExtractOffset.setProgress(this.eraseView.getOffset() + 150);
                linearLayoutEraser.setVisibility(View.GONE);
                linearLayoutAuto.setVisibility(View.GONE);
                lay_lasso_cut.setVisibility(View.VISIBLE);
                return;
            } else if (id == R.id.relativeLayoutRestore) {
                eraseView.enableTouchClear(true);
                main_rel.setOnTouchListener((View.OnTouchListener) null);
                eraseView.setMODE(4);
                eraseView.invalidate();
                imageViewAuto.setColorFilter(getResources().getColor(R.color.iconColor));
                imageViewEraser.setColorFilter(getResources().getColor(R.color.iconColor));
                imageViewLasso.setColorFilter(getResources().getColor(R.color.iconColor));
                imageViewRestore.setColorFilter(getResources().getColor(R.color.mainColor));
                imageViewZoom.setColorFilter(getResources().getColor(R.color.iconColor));
                textViewAuto.setTextColor(getResources().getColor(R.color.iconColor));
                textViewEraser.setTextColor(getResources().getColor(R.color.iconColor));
                textViewLasso.setTextColor(getResources().getColor(R.color.iconColor));
                textViewRestore.setTextColor(getResources().getColor(R.color.mainColor));
                textViewZoom.setTextColor(getResources().getColor(R.color.iconColor));
                seekBarBrushOffset.setProgress(this.eraseView.getOffset() + 150);
                linearLayoutEraser.setVisibility(View.VISIBLE);
                linearLayoutAuto.setVisibility(View.GONE);
                lay_lasso_cut.setVisibility(View.GONE);
                return;
            } else if (id == R.id.relativeLayoutZoom) {
                eraseView.enableTouchClear(false);
                main_rel.setOnTouchListener(new MultiTouchListener());
                eraseView.setMODE(0);
                eraseView.invalidate();
                imageViewAuto.setColorFilter(getResources().getColor(R.color.iconColor));
                imageViewEraser.setColorFilter(getResources().getColor(R.color.iconColor));
                imageViewLasso.setColorFilter(getResources().getColor(R.color.iconColor));
                imageViewRestore.setColorFilter(getResources().getColor(R.color.iconColor));
                imageViewZoom.setColorFilter(getResources().getColor(R.color.mainColor));
                textViewAuto.setTextColor(getResources().getColor(R.color.iconColor));
                textViewEraser.setTextColor(getResources().getColor(R.color.iconColor));
                textViewLasso.setTextColor(getResources().getColor(R.color.iconColor));
                textViewRestore.setTextColor(getResources().getColor(R.color.iconColor));
                textViewZoom.setTextColor(getResources().getColor(R.color.mainColor));
                linearLayoutEraser.setVisibility(View.GONE);
                linearLayoutAuto.setVisibility(View.GONE);
                lay_lasso_cut.setVisibility(View.GONE);
                return;
            } else if (id == R.id.save_image_btn) {
                SaveView();
                return;
            }
        } else {
            Toast.makeText(this, getResources().getString(R.string.import_img_warning), Toast.LENGTH_SHORT).show();
        }
    }

    private void SaveView() {
        Bitmap finalBitmap = this.eraseView.getFinalBitmap();
        bitmap = finalBitmap;
        if (finalBitmap != null) {
            try {
                int dpToPx = ImageUtils.dpToPx((Context) this, 42.0f);
                Bitmap resizeBitmap = ImageUtils.resizeBitmap(bitmap, orgBitWidth + dpToPx + dpToPx, orgBitHeight + dpToPx + dpToPx);
                bitmap = resizeBitmap;
                int i = dpToPx + dpToPx;
                Bitmap createBitmap = Bitmap.createBitmap(resizeBitmap, dpToPx, dpToPx, resizeBitmap.getWidth() - i, bitmap.getHeight() - i);
                bitmap = createBitmap;
                Bitmap createScaledBitmap = Bitmap.createScaledBitmap(createBitmap, orgBitWidth, orgBitHeight, true);
                bitmap = createScaledBitmap;
                bitmap = ImageUtils.bitmapmasking(this.orgBitmap, createScaledBitmap);
                if (this.openFrom.equalsIgnoreCase(Constants.VALUE_OPEN_FROM_REMOVE_BG)) {
                    Constant.Cutout = bitmap;
                }
                setResult(-1, new Intent());
                finish();
            } catch (OutOfMemoryError e) {
                e.printStackTrace();
            }
        } else {
            finish();
        }
    }

    private void changeBG() {
        int i = curBgType;
        if (i == 1) {
            curBgType = 2;
            this.imageViewBackgroundCover.setImageBitmap(null);
            this.imageViewBackgroundCover.setImageBitmap(ImageUtils.getTiledBitmap(this, R.drawable.tbg1, this.width, this.height));
            bgCircleBit = ImageUtils.getBgCircleBit(this, R.drawable.tbg1);
        } else if (i == 2) {
            curBgType = 3;
            this.imageViewBackgroundCover.setImageBitmap(null);
            this.imageViewBackgroundCover.setImageBitmap(ImageUtils.getTiledBitmap(this, R.drawable.tbg, this.width, this.height));
            bgCircleBit = ImageUtils.getBgCircleBit(this, R.drawable.tbg);
        } else if (i == 3) {
            curBgType = 4;
            this.imageViewBackgroundCover.setImageBitmap(null);
            this.imageViewBackgroundCover.setImageBitmap(ImageUtils.getTiledBitmap(this, R.drawable.tbg3, this.width, this.height));
            bgCircleBit = ImageUtils.getBgCircleBit(this, R.drawable.tbg3);
        } else if (i == 4) {
            curBgType = 5;
            this.imageViewBackgroundCover.setImageBitmap(null);
            this.imageViewBackgroundCover.setImageBitmap(ImageUtils.getTiledBitmap(this, R.drawable.tbg4, this.width, this.height));
            bgCircleBit = ImageUtils.getBgCircleBit(this, R.drawable.tbg4);
        } else if (i == 5) {
            curBgType = 6;
            this.imageViewBackgroundCover.setImageBitmap(null);
            this.imageViewBackgroundCover.setImageBitmap(ImageUtils.getTiledBitmap(this, R.drawable.tbg5, this.width, this.height));
            bgCircleBit = ImageUtils.getBgCircleBit(this, R.drawable.tbg5);
        } else if (i == 6) {
            curBgType = 1;
            this.imageViewBackgroundCover.setImageBitmap(null);
            this.imageViewBackgroundCover.setImageBitmap(ImageUtils.getTiledBitmap(this, R.drawable.tbg2, this.width, this.height));
            bgCircleBit = ImageUtils.getBgCircleBit(this, R.drawable.tbg2);
        }
    }

    public void importImageFromUri() {
        this.showDialog = false;
        final ProgressDialog show = ProgressDialog.show(this, "", getResources().getString(R.string.importing_image), true);
        show.setCancelable(false);
        new Thread(new Runnable() {
            public void run() {
                try {
                    if (f4458b == null) {
                        showDialog = true;
                    } else {
                        orgBitmap = f4458b.copy(f4458b.getConfig(), true);
                        int dpToPx = ImageUtils.dpToPx(EraserBgActivity.this, 42.0f);
                        orgBitWidth = f4458b.getWidth();
                        orgBitHeight = f4458b.getHeight();
                        Bitmap createBitmap = Bitmap.createBitmap(f4458b.getWidth() + dpToPx + dpToPx, f4458b.getHeight() + dpToPx + dpToPx, f4458b.getConfig());
                        Canvas canvas = new Canvas(createBitmap);
                        canvas.drawColor(0);
                        float f = (float) dpToPx;
                        canvas.drawBitmap(f4458b, f, f, null);
                        f4458b = createBitmap;
                        if (f4458b.getWidth() > width || f4458b.getHeight() > height || (f4458b.getWidth() < width && f4458b.getHeight() < height)) {
                            f4458b = ImageUtils.resizeBitmap(f4458b, width, height);
                        }
                    }
                    Thread.sleep(1000);
                } catch (OutOfMemoryError | Exception e) {
                    e.printStackTrace();
                    showDialog = true;
                    show.dismiss();
                }
                show.dismiss();
            }
        }).start();
        show.setOnDismissListener(new DialogInterface.OnDismissListener() {
            public void onDismiss(DialogInterface dialogInterface) {
                if (showDialog) {

                    Toast.makeText(EraserBgActivity.this, getResources().getString(R.string.import_error), Toast.LENGTH_SHORT).show();
                    finish();
                    return;
                }
                setImageBitmap();
            }
        });
    }

    public void setImageBitmap() {
        eraseView = new EraseView(this);
        dv1 = new ImageView(this);
        eraseView.setImageBitmap(f4458b);
        dv1.setImageBitmap(getGreenLayerBitmap(f4458b));
        eraseView.invalidate();
        eraseView.enableTouchClear(true);
        main_rel.setOnTouchListener(null);
        eraseView.setMODE(1);
        eraseView.invalidate();
        seekBarBrushOffset.setProgress(this.eraseView.getOffset() + 150);
        radius_seekbar.setProgress(18);
        seekBarThreshold.setProgress(20);
        main_rel.removeAllViews();
        main_rel.setScaleX(1.0f);
        main_rel.setScaleY(1.0f);
        main_rel.addView(this.dv1);
        main_rel.addView(this.eraseView);
        eraseView.invalidate();
        dv1.setVisibility(View.GONE);
        eraseView.setUndoRedoListener(new EraseView.UndoRedoListener() {
            public void enableUndo(boolean z, int i) {
                if (z) {

                    setBGDrawable(i, undo_btn, R.drawable.ic_undo_active, z);
                    return;
                }

                setBGDrawable(i, undo_btn, R.drawable.ic_undo_new, z);
            }

            public void enableRedo(boolean z, int i) {
                if (z) {

                    setBGDrawable(i, redo_btn, R.drawable.ic_redo_active, z);
                    return;
                }

                setBGDrawable(i, redo_btn, R.drawable.ic_redo, z);
            }
        });
        f4458b.recycle();
        this.eraseView.setActionListener(new EraseView.ActionListener() {
            public void onActionCompleted(final int i) {
                runOnUiThread(new Runnable() {
                    public void run() {
                    }
                });
            }

            public void onAction(int i) {
                runOnUiThread(new Runnable() {
                    public void run() {
                    }
                });
            }
        });
    }

    public void setBGDrawable(int i, final ImageView imageView, final int i2, final boolean z) {
        runOnUiThread(new Runnable() {
            public void run() {
                imageView.setImageResource(i2);
                imageView.setEnabled(z);
            }
        });
    }

    public Bitmap getGreenLayerBitmap(Bitmap bitmap2) {
        Paint paint = new Paint();
        paint.setColor(-16711936);
        paint.setAlpha(80);
        int dpToPx = ImageUtils.dpToPx(this, 42.0f);
        Bitmap createBitmap = Bitmap.createBitmap(orgBitWidth + dpToPx + dpToPx, orgBitHeight + dpToPx + dpToPx, bitmap2.getConfig());
        Canvas canvas = new Canvas(createBitmap);
        canvas.drawColor(0);
        float f = (float) dpToPx;
        canvas.drawBitmap(this.orgBitmap, f, f, null);
        canvas.drawRect(f, f, (float) (orgBitWidth + dpToPx), (float) (orgBitHeight + dpToPx), paint);
        Bitmap createBitmap2 = Bitmap.createBitmap(orgBitWidth + dpToPx + dpToPx, orgBitHeight + dpToPx + dpToPx, bitmap2.getConfig());
        Canvas canvas2 = new Canvas(createBitmap2);
        canvas2.drawColor(0);
        canvas2.drawBitmap(this.orgBitmap, f, f, null);
        patternBMPshader = new BitmapShader(ImageUtils.resizeBitmap(createBitmap2, this.width, this.height), Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
        return ImageUtils.resizeBitmap(createBitmap, this.width, this.height);
    }

    public void onDestroy() {
        Bitmap bitmap2 = f4458b;
        if (bitmap2 != null) {
            bitmap2.recycle();
            f4458b = null;
        }
        try {
            if (!isFinishing() && this.eraseView.f4466pd != null && this.eraseView.f4466pd.isShowing()) {
                this.eraseView.f4466pd.dismiss();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();

    }



}
