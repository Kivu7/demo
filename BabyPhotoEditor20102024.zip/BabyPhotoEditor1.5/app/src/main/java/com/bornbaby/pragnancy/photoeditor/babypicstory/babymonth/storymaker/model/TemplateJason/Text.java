package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.TemplateJason;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import java.io.Serializable;

public class Text implements Serializable {
    @SerializedName("alignment")
    @Expose
    private String alignment;
    @SerializedName("argb")
    @Expose
    private String argb;
    @SerializedName("font_name")
    @Expose
    private String fontName;
    @SerializedName("font_size")
    @Expose
    private Double fontSize;
    @SerializedName("kern")
    @Expose
    private Double kern;
    @SerializedName("line_height_multiple")
    @Expose
    private Double lineHeightMultiple;
    @SerializedName("value")
    @Expose
    private String value;

    public String getValue() {
        return this.value;
    }

    public void setValue(String str) {
        this.value = str;
    }

    public String getFontName() {
        return this.fontName;
    }

    public void setFontName(String str) {
        this.fontName = str;
    }

    public Double getFontSize() {
        return this.fontSize;
    }

    public void setFontSize(Double d) {
        this.fontSize = d;
    }

    public String getArgb() {
        return this.argb;
    }

    public void setArgb(String str) {
        this.argb = str;
    }

    public String getAlignment() {
        return this.alignment;
    }

    public void setAlignment(String str) {
        this.alignment = str;
    }

    public Double getKern() {
        return this.kern;
    }

    public void setKern(Double d) {
        this.kern = d;
    }

    public Double getLineHeightMultiple() {
        return this.lineHeightMultiple;
    }

    public void setLineHeightMultiple(Double d) {
        this.lineHeightMultiple = d;
    }
}
