package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils;

import okhttp3.MultipartBody;
import okhttp3.ResponseBody;
import retrofit2.http.Headers;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import rx.Observable;

public interface ApiDetail {
    @Multipart
    @POST("DexNewGrabcut")
    @Headers({"Host:prodml.dexati.com"})
    Observable<ResponseBody> uploadFile(@Part MultipartBody.Part part);
}
