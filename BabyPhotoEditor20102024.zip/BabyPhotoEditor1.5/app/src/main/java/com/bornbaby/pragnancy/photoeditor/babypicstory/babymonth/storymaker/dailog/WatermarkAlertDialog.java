package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.dailog;

import android.animation.ObjectAnimator;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.R;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.activity.PremiumActivity;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.application.MyApplication;


public class WatermarkAlertDialog extends DialogFragment {

    private ObjectAnimator duration2;
    private DialogFinishListner adListner;

    public void setVideoListner(DialogFinishListner adListner) {
        this.adListner = adListner;
    }

    public static WatermarkAlertDialog newInstance(String s) {
        Bundle bundle = new Bundle();
        WatermarkAlertDialog alertDialog = new WatermarkAlertDialog();
        bundle.putString("disc", s);
        alertDialog.setArguments(bundle);
        return alertDialog;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        setStyle(STYLE_NORMAL, R.style.AppAlertDialogExit);
        if (getDialog() != null && getDialog().getWindow() != null) {
            getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            getDialog().getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        }
        return super.onCreateView(inflater, container, savedInstanceState);

    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
        View view = LayoutInflater.from(getActivity()).inflate(R.layout.alert_watermark_dialog, null);

        TextView tvSubmit = view.findViewById(R.id.tvSubmit);
        ProgressBar progressBar2 = view.findViewById(R.id.progress_bar_rwm);
        TextView textView2 = view.findViewById(R.id.txtWatchAds_rwm);
        duration2 = ObjectAnimator.ofInt(progressBar2, "progress", progressBar2.getProgress(), 100).setDuration((long) (5 * 1000));
        duration2.setInterpolator(new LinearInterpolator());
        duration2.addUpdateListener(new WatermarkAnimClassnew(getActivity(), progressBar2, textView2, WatermarkAlertDialog.this, adListner));
        duration2.start();
        if (MyApplication.getInstance().mTemplateListActivity != null) {
            MyApplication.getInstance().mTemplateListActivity.isWatermarkdailogClose = false;
            MyApplication.getInstance().mTemplateListActivity.callBackForRewardedInt = adListner;
            MyApplication.getInstance().mTemplateListActivity.loadAdRewardedIntForPremiumItem();
        }
        duration2.addListener(new WatermarkListenerNew(getActivity(), 1));

        ImageView imgClose = view.findViewById(R.id.iv_closedialog_rwm);

        TextView txt_header_sub = view.findViewById(R.id.description_rwm);
        txt_header_sub.setText(getString(R.string.watch_the_rewarded_video_and_unlock_this_premium) + " " + getArguments().getString("disc") + "!");
        tvSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    MyApplication.getInstance().EventRegister("Rewarded_Int_Dialog_Close", new Bundle());
                    MyApplication.getInstance().EventRegister("Dialog_Close_For_Unlock_" + MyApplication.getInstance().mCurrentUnlockItemName, new Bundle());
                    if (MyApplication.getInstance().mTemplateListActivity != null) {
                        MyApplication.getInstance().mTemplateListActivity.isWatermarkdailogClose = true;
                    }
                    duration2.removeAllListeners();
                    dismiss();
                } catch (Exception e) {

                }
                startActivity(new Intent(getActivity(), PremiumActivity.class));
            }
        });
        imgClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    MyApplication.getInstance().EventRegister("Rewarded_Int_Dialog_Close", new Bundle());
                    MyApplication.getInstance().EventRegister("Dialog_Close_For_Unlock_" + MyApplication.getInstance().mCurrentUnlockItemName, new Bundle());
                    if (MyApplication.getInstance().mTemplateListActivity != null) {
                        MyApplication.getInstance().mTemplateListActivity.isWatermarkdailogClose = true;
                    }
                    duration2.removeAllListeners();
                    dismiss();
                } catch (Exception e) {

                }
            }
        });

        builder.setView(view);
        return builder.create();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        try {
            if (duration2 != null) {
                duration2.removeAllListeners();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (getDialog() != null && getDialog().isShowing()) {
            dismiss();
        }
    }
}