package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Html;
import android.text.SpannableString;
import android.text.method.LinkMovementMethod;
import android.text.style.StyleSpan;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.core.content.ContextCompat;

import com.ads.sdk.admob.AdsConsentManager;
import com.ads.sdk.admob.AppOpenManager;
import com.ads.sdk.ads.SdkAd;
import com.ads.sdk.funtion.AdCallback;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.R;

import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.application.MyApplication;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.myAds.Log;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.PrefManager;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.ump.FormError;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;


public   class SplashScreen extends AppCompatActivity {

    private final AtomicBoolean isMobileAdsInitializeCalled = new AtomicBoolean(false);

    private AppCompatButton btnGetStartedChecked;
    private AppCompatCheckBox cbPrivacy;

    RelativeLayout bottomads;


    boolean isEnableUMP = true;
    SharedPreferences sharedPreferences;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_splash_screen);

        TextView tvPolicy = findViewById(R.id.tvPolicy);
        LinearLayout privacyPolicyLayout = findViewById(R.id.privacyLay);
        this.cbPrivacy = findViewById(R.id.cbPrivacy);
        bottomads = findViewById(R.id.bottomads);
        this.btnGetStartedChecked = findViewById(R.id.btnGetStartedChecked);
         sharedPreferences = getSharedPreferences("first_time_preference", MODE_PRIVATE);

        if (PrefManager.getInstance(this).isPrivacyPolicyAccepted()) {
            privacyPolicyLayout.setVisibility(View.GONE);
            bottomads.setVisibility(View.VISIBLE);
            String android_id = Settings.Secure.getString(this.getContentResolver(), Settings.Secure.ANDROID_ID);
            String deviceId = md5(android_id).toUpperCase();

            if (isEnableUMP) {

                adsConsentManager = new AdsConsentManager(this);

                adsConsentManager.requestUMP(

                        true,

                        deviceId,

                        false,

                        canRequestAds -> runOnUiThread(this::loadSplash)

                );

            } else {

                SdkAd.getInstance().initAdsNetwork();

                loadSplash();

            }
            return;
        }
        privacyPolicyLayout.setVisibility(View.VISIBLE);
        bottomads.setVisibility(View.GONE);
        SpannableString spannableString = new SpannableString(" Privacy Policy ");
        spannableString.setSpan(new StyleSpan(1), 0, spannableString.length(), 0);

        tvPolicy.setText(Html.fromHtml("By clicking Get Started button, you are agree to the <a href='" + getString(R.string.privacy_policy_link) + "'><b> Privacy Policy</b></a> and <a href='" + getString(R.string.Terms_link) + "'><b>Terms & Conditions </b></a>"));
        tvPolicy.setMovementMethod(LinkMovementMethod.getInstance());
        tvPolicy.setLinkTextColor(ContextCompat.getColor(this, R.color.color_primary));
        this.cbPrivacy.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                if (z) {
                    if (Build.VERSION.SDK_INT >= 21) {
                        btnGetStartedChecked.setBackgroundTintList(ContextCompat.getColorStateList(SplashScreen.this, R.color.color_primary));
                    }
                    btnGetStartedChecked.setTextColor(ContextCompat.getColor(SplashScreen.this, R.color.white));
                } else {
                    btnGetStartedChecked.setTextColor(ContextCompat.getColor(SplashScreen.this, R.color.black));
                    if (Build.VERSION.SDK_INT >= 21) {
                        btnGetStartedChecked.setBackgroundTintList(ContextCompat.getColorStateList(SplashScreen.this, R.color.disable_bg));
                    }
                }
                btnGetStartedChecked.setEnabled(z);
            }
        });
        this.btnGetStartedChecked.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                if (cbPrivacy.isChecked()) {
                    PrefManager.getInstance(SplashScreen.this).setPrivacyPolicyAccepted(true);
                    launchFurtherScreen();
                }
            }
        });


    }

    public String md5(final String s) {
        try {
            // Create MD5 Hash
            MessageDigest digest = java.security.MessageDigest
                    .getInstance("MD5");
            digest.update(s.getBytes());
            byte messageDigest[] = digest.digest();

            // Create Hex String
            StringBuffer hexString = new StringBuffer();
            for (int i = 0; i < messageDigest.length; i++) {
                String h = Integer.toHexString(0xFF & messageDigest[i]);
                while (h.length() < 2)
                    h = "0" + h;
                hexString.append(h);
            }
            return hexString.toString();

        } catch (NoSuchAlgorithmException e) {
        }
        return "";
    }
    private void loadSplash() {

//        preLoadNativeAd();
        AppOpenManager.getInstance().loadOpenAppAdSplash(
                this,
                MyApplication.getApplication().appopenResumeId,
                5000,
                20000,
                false,
                new AdCallback() {
                    @Override
                    public void onAdSplashReady() {
                        super.onAdSplashReady();

                        android.util.Log.e("EEEEEEE", "==>" + "onAdSplashReady");

                        if (isDestroyed() || isFinishing()) return;
                        showAdsOpenAppSplash();
                    }

                    @Override
                    public void onNextAction() {
                        super.onNextAction();
                        android.util.Log.e("EEEEEEE", "==>" + "onNextAction");
                        if (isDestroyed() || isFinishing()) return;
                        MyApplication.getApplication().isAdCloseSplash.postValue(true);
                        navigateToNextScreen();
                    }

                    @Override
                    public void onAdFailedToLoad(@Nullable LoadAdError i) {
                        super.onAdFailedToLoad(i);
                        android.util.Log.e("EEEEEEE", "==>" + "onAdFailedToLoad");
                        if (isDestroyed() || isFinishing()) return;
                        MyApplication.getApplication().isAdCloseSplash.postValue(true);
                        navigateToNextScreen();
                    }
                }
        );



    }

    private void showAdsOpenAppSplash() {
        android.util.Log.e("AAAA", "showAdsOpenAppSplash");
        AppOpenManager.getInstance().showAppOpenSplash(
                this,
                new AdCallback() {
                    @Override
                    public void onNextAction() {
                        super.onNextAction();
                        if (isDestroyed() || isFinishing()) return;
                        navigateToNextScreen();
                    }

                    @Override
                    public void onAdFailedToShow(@Nullable AdError adError) {
                        super.onAdFailedToShow(adError);
                        if (isDestroyed() || isFinishing()) return;
                        MyApplication.getApplication().isAdCloseSplash.postValue(true);
                        navigateToNextScreen();
                    }

                    @Override
                    public void onAdClosed() {
                        super.onAdClosed();
                        if (isDestroyed() || isFinishing()) return;
                        MyApplication.getApplication().isAdCloseSplash.postValue(true);
                        navigateToNextScreen();
                    }
                }
        );
    }

    private void navigateToNextScreen() {

        if (isDestroyed() || isFinishing()) {
            return;
        }
        loadMainActivity();

    }



    protected void onStop() {
        super.onStop();
    }

    protected void onDestroy() {
        System.gc();
        super.onDestroy();
    }

    public void launchFurtherScreen() {
        loadMainActivity();
    }

    private void loadMainActivity() {

        if (!isLanguageSet()) {
            launchLanguageSelectionScreen();
        } else {
            launchContentListScreen();
        }
        finish();
    }

    private boolean isLanguageSet() {
        String languageCode = new PrefManager(this).getLanguageCode();
        return languageCode != null && !languageCode.trim().isEmpty();
    }

    public void launchLanguageSelectionScreen() {
        Intent intent = new Intent(this, LanguageSelectActivity.class);

        startActivity(intent);
        finish();
    }


    public void launchContentListScreen() {
        Intent intent = new Intent(this, HomeActivity.class);
        startActivity(intent);
        finish();
    }

    public static final void onCreate$lambda$0(SplashScreen this$0, FormError formError) {

        if (formError != null) {

            String format = String.format("%s: %s", Arrays.copyOf(new Object[]{Integer.valueOf(formError.getErrorCode()), formError.getMessage()}, 2));
            Log.w("SplashActivity", format);
        }

        this$0.checkPurchase();
    }

    private final void initializeMobileAdsSdk() {
        if (this.isMobileAdsInitializeCalled.getAndSet(true)) {
            return;
        }

        MobileAds.initialize(this, new OnInitializationCompleteListener() { // from class: com.ai.faceswap.scences.splash.SplashActivity$$ExternalSyntheticLambda4
            @Override // com.google.android.gms.ads.initialization.OnInitializationCompleteListener
            public final void onInitializationComplete(InitializationStatus initializationStatus) {

            }
        });
    }

    private final void checkPurchase() {
        BillingClient build = BillingClient.newBuilder(this).enablePendingPurchases().setListener(new PurchasesUpdatedListener() { // from class: com.ai.faceswap.scences.splash.SplashActivity$$ExternalSyntheticLambda1
            @Override // com.android.billingclient.api.PurchasesUpdatedListener
            public final void onPurchasesUpdated(BillingResult billingResult, List list) {

            }
        }).build();


        build.startConnection(new SplashActivityBilling(build, this));
    }


    public final void loadData(boolean z) {
        if (z) {
            runOnUiThread(new Runnable() {
                @Override // java.lang.Runnable
                public final void run() {
                    SplashScreen.loadData$lambda$3(SplashScreen.this);
                }
            });
        }

    }


    public static void loadData$lambda$3(SplashScreen this$0) {

    }



}