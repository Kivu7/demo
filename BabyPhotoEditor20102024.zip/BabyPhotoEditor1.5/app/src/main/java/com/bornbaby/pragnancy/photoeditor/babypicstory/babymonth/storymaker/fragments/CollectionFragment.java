package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.fragments;

import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.adapter.CollectionAdapter;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.R;
import java.io.File;
import java.util.ArrayList;

public class CollectionFragment extends Fragment {
    ArrayList<String> collectionImages = new ArrayList<>();
    RecyclerView mRecyclerView;

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.collection_layout, viewGroup, false);
        this.mRecyclerView = inflate.findViewById(R.id.categoryListRecycle);
        new Thread(new Runnable() {
            public void run() {
                File[] listFiles;
                File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)+ "/Template");
                if (file.exists() && (listFiles = file.listFiles()) != null && listFiles.length != 0) {
                    for (File path : listFiles) {
                        collectionImages.add(path.getPath());
                    }
                }
            }
        }).start();
        return inflate;
    }

}
