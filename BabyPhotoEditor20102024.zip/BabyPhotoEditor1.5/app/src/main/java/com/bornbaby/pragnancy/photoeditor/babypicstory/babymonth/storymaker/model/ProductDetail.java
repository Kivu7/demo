package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ProductDetail {
    @SerializedName("isPro")
    @Expose
    private Boolean isPro;
    @SerializedName("Preview")
    @Expose
    private String preview;

    public Boolean getIsPro() {
        return this.isPro;
    }

    public void setIsPro(Boolean bool) {
        this.isPro = bool;
    }

    public String getPreview() {
        return this.preview;
    }

    public void setPreview(String str) {
        this.preview = str;
    }
}
