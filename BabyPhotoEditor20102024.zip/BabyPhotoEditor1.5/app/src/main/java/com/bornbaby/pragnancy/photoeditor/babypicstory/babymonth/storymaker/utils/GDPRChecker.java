package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils;

import android.app.Activity;
import android.util.Log;

import com.google.android.ump.ConsentForm;
import com.google.android.ump.ConsentInformation;
import com.google.android.ump.ConsentRequestParameters;
import com.google.android.ump.FormError;
import com.google.android.ump.UserMessagingPlatform;

public class GDPRChecker {
    private static GDPRChecker instance = null;
    
    public static int status = 2;
    
    public ConsentForm consentForm;
    
    public ConsentInformation consentInformation;
    
    public Activity context;
    private String privacyUrl;
    private String[] publisherIds;

    protected GDPRChecker(Activity activity) {
        this.context = activity;
        this.consentInformation = UserMessagingPlatform.getConsentInformation(activity);
    }

    public GDPRChecker() {
    }

    public GDPRChecker withContext(Activity activity) {
        GDPRChecker gDPRChecker = new GDPRChecker(activity);
        instance = gDPRChecker;
        return gDPRChecker;
    }

    public GDPRChecker withPrivacyUrl(String str) {
        this.privacyUrl = str;
        GDPRChecker gDPRChecker = instance;
        if (gDPRChecker != null) {
            return gDPRChecker;
        }
        throw new NullPointerException("Please call withContext first");
    }

    private void initGDPR() {
        if (this.publisherIds != null) {
            this.consentInformation.requestConsentInfoUpdate(this.context, new ConsentRequestParameters.Builder().setTagForUnderAgeOfConsent(false).build(), new ConsentInformation.OnConsentInfoUpdateSuccessListener() {
                public void onConsentInfoUpdateSuccess() {
                    if (consentInformation.isConsentFormAvailable()) {
                        Log.w("PTag", "Ram 1");
                        loadForm();
                    }
                }
            }, new ConsentInformation.OnConsentInfoUpdateFailureListener() {
                public void onConsentInfoUpdateFailure(FormError formError) {
                    Log.w("PTag", "Ram 3");
                    loadForm();
                }
            });
            return;
        }
        throw new NullPointerException("publisherIds is null, please call withPublisherIds first");
    }

    
    public void loadForm() {
        UserMessagingPlatform.loadConsentForm(this.context, new UserMessagingPlatform.OnConsentFormLoadSuccessListener() {
            public void onConsentFormLoadSuccess(ConsentForm consentForm) {
                consentForm = consentForm;
                if (consentInformation.getConsentStatus() == 2) {
                    consentForm.show(context, new ConsentForm.OnConsentFormDismissedListener() {
                        public void onConsentFormDismissed(FormError formError) {
                            Log.w("PTag", "Ram 4");
                            loadForm();
                        }
                    });
                } else {
                    Log.w("PTag", "Ram 5");
                }
                GDPRChecker.status = consentInformation.getConsentStatus();
            }
        }, new UserMessagingPlatform.OnConsentFormLoadFailureListener() {
            public void onConsentFormLoadFailure(FormError formError) {
                Log.w("PTag", "Ram 6");
            }
        });
    }

    public void check() {
        initGDPR();
    }

    public GDPRChecker withPublisherIds(String... strArr) {
        this.publisherIds = strArr;
        GDPRChecker gDPRChecker = instance;
        if (gDPRChecker != null) {
            return gDPRChecker;
        }
        throw new NullPointerException("Please call withContext first");
    }

    public static int getStatus() {
        return status;
    }
}
