package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.adapter.InnerViewPagerAdapter;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.R;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.Constant;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.CustomViewPager;
import java.util.ArrayList;

public class CategoryFragment extends Fragment {
    TextView collageBtn;
    
    public int currentSelectedTab = 1;
    private ArrayList<Fragment> fragments;
    
    public TextView frameBtn;
    
    public TextView generalBtn;
    
    public CustomViewPager mCustomViewPager;

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.catagory_fragment, viewGroup, false);
        this.mCustomViewPager = inflate.findViewById(R.id.innerViewPager);
        this.generalBtn = inflate.findViewById(R.id.general);
        this.collageBtn = inflate.findViewById(R.id.collage);
        this.frameBtn = inflate.findViewById(R.id.frame);
        RelativeLayout rvGeneralTab = inflate.findViewById(R.id.rvGeneralTab);
        RelativeLayout rvCollageTab = inflate.findViewById(R.id.rvCollageTab);
        RelativeLayout rvFrameTab = inflate.findViewById(R.id.rvFrameTab);
        this.generalBtn.setTypeface(Constant.TYPEFACE);
        this.collageBtn.setTypeface(Constant.TYPEFACE);
        this.frameBtn.setTypeface(Constant.TYPEFACE);
        this.collageBtn.setBackgroundResource(0);
        this.frameBtn.setBackgroundResource(0);
        if (!this.fragments.isEmpty()) {
            this.fragments.add(new CategoryListFragment().newInstance(2));
            this.fragments.add(new CategoryListFragment().newInstance(3));
            this.fragments.add(new CategoryListFragment().newInstance(1));
        }
        this.mCustomViewPager.setAdapter(new InnerViewPagerAdapter(getActivity().getSupportFragmentManager(), 1, this.fragments));
        this.mCustomViewPager.setPagingEnabled(false);
        this.mCustomViewPager.setOffscreenPageLimit(3);
        this.generalBtn.setTextColor(ContextCompat.getColor(getActivity(), R.color.white));
        this.generalBtn.setBackgroundResource(R.drawable.tab_collage);
        rvGeneralTab.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (currentSelectedTab != 1) {
                    currentSelectedTab = 1;
                    generalBtn.setTextColor(ContextCompat.getColor(getActivity(), R.color.white));
                    generalBtn.setBackgroundResource(R.drawable.tab_collage);
                    collageBtn.setTextColor(ContextCompat.getColor(getActivity(), R.color.black));
                    collageBtn.setBackgroundResource(0);
                    frameBtn.setBackgroundResource(0);
                    frameBtn.setTextColor(ContextCompat.getColor(getActivity(), R.color.black));
                    mCustomViewPager.setCurrentItem(0);
                }
            }
        });
        rvCollageTab.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (currentSelectedTab != 2) {
                     currentSelectedTab = 2;
                    collageBtn.setBackgroundResource(R.drawable.tab_collage);
                    collageBtn.setTextColor(ContextCompat.getColor(getActivity(), R.color.white));
                    generalBtn.setBackgroundResource(0);
                    generalBtn.setTextColor(ContextCompat.getColor(getActivity(), R.color.black));
                    frameBtn.setBackgroundResource(0);
                    frameBtn.setTextColor(ContextCompat.getColor(getActivity(), R.color.black));
                    mCustomViewPager.setCurrentItem(1);
                }
            }
        });
        rvFrameTab.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (currentSelectedTab != 3) {
                     currentSelectedTab = 3;
                    frameBtn.setBackgroundResource(R.drawable.tab_collage);
                    frameBtn.setTextColor(ContextCompat.getColor(getActivity(), R.color.white));
                    collageBtn.setBackgroundResource(0);
                    collageBtn.setTextColor(ContextCompat.getColor(getActivity(), R.color.black));
                    generalBtn.setBackgroundResource(0);
                    generalBtn.setTextColor(ContextCompat.getColor(getActivity(), R.color.black));
                    mCustomViewPager.setCurrentItem(2);
                }
            }
        });
        return inflate;
    }
}
