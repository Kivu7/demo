package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.TemplateJason;

import java.io.Serializable;

public class Overlay_image_coordinate implements Serializable {
    private int height;
    private int width;
    private int x;
    private int y;

    public void setX(int i) {
        this.x = i;
    }

    public int getX() {
        return this.x;
    }

    public void setY(int i) {
        this.y = i;
    }

    public int getY() {
        return this.y;
    }

    public void setWidth(int i) {
        this.width = i;
    }

    public int getWidth() {
        return this.width;
    }

    public void setHeight(int i) {
        this.height = i;
    }

    public int getHeight() {
        return this.height;
    }
}
