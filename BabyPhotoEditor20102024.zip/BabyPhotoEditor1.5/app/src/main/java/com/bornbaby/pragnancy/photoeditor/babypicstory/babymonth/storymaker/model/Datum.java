package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import java.util.List;

public class Datum {
    @SerializedName("cat_id")
    @Expose
    private String catId;
    @SerializedName("cat_name")
    @Expose
    private String catName;
    @SerializedName("product_details")
    @Expose
    private List<ProductDetail> productDetails = null;
    @SerializedName("type")
    @Expose
    private Integer type;

    public Integer getType() {
        return this.type;
    }

    public void setType(Integer num) {
        this.type = num;
    }

    public String getCatId() {
        return this.catId;
    }

    public void setCatId(String str) {
        this.catId = str;
    }

    public String getCatName() {
        return this.catName;
    }

    public void setCatName(String str) {
        this.catName = str;
    }

    public List<ProductDetail> getProductDetails() {
        return this.productDetails;
    }

    public void setProductDetails(List<ProductDetail> list) {
        this.productDetails = list;
    }
}
