package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.view;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PaintFlagsDrawFilter;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.MotionEvent;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.core.view.MotionEventCompat;
import androidx.core.view.ViewCompat;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.R;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.BubblePropertyModel;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.DensityUtils;

public class BubbleTextView extends AppCompatImageView {
    private float MAX_SCALE = 1.5f;
    private float MIN_SCALE = 0.5f;
    private float baseline;
    private final long bubbleId;
    private Canvas canvasText;
    private Context context;
    private final String defaultStr;
    private Bitmap deleteBitmap;
    private int deleteBitmapHeight;
    private int deleteBitmapWidth;
    private DisplayMetrics dm;
    private Rect dst_delete;
    private Rect dst_flipV;
    private Rect dst_resize;
    private Rect dst_top;
    private Paint.FontMetrics fm;
    private int fontColor;
    private double halfDiagonalLength;
    private int height;
    private float initialRotation;
    public boolean isClickable = true;
    private boolean isInEdit = true;
    private boolean isInResize = false;
    private boolean isInSide=false;

    boolean isInit = true;
    private boolean isMove = false;
    private boolean isPointerDown = false;

    private float lastLength;
    private float lastRotateDegree;
    private float lastX;
    private float lastY;
    private float lineSpacing = 10.0f;
    private Paint localPaint;
    private Bitmap mBitmap;
    private TextPaint mFontPaint;
    private float mFontSize = 20.0f;

    private int mScreenwidth;
    private String mStr = "";
    private Matrix matrix = new Matrix();
    private PointF mid = new PointF();
    private float oldDis;
    private OperationListener operationListener;
    private Bitmap originBitmap;
    private float oringinWidth = 0.0f;
    private long preClicktime;
    private Bitmap resizeBitmap;
    private int resizeBitmapHeight;
    private int resizeBitmapWidth;
    private float rotation;
    private float scale = 1.0f;
    private int topBitmapHeight;
    private int topBitmapWidth;
    private int width;
    private float xLength;
    private float yLength;

    public interface OperationListener {
        void onClick(BubbleTextView bubbleTextView);

        void onDeleteClick();

        void onEdit(BubbleTextView bubbleTextView);

        void onTop(BubbleTextView bubbleTextView);
    }

    public BubbleTextView(Context context2, AttributeSet attributeSet) {
        super(context2, attributeSet);
        this.context = context2;
        this.defaultStr = getContext().getString(R.string.double_click_input_text);
        this.fontColor = ViewCompat.MEASURED_STATE_MASK;
        this.bubbleId = 0;
        init();
    }

    public BubbleTextView(Context context2) {
        super(context2);
        this.context = context2;
        this.defaultStr = getContext().getString(R.string.double_click_input_text);
        this.fontColor = ViewCompat.MEASURED_STATE_MASK;
        this.bubbleId = 0;
        init();
    }

    public BubbleTextView(Context context2, String str) {
        super(context2);
        this.context = context2;
        this.defaultStr = str;
        this.fontColor = ViewCompat.MEASURED_STATE_MASK;
        this.bubbleId = 0;
        init();
    }

    public BubbleTextView(Context context2, AttributeSet attributeSet, int i) {
        super(context2, attributeSet, i);
        this.context = context2;
        this.defaultStr = getContext().getString(R.string.double_click_input_text);
        this.fontColor = ViewCompat.MEASURED_STATE_MASK;
        this.bubbleId = 0;
        init();
    }

    public BubbleTextView(Context context2, int i, long j) {
        super(context2);
        this.context = context2;
        this.defaultStr = getContext().getString(R.string.double_click_input_text);
        this.fontColor = i;
        this.bubbleId = j;
        init();
    }

    private void init() {
        this.dm = getResources().getDisplayMetrics();
        this.dst_delete = new Rect();
        this.dst_resize = new Rect();
        this.dst_flipV = new Rect();
        this.dst_top = new Rect();
        Paint paint = new Paint();
        this.localPaint = paint;
        paint.setColor(getResources().getColor(R.color.black));
        this.localPaint.setAntiAlias(true);
        this.localPaint.setDither(true);
        this.localPaint.setStyle(Paint.Style.STROKE);
        this.localPaint.setStrokeWidth(2.0f);
        this.mScreenwidth = this.dm.widthPixels;
        int mScreenHeight = this.dm.heightPixels;
        this.mFontSize = 20.0f;
        TextPaint textPaint = new TextPaint();
        this.mFontPaint = textPaint;
        textPaint.setTextSize(TypedValue.applyDimension(2, this.mFontSize, this.dm));
        this.mFontPaint.setColor(this.fontColor);
        this.mFontPaint.setTextAlign(Paint.Align.CENTER);
        this.mFontPaint.setAntiAlias(true);
        Paint.FontMetrics fontMetrics = this.mFontPaint.getFontMetrics();
        this.fm = fontMetrics;
        this.baseline = fontMetrics.descent - this.fm.ascent;
        this.isInit = true;
        this.mStr = this.defaultStr;
    }

     
    public void onDraw(Canvas canvas) {
        int i;
        Canvas canvas2 = canvas;
        if (this.mBitmap != null) {
            getHeight();
            getWidth();
            this.mFontPaint.setColor(this.fontColor);
            this.mFontPaint.setAlpha(255);
            float[] fArr = new float[9];
            canvas.save();
            Bitmap copy = this.originBitmap.copy(Bitmap.Config.ARGB_8888, true);
            this.mBitmap = copy;
            this.canvasText.setBitmap(copy);
            this.canvasText.setDrawFilter(new PaintFlagsDrawFilter(0, 3));
            canvas2.setDrawFilter(new PaintFlagsDrawFilter(0, 3));
            float applyDimension = TypedValue.applyDimension(1, 15.0f, this.dm);
            float f = fArr[0];
            float f2 = fArr[3];
            Math.sqrt((double) ((f * f) + (f2 * f2)));
            float f3 = this.mFontSize;
            if (f3 > 35.0f) {
                this.mFontSize = 35.0f;
            } else if (f3 < 14.0f) {
                this.mFontSize = 14.0f;
            }
            this.mFontPaint.setTextSize(TypedValue.applyDimension(2, 35.0f, this.dm));
            String[] autoSplit = autoSplit(this.mStr, this.mFontPaint, ((float) this.mBitmap.getWidth()) - (applyDimension * 1.0f));
            this.mFontPaint.measureText(getmStr());
            Rect rect = new Rect();
            float textWidth = this.mFontPaint.measureText(autoSplit[0], 0, autoSplit[0].length());
            try {
                this.mFontPaint.getTextBounds(getmStr(), 0, getmStr().length(), rect);
                i = rect.height();
            } catch (Exception e) {
                e.printStackTrace();
                i = 10;
            }
            Rect rect2 = new Rect();
            this.mFontPaint.getTextBounds(autoSplit[0], 0, autoSplit[0].length(), rect2);
            int textHeight = rect2.height();
            if (autoSplit.length == 1) {
                this.mBitmap = Bitmap.createBitmap(((int) textWidth) + 10, this.mBitmap.getHeight() - 40, Bitmap.Config.ARGB_8888);
            } else {
                this.mBitmap = Bitmap.createBitmap((int) (textWidth + 30.0f), (int) ((((float) ((i * (autoSplit.length + 1)) + 20)) * this.scale) + this.lineSpacing + this.fm.leading), Bitmap.Config.ARGB_8888);
            }
            this.canvasText = new Canvas(this.mBitmap);
            float height2 = ((((float) this.mBitmap.getHeight()) - ((((float) autoSplit.length) * (this.baseline + this.fm.leading)) + this.baseline)) / 2.0f) + this.baseline;
            for (String str : autoSplit) {
                if (!TextUtils.isEmpty(str)) {
                    this.canvasText.drawText(str, (float) (this.mBitmap.getWidth() / 2), 20.0f + height2, this.mFontPaint);
                    height2 += this.baseline + this.fm.leading + this.lineSpacing;
                }
            }
            canvas2.drawBitmap(this.mBitmap, this.matrix, (Paint) null);
            this.matrix.getValues(fArr);
            this.xLength = fArr[2];
            this.yLength = fArr[5];
            float f4 = fArr[2] + (fArr[0] * 0.0f) + (fArr[1] * 0.0f);
            float f5 = fArr[5] + (fArr[3] * 0.0f) + (fArr[4] * 0.0f);
            float width2 = fArr[2] + (fArr[0] * ((float) this.mBitmap.getWidth())) + (fArr[1] * 0.0f);
            float width3 = fArr[5] + (fArr[3] * ((float) this.mBitmap.getWidth())) + (fArr[4] * 0.0f);
            float height3 = fArr[2] + (fArr[0] * 0.0f) + (fArr[1] * ((float) this.mBitmap.getHeight()));
            float height4 = (fArr[3] * 0.0f) + (fArr[4] * ((float) this.mBitmap.getHeight())) + fArr[5];
            float width4 = (fArr[0] * ((float) this.mBitmap.getWidth())) + (fArr[1] * ((float) this.mBitmap.getHeight())) + fArr[2];
            float width5 = fArr[5] + (fArr[3] * ((float) this.mBitmap.getWidth())) + (fArr[4] * ((float) this.mBitmap.getHeight()));
            this.rotation = (float) Math.round(Math.atan2((double) fArr[1], (double) fArr[0]) * 57.29577951308232d);
            this.dst_delete.left = (int) (width2 - ((float) (this.deleteBitmapWidth / 2)));
            this.dst_delete.right = (int) (((float) (this.deleteBitmapWidth / 2)) + width2);
            this.dst_delete.top = (int) (width3 - ((float) (this.deleteBitmapHeight / 2)));
            this.dst_delete.bottom = (int) (((float) (this.deleteBitmapHeight / 2)) + width3);
            this.dst_resize.left = (int) (width4 - ((float) (this.resizeBitmapWidth / 2)));
            this.dst_resize.right = (int) (width4 + ((float) (this.resizeBitmapWidth / 2)));
            this.dst_resize.top = (int) (width5 - ((float) (this.resizeBitmapHeight / 2)));
            this.dst_resize.bottom = (int) (((float) (this.resizeBitmapHeight / 2)) + width5);
            this.dst_top.left = (int) (f4 - ((float) (this.topBitmapWidth / 2)));
            this.dst_top.right = (int) (((float) (this.topBitmapWidth / 2)) + f4);
            this.dst_top.top = (int) (f5 - ((float) (this.topBitmapHeight / 2)));
            this.dst_top.bottom = (int) (((float) (this.topBitmapHeight / 2)) + f5);
            if (this.isInEdit) {
                Canvas canvas3 = canvas;
                canvas3.drawLine(f4, f5, width2, width3, this.localPaint);
                float f6 = width4;
                float f7 = width5;
                canvas3.drawLine(width2, width3, f6, f7, this.localPaint);
                float f8 = height3;
                float f9 = height4;
                canvas3.drawLine(f8, f9, f6, f7, this.localPaint);
                canvas3.drawLine(f8, f9, f4, f5, this.localPaint);
                if (this.isClickable) {
                    canvas2.drawBitmap(this.deleteBitmap, (Rect) null, this.dst_delete, (Paint) null);
                    canvas2.drawBitmap(this.resizeBitmap, (Rect) null, this.dst_resize, (Paint) null);
                }
            }
            canvas.restore();
        }
    }

    public void setText(String str) {
        this.mStr = str;
        invalidate();
    }

    public void setColor(int i) {
        this.fontColor = i;
        invalidate();
    }

    public void setImageResource(int i, float f, float f2, float f3, float f4, float f5) {
        this.matrix.reset();
        this.initialRotation = f5;
        Bitmap decodeResource = BitmapFactory.decodeResource(getResources(), i);
        if (f == 0.0f || f2 == 0.0f) {
            setBitmap(decodeResource, 0.0f, 0.0f, f5);
        } else {
            setBitmap(Bitmap.createScaledBitmap(decodeResource, (int) f4, (int) f3, true), f, f2, f5);
        }
    }

    public void setImageResource(int i, BubblePropertyModel bubblePropertyModel) {
        this.matrix.reset();
        setBitmap(BitmapFactory.decodeResource(getResources(), i), bubblePropertyModel);
    }

    public void setBitmap(Bitmap bitmap, BubblePropertyModel samarpan_BubblePropertyModel) {
        this.mFontSize = 20.0f;
        this.originBitmap = bitmap;
        this.mBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true);
        this.canvasText = new Canvas(this.mBitmap);
        setDiagonalLength();
        initBitmaps();
        this.oringinWidth = this.width;
        this.mStr = samarpan_BubblePropertyModel.getText();
        float scaling = (samarpan_BubblePropertyModel.getScaling() * this.mScreenwidth) / this.mBitmap.getWidth();
        float f = this.MAX_SCALE;
        float f2 = f;
        if (scaling <= f) {
            f2 = this.MIN_SCALE;
        }
        this.matrix.postRotate(-((float) Math.toDegrees(samarpan_BubblePropertyModel.getDegree())), this.width >> 1, this.height >> 1);
        this.matrix.postScale(f2, f2, this.width >> 1, this.height >> 1);
        float f3 = samarpan_BubblePropertyModel.getxLocation();
        float f4 = this.mScreenwidth;
        float f5 = samarpan_BubblePropertyModel.getyLocation();
        float f6 = this.mScreenwidth;
        float applyDimension = TypedValue.applyDimension(1, 22.0f, this.dm);
        this.matrix.postTranslate(((f3 * f4) - ((this.width * f2) / 2.0f)) - applyDimension, ((f5 * f6) - ((this.height * f2) / 2.0f)) - applyDimension);
        invalidate();
    }


    public void setBitmap(Bitmap bitmap, float f, float f2, float f3) {
        this.mFontSize = 20.0f;
        this.originBitmap = bitmap;
        this.mBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true);
        this.canvasText = new Canvas(this.mBitmap);
        setDiagonalLength();
        initBitmaps();
        this.width = this.mBitmap.getWidth();
        this.height = this.mBitmap.getHeight();
        this.oringinWidth = (float) this.width;
        DensityUtils.dip2px(getContext(), 50.0f);
        if (f == 0.0f || f2 == 0.0f) {
            Matrix matrix2 = this.matrix;
            int i = this.mScreenwidth;
            matrix2.postTranslate((float) ((i / 2) - (this.width / 2)), (float) ((i / 2) - (this.height / 2)));
        } else {
            this.matrix.postTranslate(f, f2);
            this.matrix.postRotate(f3);
        }
        invalidate();
    }

    private void setDiagonalLength() {
        this.halfDiagonalLength = Math.hypot((double) this.mBitmap.getWidth(), (double) this.mBitmap.getHeight()) / 2.0d;
    }

    private void initBitmaps() {
        float f = (float) (this.mScreenwidth / 10);
        if (((float) this.mBitmap.getWidth()) < f) {
            this.MIN_SCALE = 1.0f;
        } else {
            this.MIN_SCALE = (f * 1.0f) / ((float) this.mBitmap.getWidth());
        }
        int width2 = this.mBitmap.getWidth();
        int i = this.mScreenwidth;
        if (width2 > i) {
            this.MAX_SCALE = 1.0f;
        } else {
            this.MAX_SCALE = (((float) i) * 1.0f) / ((float) this.mBitmap.getWidth());
        }
        this.deleteBitmap = drawableToBitmap(this.context.getResources().getDrawable(R.drawable.sticker_close));
        this.resizeBitmap = drawableToBitmap(this.context.getResources().getDrawable(R.drawable.sticker_zoom));
        this.deleteBitmapWidth = (int) (((float) this.deleteBitmap.getWidth()) * 0.1f);
        this.deleteBitmapHeight = (int) (((float) this.deleteBitmap.getHeight()) * 0.1f);
        this.resizeBitmapWidth = (int) (((float) this.resizeBitmap.getWidth()) * 0.1f);
        this.resizeBitmapHeight = (int) (((float) this.resizeBitmap.getHeight()) * 0.1f);

    }

    public boolean onTouchEvent(MotionEvent var1) {
        int var10 = MotionEventCompat.getActionMasked(var1);
        boolean var13 = false;
        boolean isInBitmap = false;
        OperationListener var14;
        if (this.isClickable) {
            label131: {
                float var7 = 1.0F;
                boolean isDown = false;
                boolean isUp = false;
                if (var10 != 0) {
                    label129: {
                        if (var10 != 1) {
                            if (var10 == 2) {
                                float var6;
                                if (this.isPointerDown) {
                                    var6 = this.spacing(var1);
                                    if (var6 != 0.0F && !(var6 < 20.0F)) {
                                        var6 = (var6 / this.oldDis - 1.0F) * 0.09F + 1.0F;
                                    } else {
                                        var6 = 1.0F;
                                    }

                                    float var8;
                                    label136: {
                                        float var9 = (float)Math.abs(this.dst_flipV.left - this.dst_resize.left) * var6 / this.oringinWidth;
                                        if (var9 <= this.MIN_SCALE) {
                                            var8 = var7;
                                            if (var6 < 1.0F) {
                                                break label136;
                                            }
                                        }

                                        if (var9 >= this.MAX_SCALE && var6 > 1.0F) {
                                            var8 = var7;
                                        } else {
                                            this.lastLength = this.diagonalLength(var1);
                                            var8 = var6;
                                        }
                                    }

                                    this.matrix.postScale(var8, var8, this.mid.x, this.mid.y);
                                    this.mFontSize *= var8 / 2.0F;
                                    this.scale = var8;
                                    this.invalidate();
                                } else if (this.isInResize) {
                                    label140: {
                                        this.matrix.postRotate((this.rotationToStartPoint(var1) - this.lastRotateDegree) * 2.0F, this.mid.x, this.mid.y);
                                        this.lastRotateDegree = this.rotationToStartPoint(var1);
                                        var6 = this.diagonalLength(var1) / this.lastLength;
                                        double var2 = (double)this.diagonalLength(var1);
                                        double var4 = this.halfDiagonalLength;
                                        Double.isNaN(var2);
                                        if (!(var2 / var4 <= (double)this.MIN_SCALE) || !(var6 < 1.0F)) {
                                            var2 = (double)this.diagonalLength(var1);
                                            var4 = this.halfDiagonalLength;
                                            Double.isNaN(var2);
                                            if (!(var2 / var4 >= (double)this.MAX_SCALE) || !(var6 > 1.0F)) {
                                                this.lastLength = this.diagonalLength(var1);
                                                break label140;
                                            }
                                        }

                                        var6 = var7;
                                        if (!this.isInResize(var1)) {
                                            this.isInResize = false;
                                            var6 = var7;
                                        }
                                    }

                                    this.matrix.postScale(var6, var6, this.mid.x, this.mid.y);
                                    this.mFontSize *= var6;
                                    this.scale = var6;
                                    this.invalidate();
                                } else if (this.isInSide) {
                                    var7 = var1.getX(0);
                                    var6 = var1.getY(0);
                                    if (!this.isMove && Math.abs(var7 - this.lastX) < 0.5F && Math.abs(var6 - this.lastY) < 0.5F) {
                                        this.isMove = false;
                                    } else {
                                        this.isMove = true;
                                    }

                                    this.matrix.postTranslate(var7 - this.lastX, var6 - this.lastY);
                                    this.lastX = var7;
                                    this.lastY = var6;
                                    this.invalidate();
                                }
                                break label129;
                            }

                            if (var10 != 3) {
                                if (var10 == 5) {
                                    if (this.spacing(var1) > 20.0F) {
                                        this.oldDis = this.spacing(var1);
                                        this.isPointerDown = true;
                                        this.midPointToStartPoint(var1);
                                    } else {
                                        this.isPointerDown = false;
                                    }

                                    this.isInSide = false;
                                    this.isInResize = false;
                                }
                                break label129;
                            }
                        }

                        this.isInResize = false;
                        this.isInSide = false;
                        this.isPointerDown = false;
                        isUp = true;
                    }
                } else if (this.isInButton(var1, this.dst_delete)) {
                    var14 = this.operationListener;
                    if (var14 != null) {
                        var14.onDeleteClick();
                    }

                    isDown = false;
                } else if (this.isInResize(var1)) {
                    this.isInResize = true;
                    this.lastRotateDegree = this.rotationToStartPoint(var1);
                    this.midPointToStartPoint(var1);
                    this.lastLength = this.diagonalLength(var1);
                    isDown = false;
                } else if (this.isInButton(var1, this.dst_flipV)) {
                    PointF var15 = new PointF();
                    this.midDiagonalPoint(var15);
                    this.matrix.postScale(-1.0F, 1.0F, var15.x, var15.y);
                    isDown = false;
                    this.invalidate();
                } else if (this.isInButton(var1, this.dst_top)) {
                    this.bringToFront();
                    var14 = this.operationListener;
                    if (var14 != null) {
                        var14.onTop(this);
                    }

                    isDown = false;
                } else {
                    if (!this.isInBitmap(var1)) {
                        break label131;
                    }

                    this.isInSide = true;
                    this.lastX = var1.getX(0);
                    this.lastY = var1.getY(0);
                    isDown = true;
                    this.isMove = false;
                    this.isPointerDown = false;
                    isUp = false;
                    isInBitmap = true;
                    long var11 = System.currentTimeMillis();
                    StringBuilder var16 = new StringBuilder();
                    var16.append(var11 - this.preClicktime);
                    var16.append("");
                    Log.d("BubbleTextView", var16.toString());
                    if (var11 - this.preClicktime > 200L) {
                        this.preClicktime = var11;
                    } else if (this.isInEdit) {
                        var14 = this.operationListener;
                        if (var14 != null) {
                            var14.onClick(this);
                        }
                    }
                }

                var13 = true;
            }
        } else {
            this.operationListener.onEdit(this);
        }

        if (var13) {
            var14 = this.operationListener;
            if (var14 != null) {
                var14.onEdit(this);
            }
        }

        return var13;
    }


    public BubblePropertyModel calculate(BubblePropertyModel bubblePropertyModel) {
        float[] fArr = new float[9];
        this.matrix.getValues(fArr);
        float f = fArr[2];
        float f2 = fArr[5];
        float f3 = fArr[0];
        float f4 = fArr[3];
        float sqrt = (float) Math.sqrt((double) ((f3 * f3) + (f4 * f4)));
        float round = (float) Math.round(Math.atan2((double) fArr[1], (double) fArr[0]) * 57.29577951308232d);
        float centerX = (float) ((this.dst_top.centerX() + this.dst_resize.centerX()) / 2);
        float centerY = (float) ((this.dst_top.centerY() + this.dst_resize.centerY()) / 2);
        bubblePropertyModel.setDegree((float) Math.toRadians((double) round));
        bubblePropertyModel.setBubbleId(this.bubbleId);
        bubblePropertyModel.setScaling((((float) this.mBitmap.getWidth()) * sqrt) / ((float) this.mScreenwidth));
        bubblePropertyModel.setxLocation(centerX / ((float) this.mScreenwidth));
        bubblePropertyModel.setyLocation(centerY / ((float) this.mScreenwidth));
        bubblePropertyModel.setText(this.mStr);
        return bubblePropertyModel;
    }

    private boolean isInBitmap(MotionEvent motionEvent) {
        MotionEvent motionEvent2 = motionEvent;
        float[] fArr = new float[9];
        this.matrix.getValues(fArr);
        float f = (fArr[0] * 0.0f) + (fArr[1] * 0.0f) + fArr[2];
        float f2 = (fArr[3] * 0.0f) + (fArr[4] * 0.0f) + fArr[5];
        float width2 = (fArr[0] * ((float) this.mBitmap.getWidth())) + (fArr[1] * 0.0f) + fArr[2];
        float width3 = (fArr[3] * ((float) this.mBitmap.getWidth())) + (fArr[4] * 0.0f) + fArr[5];
        float height2 = (fArr[0] * 0.0f) + (fArr[1] * ((float) this.mBitmap.getHeight())) + fArr[2];
        float height3 = (fArr[3] * 0.0f) + (fArr[4] * ((float) this.mBitmap.getHeight())) + fArr[5];
        float width4 = (fArr[0] * ((float) this.mBitmap.getWidth())) + (fArr[1] * ((float) this.mBitmap.getHeight())) + fArr[2];
        float width5 = (fArr[3] * ((float) this.mBitmap.getWidth())) + (fArr[4] * ((float) this.mBitmap.getHeight())) + fArr[5];
        return pointInRect(new float[]{f, width2, width4, height2}, new float[]{f2, width3, width5, height3}, motionEvent2.getX(0), motionEvent2.getY(0));
    }

    private boolean pointInRect(float[] fArr, float[] fArr2, float f, float f2) {
        double hypot = Math.hypot((double) (fArr[0] - fArr[1]), (double) (fArr2[0] - fArr2[1]));
        double hypot2 = Math.hypot((double) (fArr[1] - fArr[2]), (double) (fArr2[1] - fArr2[2]));
        double hypot3 = Math.hypot((double) (fArr[3] - fArr[2]), (double) (fArr2[3] - fArr2[2]));
        double hypot4 = Math.hypot((double) (fArr[0] - fArr[3]), (double) (fArr2[0] - fArr2[3]));
        double hypot5 = Math.hypot((double) (f - fArr[0]), (double) (f2 - fArr2[0]));
        double d = hypot;
        double hypot6 = Math.hypot((double) (f - fArr[1]), (double) (f2 - fArr2[1]));
        double hypot7 = Math.hypot((double) (f - fArr[2]), (double) (f2 - fArr2[2]));
        double hypot8 = Math.hypot((double) (f - fArr[3]), (double) (f2 - fArr2[3]));
        double d2 = ((d + hypot5) + hypot6) / 2.0d;
        double d3 = ((hypot2 + hypot6) + hypot7) / 2.0d;
        double d4 = ((hypot3 + hypot7) + hypot8) / 2.0d;
        double d5 = ((hypot4 + hypot8) + hypot5) / 2.0d;
        return Math.abs((d * hypot2) - (((Math.sqrt((((d2 - d) * d2) * (d2 - hypot5)) * (d2 - hypot6)) + Math.sqrt((((d3 - hypot2) * d3) * (d3 - hypot6)) * (d3 - hypot7))) + Math.sqrt((((d4 - hypot3) * d4) * (d4 - hypot7)) * (d4 - hypot8))) + Math.sqrt((((d5 - hypot4) * d5) * (d5 - hypot8)) * (d5 - hypot5)))) < 0.5d;
    }

    private boolean isInButton(MotionEvent motionEvent, Rect rect) {
        int i = rect.left;
        int i2 = rect.right;
        int i3 = rect.top;
        int i4 = rect.bottom;
        if (motionEvent.getX(0) < ((float) i) || motionEvent.getX(0) > ((float) i2) || motionEvent.getY(0) < ((float) i3) || motionEvent.getY(0) > ((float) i4)) {
            return false;
        }
        return true;
    }

    private boolean isInResize(MotionEvent motionEvent) {
        int i = this.dst_resize.top - 20;
        int i2 = this.dst_resize.right + 20;
        int i3 = this.dst_resize.bottom + 20;
        if (motionEvent.getX(0) < ((float) (this.dst_resize.left - 20)) || motionEvent.getX(0) > ((float) i2) || motionEvent.getY(0) < ((float) i) || motionEvent.getY(0) > ((float) i3)) {
            return false;
        }
        return true;
    }

    private void midPointToStartPoint(MotionEvent motionEvent) {
        float[] fArr = new float[9];
        this.matrix.getValues(fArr);
        this.mid.set(((((fArr[0] * 0.0f) + (fArr[1] * 0.0f)) + fArr[2]) + motionEvent.getX(0)) / 2.0f, ((((fArr[3] * 0.0f) + (fArr[4] * 0.0f)) + fArr[5]) + motionEvent.getY(0)) / 2.0f);
    }

    private void midDiagonalPoint(PointF pointF) {
        float[] fArr = new float[9];
        this.matrix.getValues(fArr);
        float f = (fArr[0] * 0.0f) + (fArr[1] * 0.0f) + fArr[2];
        float f2 = (fArr[3] * 0.0f) + (fArr[4] * 0.0f) + fArr[5];
        pointF.set((f + (((fArr[0] * ((float) this.mBitmap.getWidth())) + (fArr[1] * ((float) this.mBitmap.getHeight()))) + fArr[2])) / 2.0f, (f2 + (((fArr[3] * ((float) this.mBitmap.getWidth())) + (fArr[4] * ((float) this.mBitmap.getHeight()))) + fArr[5])) / 2.0f);
    }

    private float rotationToStartPoint(MotionEvent motionEvent) {
        float[] fArr = new float[9];
        this.matrix.getValues(fArr);
        float f = (fArr[0] * 0.0f) + (fArr[1] * 0.0f) + fArr[2];
        return (float) Math.toDegrees(Math.atan2((double) (motionEvent.getY(0) - (((fArr[3] * 0.0f) + (fArr[4] * 0.0f)) + fArr[5])), (double) (motionEvent.getX(0) - f)));
    }

    private float diagonalLength(MotionEvent motionEvent) {
        return (float) Math.hypot((double) (motionEvent.getX(0) - this.mid.x), (double) (motionEvent.getY(0) - this.mid.y));
    }

    private float spacing(MotionEvent motionEvent) {
        if (motionEvent.getPointerCount() != 2) {
            return 0.0f;
        }
        float x = motionEvent.getX(0) - motionEvent.getX(1);
        float y = motionEvent.getY(0) - motionEvent.getY(1);
        return (float) Math.sqrt((double) ((x * x) + (y * y)));
    }

    public void setOperationListener(OperationListener operationListener2) {
        this.operationListener = operationListener2;
    }

    public void setInEdit(boolean z) {
        this.isInEdit = z;
        invalidate();
    }

    private String[] autoSplit(String str, Paint paint, float f) {
        int length = str.length();
        float measureText = paint.measureText(str);
        int i = 0;
        if (measureText <= f) {
            return new String[]{str};
        }
        String[] strArr = new String[((int) Math.ceil((double) (measureText / f)))];
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        int i5 = 1;
        while (true) {
            if (i >= length) {
                break;
            }
            if (paint.measureText(str, i, i5) > f) {
                int length2 = str.length() - 1;
                while (true) {
                    if (length2 > 0) {
                        break;
                    }
                    i3++;
                    if (str.charAt(length2) == ' ') {
                        i4++;
                        i3++;
                        strArr[i2] = (String) str.subSequence(i, i5);
                        i = i5 - i3;
                        i2++;
                        break;
                    }
                    length2--;
                }
                if (i4 == 0) {
                    strArr[i2] = (String) str.subSequence(i, i5);
                    i = i5;
                    i2++;
                }
            }
            if (i5 == length) {
                strArr[i2] = (String) str.subSequence(i, i5);
                break;
            }
            i5++;
        }
        return strArr;
    }

    public String getmStr() {
        return this.mStr;
    }

    public void setTextStickerClickable(boolean z) {
        this.isClickable = z;
        invalidate();
    }

    public float getH() {
        return (float) this.height;
    }

    public float getW() {
        return (float) this.width;
    }

    public float getx() {
        return this.xLength;
    }

    public float gety() {
        return this.yLength;
    }

    public float getRotation() {
        if (this.lastRotateDegree == 0.0f) {
            return this.initialRotation;
        }
        return -this.rotation;
    }

    public void setFontFamily(String str) {
        AssetManager assets = this.context.getAssets();
        this.mFontPaint.setTypeface(Typeface.createFromAsset(assets, "fonts/" + str + ".ttf"));
        invalidate();
    }

    public void setLetterSpacing(float f) {
        if (Build.VERSION.SDK_INT >= 21) {
            this.mFontPaint.setLetterSpacing(f / 100.0f);
            invalidate();
        }
    }

    public float getLetterSpacing() {
        if (Build.VERSION.SDK_INT >= 21) {
            return this.mFontPaint.getLetterSpacing();
        }
        return 0.0f;
    }

    public float getLineSpacing() {
        return this.fm.leading + this.lineSpacing;
    }

    public void setLineSpacing(float f) {
        this.lineSpacing = f;
        invalidate();
    }

    public Bitmap drawableToBitmap(Drawable drawable) {
        if (drawable instanceof BitmapDrawable) {
            return ((BitmapDrawable) drawable).getBitmap();
        }
        Bitmap createBitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(createBitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);
        return createBitmap;
    }
}
