package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.adapter;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

import androidx.recyclerview.widget.RecyclerView;

import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.R;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.activity.StickerActivity;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.application.MyApplication;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.Datum;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.EPreferences;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestManager;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;

public class StickerAdaptor extends RecyclerView.Adapter<StickerAdaptor.ViewHolder> {
    StickerActivity context;
    Datum productDetail;

    public StickerAdaptor(StickerActivity context2, Datum datum) {
        this.context = context2;
        this.productDetail = datum;
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_list, viewGroup, false));
    }

    public void onBindViewHolder(final ViewHolder viewHolder, int i) {
        final String preview = this.productDetail.getProductDetails().get(i).getPreview();
        RequestManager with = Glide.with(this.context);
        with.load(MyApplication.App_url + preview).listener(new RequestListener<Drawable>() {
            public boolean onLoadFailed(GlideException glideException, Object obj, Target<Drawable> target, boolean z) {
                viewHolder.progressBar.setVisibility(View.VISIBLE);
                return false;
            }

            public boolean onResourceReady(Drawable drawable, Object obj, Target<Drawable> target, DataSource dataSource, boolean z) {
                viewHolder.progressBar.setVisibility(View.GONE);
                return false;
            }
        }).into(viewHolder.imageView);
        String s = EPreferences.getInstance(context).getString(EPreferences.PREF_KEY_WATCH_BUNDLE_ADS, "");
        String[] array = null;
        if (!s.equals("")) {
            try {
                array = s.split("\\" + MyApplication.SPLIT_PATTERN);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
//        if (productDetail.getProductDetails().get(i).getIsPro()) {
//            if (array != null) {
//                if (Arrays.toString(array).contains(productDetail.getProductDetails().get(i).getPreview())) {
//                    viewHolder.ispro.setVisibility(View.GONE);
//                } else {
//                    viewHolder.ispro.setVisibility(View.VISIBLE);
//                }
//            }
//        } else {
//            viewHolder.ispro.setVisibility(View.GONE);
//        }
        viewHolder.card.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
//                if (productDetail.getProductDetails().get(i).getIsPro()) {
//
//                    WatchAdDialog rewardVideoConfirmDailog = WatchAdDialog.newInstance(context.getString(R.string.admob_rewared_video_ad_for_premium_theme), productDetail.getCatName() + " Style");
//
//                    rewardVideoConfirmDailog.setVideoListner(new VideoAdsListner() {
//                        @Override
//                        public void videoAdsClose() {
//                            Intent intent = new Intent();
//                            intent.putExtra("selectedSticker", MyApplication.App_url + preview);
//                            context.setResult(-1, intent);
//                            context.finish();
//
////                            Intent intent = new Intent(context, EditActivity.class);
////                            String catName2 = productDetail.getCatName();
////                            intent.putExtra("Name", catName2);
////                            intent.putExtra("android.intent.extra.STREAM", MyApplication.App_url + preview);
////                            context.startActivity(intent);
//                        }
//
//                        @Override
//                        public void videoAdNotWatchComplate() {
//                            Toast.makeText(context, "Please watch complate video!", Toast.LENGTH_SHORT).show();
//                        }
//
//                        @Override
//                        public void videoAdNotLoaded() {
//                        }
//
//
//                    });
//
//                    rewardVideoConfirmDailog.show(context.getSupportFragmentManager(), "Watch Video Ads");
//
//
//                } else {
                    Intent intent = new Intent();
                    intent.putExtra("selectedSticker", MyApplication.App_url + preview);
                    context.setResult(-1, intent);
                    context.finish();
//                    Intent intent = new Intent(context, EditActivity.class);
//                    String catName2 = productDetail.getCatName();
//                    intent.putExtra("Name", catName2);
//                    intent.putExtra("android.intent.extra.STREAM", MyApplication.App_url + preview);
//                    context.startActivity(intent);
//                }
            }
        });
    }

    public int getItemCount() {
        return this.productDetail.getProductDetails().size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        RelativeLayout card;
        ImageView imageView;
        ImageView ispro;
        ProgressBar progressBar;

        public ViewHolder(View view) {
            super(view);
            this.imageView = view.findViewById(R.id.cat_name);
            this.ispro = view.findViewById(R.id.ispro);
            this.card = view.findViewById(R.id.rings);
            this.progressBar = view.findViewById(R.id.progressFrames);
        }
    }
}
