package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.TemplateJason;

import java.io.Serializable;

public class Starter_data implements Serializable {
    private String cutout_picture_type;

    public void setCutout_picture_type(String str) {
        this.cutout_picture_type = str;
    }

    public String getCutout_picture_type() {
        return this.cutout_picture_type;
    }
}
