package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.activity;

import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.Xfermode;
import android.media.ExifInterface;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ads.sdk.ads.SdkAd;
import com.ads.sdk.funtion.AdCallback;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.R;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.adapter.AlbumAdapter;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.adapter.ImageAdapter;


import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.application.MyApplication;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.ImageDir;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.ImageInfo;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.SelectedImage;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.TemplateJason.RootTemplate;


import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.Api;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.ApiDetail;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.Constant;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.CustomDialog;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.FilterClick;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.ProgressDialog;
import com.bumptech.glide.Glide;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.material.card.MaterialCardView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import rx.Observer;
import rx.schedulers.Schedulers;


public class SelectImageActivity extends AppCompatActivity {
    DirectoryAdapter adapter;
    AlbumAdapter albumAdapter;
    String bucketId;
    long date;
    String folder;
    boolean frame = false;
    boolean fromPhoto = false;
    ImageAdapter imageAdapter;
    ImageDir imageDir;
    ArrayList<ImageDir> imageDirs = new ArrayList<>();
    ArrayList<ImageInfo> imageInfo;
    ArrayList<ImageInfo> imageInfoSelected;
    boolean isShowList = false;
    boolean isToAddImages = false;
    String paths;
    ArrayList<ImageInfo> previousList;
    ProgressDialog progressDialog;
    long size;
    int temppos = -1;
    int type;
    Uri uris;

    public CardView imgNext;
    public LinearLayout linAlbum;
    public LinearLayout linMain;
    public LinearLayout linSelections;
    public LinearLayout llNodata;

    public TextView notxt;
    public RecyclerView recycler;
    public CardView relAlbimList;
    public RelativeLayout relGalleryList;
    public RelativeLayout rlContainer;
    public RecyclerView rvFolderImageList;
    public RecyclerView rvFolderList;
    public RecyclerView rvImageList;
    public TextView txtAlbum;
    public TextView txtAll;
    public TextView txtCount;
    Context context;






    public CardView imgBack;

    public TextView titleText;
    public Toolbar toolBar;
    public TextView txtDone;
    public RootTemplate rootTemplate;
    public CustomDialog customDialog;

    public Bitmap cutOut;

    public Bitmap cutOutImg;
    public Bitmap originalImg;

    private String path;
    private void bannerNativeAds() {
        FrameLayout frAds;
        ShimmerFrameLayout shimmerAds;

        frAds = findViewById(R.id.fr_ads);
        shimmerAds = findViewById(R.id.shimmer_native);



        SdkAd.getInstance().loadNativeAd(this, MyApplication.getApplication().nativeId, R.layout.native_medium, frAds, shimmerAds, new AdCallback() {
            @Override
            public void onAdFailedToLoad(@org.jetbrains.annotations.Nullable LoadAdError i) {
                super.onAdFailedToLoad(i);
                frAds.removeAllViews();
            }

            @Override
            public void onAdFailedToShow(@org.jetbrains.annotations.Nullable AdError adError) {
                super.onAdFailedToShow(adError);
                frAds.removeAllViews();
            }
        });
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_select_image);
        bannerNativeAds();
        context = SelectImageActivity.this;
        imgNext = findViewById(R.id.imgNext);
        linAlbum = findViewById(R.id.linAlbum);
        linMain = findViewById(R.id.linMain);
        linSelections = findViewById(R.id.linSelections);
        llNodata = findViewById(R.id.llNodata);
        notxt = findViewById(R.id.notxt);
        recycler = findViewById(R.id.recycler);
        relAlbimList = findViewById(R.id.relAlbimList);
        relGalleryList = findViewById(R.id.relGalleryList);
        rlContainer = findViewById(R.id.rlContainer);
        rvFolderImageList = findViewById(R.id.rvFolderImageList);
        rvFolderList = findViewById(R.id.rvFolderList);
        rvImageList = findViewById(R.id.rvImageList);
        txtAlbum = findViewById(R.id.txtAlbum);
        txtAll = findViewById(R.id.txtAll);
        txtCount = findViewById(R.id.txtCount);
        this.customDialog = new CustomDialog(this);





        imgBack = findViewById(R.id.imgBack);

        titleText = findViewById(R.id.titleText);
        toolBar = findViewById(R.id.toolBar);
        txtDone = findViewById(R.id.txtDone);
        this.from = getIntent().getStringExtra("from");
        initVariable();
        setToolbar();
        setOnClicks();
        initMethods();
        setAdapter();
        init();
    }

    public void initMethods() {
    }


    public void setAdapter() {
    }

    public String from;
    private String forCrop;
    private int maxPicLimit = 1;

    public void initVariable() {
        this.progressDialog = new ProgressDialog(this);
        this.previousList = new ArrayList<>();
        this.isToAddImages = getIntent().getBooleanExtra("isFromDisplay", false);
        this.fromPhoto = getIntent().getBooleanExtra("fromPhoto", false);
        this.frame = getIntent().getBooleanExtra("frame", false);
        this.type = getIntent().getIntExtra("type", 1);
        this.imageInfoSelected = new ArrayList<>();
        openDisposal();
    }

    public void init() {
        String str = this.from;
        str.hashCode();
        char c = 65535;
        switch (str.hashCode()) {
            case -818875242:
                if (str.equals("EditCutout")) {
                    c = 0;
                    break;
                }
                break;
            case 114808351:
                if (str.equals("EditFront")) {
                    c = 1;
                    break;
                }
                break;
            case 115155230:
                if (str.equals("Category")) {
                    c = 2;
                    break;
                }
                break;
        }
        switch (c) {
            case 0:
//                this.done.setVisibility(View.INVISIBLE);
                this.txtCount.setText(getString(R.string.choose_cutout));
                this.forCrop = getIntent().getStringExtra("forCrop");
                break;
            case 1:
//                this.done.setVisibility(View.INVISIBLE);
                this.txtCount.setText(getString(R.string.choose_front_image));
                this.forCrop = getIntent().getStringExtra("forCrop");
                break;
            case 2:
                this.forCrop = getIntent().getStringExtra("forCrop");
                RootTemplate rootTemplate2 = (RootTemplate) getIntent().getSerializableExtra("rootTemplate");
                this.rootTemplate = rootTemplate2;
                if (rootTemplate2.getType().equals("Cutout")) {
                    this.maxPicLimit = 1;
                } else {
                    this.maxPicLimit = this.rootTemplate.getImages().size();
                }
                if (this.maxPicLimit <= 1) {
                    this.txtCount.setText("");
                    break;
                } else {
                    TextView textView = this.txtCount;
                    textView.setText(getString(R.string.selected_counse) + imageInfoSelected.size() + "/" + this.maxPicLimit + ")");
                    break;
                }
            default:
//                this.done.setVisibility(View.INVISIBLE);
                this.txtCount.setText(getString(R.string.choose_background));
                this.forCrop = getIntent().getStringExtra("forCrop");
                break;
        }

    }

    public void setToolbar() {

        imgBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }


    public void setOnClicks() {
        linMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rvFolderList.setVisibility(View.GONE);
                rvImageList.setVisibility(View.VISIBLE);
                try {
                    setFolderImageAdapter(0);
                } catch (Exception e) {

                }
                setCardBg(linMain, txtAll, linAlbum, txtAlbum);
            }
        });
        linAlbum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setCardBg(linAlbum, txtAlbum, linMain, txtAll);
                rvImageList.setVisibility(View.GONE);
                rvFolderList.setVisibility(View.VISIBLE);
            }
        });
        imgNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (imageInfoSelected.size() == maxPicLimit) {
                    sendSelectedImageList();
                } else {
                    Toast.makeText(context, "Please select at list " + maxPicLimit + "images..!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void setCardBg(LinearLayout linearLayout, TextView textView, LinearLayout linearLayout2, TextView textView2) {
        linearLayout.setBackgroundColor(ContextCompat.getColor(this, R.color.font12));
        linearLayout2.setBackgroundColor(ContextCompat.getColor(this, R.color.white));
        textView.setTextColor(ContextCompat.getColor(this, R.color.white));
        textView2.setTextColor(ContextCompat.getColor(this, R.color.font11));
    }


    private void openDisposal() {
        try {
            progressDialog.showDialog();
            getImagesData();
            mo15616xa02b0aa7();
        } catch (Exception e) {

        }
    }





    public void mo15616xa02b0aa7() throws Exception {
        this.progressDialog.dismissDialog();
        if (this.isToAddImages) {
            this.imageInfoSelected = getIntent().getParcelableArrayListExtra("imageList");
            for (int i = 0; i < this.imageInfoSelected.size(); i++) {
                int indexOf = this.imageInfo.indexOf(this.imageInfoSelected.get(i));
                if (indexOf != -1) {
                    this.imageInfo.get(indexOf).setSelected(true);
                }
            }
        }
        setImageAdapter();
        setUriAdapter();
        checkCount();
    }


private static final String[] PROJECTION = {
        "_id", "date_modified", "bucket_display_name", "_size", "mime_type", "bucket_id"
};
    private static final String SORT_ORDER = "date_modified DESC";

    private void getImagesData() {
        this.imageInfo = new ArrayList<>();
        this.imageDirs = new ArrayList<>();
        this.imageDirs.add(new ImageDir("All"));

        try (Cursor query = this.context.getContentResolver().query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                PROJECTION,
                null,
                null,
                SORT_ORDER
        )) {
            if (query != null && query.getCount() > 0) {
                processImageData(query);
            }
        }
    }

    private void processImageData(Cursor query) {
        while (query.moveToNext()) {
            this.bucketId = query.getString(query.getColumnIndexOrThrow("bucket_id"));
            this.size = query.getLong(query.getColumnIndex("_size"));
            this.date = query.getLong(query.getColumnIndex("date_modified"));
            this.folder = query.getString(query.getColumnIndex("bucket_display_name"));
            this.paths = String.valueOf(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, query.getLong(query.getColumnIndex("_id"))));

            if (this.folder == null) {
                this.folder = "No Name";
            }

            this.uris = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, query.getLong(query.getColumnIndex("_id")));
            ImageDir imageDir = new ImageDir(this.folder, this.bucketId);

            if (this.imageDirs.contains(imageDir)) {
                if (this.size > 0) {
                    int indexOf = this.imageDirs.indexOf(imageDir);
                    this.temppos = indexOf;
                    this.imageDirs.get(indexOf).setCount();
                    this.imageDirs.get(this.temppos).addInfoVideo(new ImageInfo(this.paths, this.uris, this.size, this.date));
                }
            } else if (this.size > 0) {
                imageDir.setBucketId(this.bucketId);
                imageDir.getArrayList().add(new ImageInfo(this.paths, this.uris, this.size, this.date));
                imageDir.setUri(this.uris);
                this.imageDirs.add(imageDir);
            }

            if (this.size > 0) {
                this.imageInfo.add(new ImageInfo(this.paths, this.uris, this.size, this.date));
            }
        }
    }
    private void setUriAdapter() {
        recycler.setLayoutManager(new LinearLayoutManager(this, 0, false));
        recycler.setHasFixedSize(true);
        this.imageAdapter = new ImageAdapter(this, this.imageInfoSelected, new FilterClick() {
            public void clickFilter(int i) {
                try {
                    if (imageInfo.contains(imageInfoSelected.get(i))) {
                        int indexOf = imageInfo.indexOf(imageInfoSelected.get(i));
                        ImageInfo imageInfo1 = imageInfo.get(indexOf);
                        imageInfo1.setSelected(false);
                        imageInfo.set(indexOf, imageInfo1);
                        imageInfoSelected.remove(i);
                        imageAdapter.notifyItemRemoved(i);
                        checkCount();
                        rvImageList.getAdapter().notifyItemChanged(indexOf);
                        return;
                    }
                    int indexOf2 = previousList.indexOf(imageInfoSelected.get(i));
                    if (indexOf2 == -1) {
                        imageInfoSelected.remove(i);
                        imageAdapter.notifyItemRemoved(i);
                        checkCount();
                        return;
                    }
                    previousList.get(indexOf2).setSelected(false);
                    imageInfoSelected.remove(i);
                    imageAdapter.notifyItemRemoved(i);
                    checkCount();
                    rvImageList.getAdapter().notifyItemChanged(indexOf2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        recycler.setAdapter(this.imageAdapter);
    }

    private void setImageAdapter() {
        this.imageDirs.get(0).getArrayList().addAll(this.imageInfo);
        this.imageDirs.get(0).setCount(Long.valueOf((long) this.imageDirs.get(0).getArrayList().size()).longValue());
        ArrayList<ImageInfo> arrayList = this.imageInfo;
        this.imageDirs.get(0).setUri(arrayList.get(arrayList.size() - 1).getUri());
        rvImageList.setLayoutManager(new GridLayoutManager(this, 3));
        this.albumAdapter = new AlbumAdapter(this, this.imageDirs, new AlbumAdapter.OnAlbum() {
            public void AlbumClick(int i) {
                rvFolderList.setVisibility(View.GONE);
                relAlbimList.setVisibility(View.GONE);
                try {
                    setFolderImageAdapter(i);
                } catch (Exception e) {

                }
            }
        });
        rvFolderList.setLayoutManager(new LinearLayoutManager(this, 1, false));
        rvFolderList.setAdapter(this.albumAdapter);
        try {
            rvImageList.setAdapter(new RecyclerView.Adapter() {
                public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
                    return new ImagePickHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_image, viewGroup, false));
                }

                public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int i) {
                    if (viewHolder instanceof ImagePickHolder) {
                        ImagePickHolder imagePickHolder = (ImagePickHolder) viewHolder;
                        Glide.with(context).load(imageInfo.get(i).getUri()).into(imagePickHolder.imageView);
                        if (imageInfo.get(i).isSelected()) {
                            imagePickHolder.imgCheck.setVisibility(View.VISIBLE);
                            imagePickHolder.imgCheck.setVisibility(View.VISIBLE);
                            imagePickHolder.llTrans.setVisibility(View.VISIBLE);
                            return;
                        }
                        imagePickHolder.imgCheck.setVisibility(View.GONE);
                        imagePickHolder.rels.setVisibility(View.GONE);
                        imagePickHolder.llTrans.setVisibility(View.GONE);
                    }
                }

                public int getItemCount() {
                    return imageInfo.size();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public class ImagePickHolder extends RecyclerView.ViewHolder {
        MaterialCardView card;
        ImageView imageView;
        ImageView imgCheck;
        RelativeLayout llTrans;
        LinearLayout rels;
        TextView txtSize;

        public ImagePickHolder(View view) {
            super(view);
            this.imageView = view.findViewById(R.id.imageView);
            this.txtSize = view.findViewById(R.id.txtSize);
            this.imgCheck = view.findViewById(R.id.imgCheck);
            this.rels = view.findViewById(R.id.rels);
            this.llTrans = view.findViewById(R.id.llTrans);
            this.card = view.findViewById(R.id.cardMain);
            view.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    if (forCrop.equalsIgnoreCase("no")) {
                        Constant.Cutout = getBitmap(getRealPathFromURI(imageInfo.get(ImagePickHolder.this.getAdapterPosition()).getUri()));
                        setResult(-1, new Intent());
                        finish();
                        return;
                    }
                    if (forCrop.equalsIgnoreCase("yes")) {
                        if (isNetworkAvailable(SelectImageActivity.this)) {
                            customDialog = new CustomDialog(SelectImageActivity.this);

                            customDialog.show();


                            Bitmap bitmap = getBitmap(getRealPathFromURI(imageInfo.get(ImagePickHolder.this.getAdapterPosition()).getUri()));
                            saveImage(bitmap);
                            path = getFilesDir().getAbsolutePath() + "/temp.png";
                            originalImg = bitmap;
                        } else {
                            Toast.makeText(SelectImageActivity.this, getString(R.string.internet_error), Toast.LENGTH_SHORT).show();
                        }
                        return;
                    }
                    if (rootTemplate.getType().equals("Cutout")) {
                        if (isNetworkAvailable(SelectImageActivity.this)) {
                            customDialog = new CustomDialog(SelectImageActivity.this);

                            customDialog.show();


                            Bitmap bitmap = getBitmap(getRealPathFromURI(imageInfo.get(ImagePickHolder.this.getAdapterPosition()).getUri()));
                            saveImage(bitmap);
                            path = getFilesDir().getAbsolutePath() + "/temp.png";
                            originalImg = bitmap;
                        } else {
                            Toast.makeText(SelectImageActivity.this, getString(R.string.internet_error), Toast.LENGTH_SHORT).show();
                        }

                        return;
                    }

                    if (imageInfoSelected.size() >= maxPicLimit) {
                        Toast.makeText(context, "Minimum " + maxPicLimit + " images you can select..!", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    try {
                        if (imageInfo.get(ImagePickHolder.this.getAdapterPosition()).isSelected()) {
                            imageInfoSelected.remove(imageInfo.get(ImagePickHolder.this.getAdapterPosition()));
                            imageInfo.get(ImagePickHolder.this.getAdapterPosition()).setSelected(false);
                        } else {
                            imageInfoSelected.add(imageInfo.get(ImagePickHolder.this.getAdapterPosition()));
                            imageInfo.get(ImagePickHolder.this.getAdapterPosition()).setSelected(true);
                        }
                        imageAdapter.notifyDataSetChanged();
                        rvFolderList.scrollToPosition(imageInfoSelected.size() - 1);
                        checkCount();
                        if (rvImageList.getAdapter() != null) {
                            rvImageList.getAdapter().notifyItemChanged(ImagePickHolder.this.getAdapterPosition());
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
        }
    }

    private String getRealPathFromURI(Uri contentURI) {
        String filePath;
        Cursor cursor = getContentResolver().query(contentURI, null, null, null, null);
        if (cursor == null) {
            filePath = contentURI.getPath();
        } else {
            cursor.moveToFirst();
            int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            filePath = cursor.getString(idx);
            cursor.close();
        }
        return filePath;
    }

    public void checkCount() {
        if (this.imageInfoSelected.size() == 0) {
            linSelections.setVisibility(View.GONE);
            return;
        }
        linSelections.setVisibility(View.VISIBLE);
        txtCount.setText("Image (" + this.imageInfoSelected.size() + "/" + maxPicLimit + ")");
    }

    public class DirectoryAdapter extends RecyclerView.Adapter {
        Context context;
        int selectedPos = 0;

        public DirectoryAdapter(Context context2) {
            this.context = context2;
        }

        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            return new DirectoryHolder(LayoutInflater.from(this.context).inflate(R.layout.custom_spinner_items, viewGroup, false));
        }

        public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int i) {
            DirectoryHolder directoryHolder = (DirectoryHolder) viewHolder;
            directoryHolder.txtName.setText(imageDirs.get(i).getDirName());
            if (this.selectedPos == i) {
                directoryHolder.divider.setVisibility(View.VISIBLE);
            } else {
                directoryHolder.divider.setVisibility(View.GONE);
            }
        }

        public int getItemCount() {
            return imageDirs.size();
        }

        public void setSelectedPosition(int i) {
            this.selectedPos = i;
            notifyDataSetChanged();
        }
    }

    public class DirectoryHolder extends RecyclerView.ViewHolder {
        View divider;
        ImageView imageView;
        LinearLayout linMain;
        TextView txtName;

        public DirectoryHolder(View view) {
            super(view);
            this.linMain = view.findViewById(R.id.linMain);
            this.txtName = view.findViewById(R.id.txtName);
            this.imageView = view.findViewById(R.id.imageView);
            this.divider = view.findViewById(R.id.divider);
            view.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    try {
                        setFolderImageAdapter(DirectoryHolder.this.getAdapterPosition());
                    } catch (Exception e) {

                    }
                    adapter.setSelectedPosition(DirectoryHolder.this.getAdapterPosition());
                }
            });
        }
    }


    public void setFolderImageAdapter(int i) throws Exception {
        this.previousList.addAll(this.imageInfo);
        this.imageInfo.clear();
        if (rvImageList.getAdapter() != null) {
            rvImageList.getAdapter().notifyDataSetChanged();
        }
        if (this.previousList.size() == 0) {
            llNodata.setVisibility(View.VISIBLE);
        } else {
            rvImageList.setVisibility(View.VISIBLE);
            llNodata.setVisibility(View.GONE);
        }
        this.progressDialog.showDialog();

        mo15618x9a24c6f7(i);
    }


    public Boolean mo15618x9a24c6f7(int i) throws Exception {
        Iterator<ImageInfo> it = this.imageDirs.get(i).getArrayList().iterator();
        while (it.hasNext()) {
            ImageInfo next = it.next();
            if (this.imageInfoSelected.contains(next)) {
                next.setSelected(true);
            } else {
                next.setSelected(false);
            }
            this.imageInfo.add(next);
        }
        mo15619xaada93b8();
        return false;
    }


    public void mo15619xaada93b8() throws Exception {
        this.progressDialog.dismissDialog();
        this.isShowList = false;
        relGalleryList.setVisibility(View.VISIBLE);
        if (rvImageList.getAdapter() != null) {
            rvImageList.getAdapter().notifyDataSetChanged();
        }
    }

    private void sendSelectedImageList() {

        ArrayList<String> arrayList = new ArrayList();

        for (int i = 0; i < imageInfoSelected.size(); i++) {
            arrayList.add(imageInfoSelected.get(i).getPath());
        }
        Intent intent = new Intent(getBaseContext(), EditorActivity.class);
        intent.putExtra("selectedImg", new SelectedImage(arrayList));
        intent.putExtra("rootTemplate", this.rootTemplate);
        startActivity(intent);
        finish();
        imageInfoSelected.clear();
        return;

    }


    public void onBackPressed() {
        if (relAlbimList.getVisibility() == 8) {
            relAlbimList.setVisibility(View.VISIBLE);
            setCardBg(linAlbum, txtAlbum, linMain, txtAll);
            rvImageList.setVisibility(View.GONE);
            rvFolderList.setVisibility(View.VISIBLE);
            return;
        }
        super.onBackPressed();
    }

    public Bitmap getBitmap(String str) {
        try {
            Bitmap decodeSampledBitmap = decodeSampledBitmap(new File(str), 1080, 768);
            int attributeInt = new ExifInterface(str).getAttributeInt(androidx.exifinterface.media.ExifInterface.TAG_ORIENTATION, 1);
            Matrix matrix = new Matrix();
            if (attributeInt == 6) {
                matrix.postRotate(90.0f);
                return Bitmap.createBitmap(decodeSampledBitmap, 0, 0, decodeSampledBitmap.getWidth(), decodeSampledBitmap.getHeight(), matrix, true);
            } else if (attributeInt == 3) {
                matrix.postRotate(180.0f);
                return Bitmap.createBitmap(decodeSampledBitmap, 0, 0, decodeSampledBitmap.getWidth(), decodeSampledBitmap.getHeight(), matrix, true);
            } else if (attributeInt != 8) {
                return decodeSampledBitmap;
            } else {
                matrix.postRotate(270.0f);
                return Bitmap.createBitmap(decodeSampledBitmap, 0, 0, decodeSampledBitmap.getWidth(), decodeSampledBitmap.getHeight(), matrix, true);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public Bitmap decodeSampledBitmap(File file, int i, int i2) throws FileNotFoundException {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeStream(new FileInputStream(file), (Rect) null, options);
        options.inSampleSize = calculateInSampleSize(options, i, i2);
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeStream(new FileInputStream(file), (Rect) null, options);
    }

    public int calculateInSampleSize(BitmapFactory.Options options, int i, int i2) {
        int i3 = options.outHeight;
        int i4 = options.outWidth;
        int i5 = 1;
        if (i3 > i2 || i4 > i) {
            int i6 = i3 / 2;
            int i7 = i4 / 2;
            while (i6 / i5 >= i2 && i7 / i5 >= i) {
                i5 *= 2;
            }
        }
        return i5;
    }

    public boolean isNetworkAvailable(Context lCon) {
        ConnectivityManager cm = null;
        try {
            cm = (ConnectivityManager) lCon.getSystemService(Context.CONNECTIVITY_SERVICE);
        } catch (Exception e) {

        }

        return cm.getActiveNetworkInfo() != null;
    }

    public void saveImage(final Bitmap bitmap) {
        new Thread(new Runnable() {
            public void run() {
                try {
                    FileOutputStream fileOutputStream = new FileOutputStream(getFilesDir().getAbsolutePath() + "/temp.png");
                    bitmap.compress(Bitmap.CompressFormat.PNG, 50, fileOutputStream);
                    fileOutputStream.close();
                    apiCall();
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e2) {
                    e2.printStackTrace();
                }
            }
        }).start();
    }

    public void apiCall() {
        File file = new File(path);
        Api.getClient(this).create(ApiDetail.class).uploadFile(MultipartBody.Part.createFormData("file", file.getName(), RequestBody.create(MediaType.parse("image/*"), file))).subscribeOn(Schedulers.io()).observeOn(Schedulers.newThread()).subscribe(new Observer<ResponseBody>() {
            public void onCompleted() {
                runOnUiThread(new Runnable() {
                    public void run() {
                        if (customDialog.isShowing()) {
                            customDialog.dismiss();
                        }
                    }
                });
            }

            public void onError(final Throwable th) {
                runOnUiThread(new Runnable() {
                    public void run() {
                        if (customDialog.isShowing()) {
                            customDialog.dismiss();
                        }
                        Toast.makeText(SelectImageActivity.this, "Can't Find Face", Toast.LENGTH_LONG).show();
                        th.printStackTrace();
                    }
                });
            }

            public void onNext(ResponseBody responseBody) {
                cutOut = BitmapFactory.decodeStream(responseBody.byteStream());

                cutOutImg = stackMaskingProcess(originalImg, cutOut);
                cutOutImg = TrimBitmap(cutOutImg);
                runOnUiThread(new Runnable() {
                    public void run() {
                        customDialog.dismiss();
                        if (from.equals("Category")) {
                            Constant.Cutout_portrait = cutOutImg;
                            ArrayList<String> arrayList = new ArrayList();
                            arrayList.add(path);
                            EditorActivity.createActivity(SelectImageActivity.this, arrayList, rootTemplate, cutOutImg, originalImg);
                        } else {
                            Constant.Cutout = cutOutImg;
                            setResult(-1, new Intent());
                        }
                        finish();

                    }
                });
            }
        });
    }

    public Bitmap TrimBitmap(Bitmap bitmap) {
        int height = bitmap.getHeight();
        int width = bitmap.getWidth();
        int i = 0;
        for (int i2 = 0; i2 < width && i == 0; i2++) {
            int i3 = 0;
            while (true) {
                if (i3 >= height) {
                    break;
                } else if (bitmap.getPixel(i2, i3) != 0) {
                    i = i2;
                    break;
                } else {
                    i3++;
                }
            }
        }
        int i4 = 0;
        for (int i5 = width - 1; i5 >= 0 && i4 == 0; i5--) {
            int i6 = 0;
            while (true) {
                if (i6 >= height) {
                    break;
                } else if (bitmap.getPixel(i5, i6) != 0) {
                    i4 = i5;
                    break;
                } else {
                    i6++;
                }
            }
        }
        int i7 = 0;
        for (int i8 = 0; i8 < height && i7 == 0; i8++) {
            int i9 = 0;
            while (true) {
                if (i9 >= width) {
                    break;
                } else if (bitmap.getPixel(i9, i8) != 0) {
                    i7 = i8;
                    break;
                } else {
                    i9++;
                }
            }
        }
        int i10 = 0;
        for (int i11 = height - 1; i11 >= 0 && i10 == 0; i11--) {
            int i12 = 0;
            while (true) {
                if (i12 >= width) {
                    break;
                } else if (bitmap.getPixel(i12, i11) != 0) {
                    i10 = i11;
                    break;
                } else {
                    i12++;
                }
            }
        }
        return Bitmap.createBitmap(bitmap, i, i7, i4 - i, i10 - i7);
    }

    public Bitmap stackMaskingProcess(Bitmap bitmap, Bitmap bitmap2) {
        Bitmap[] bitmapArr = {null};
        Bitmap[] bitmapArr2 = new Bitmap[1];
        if (bitmap != null) {
            try {
                int width = bitmap.getWidth();
                int height = bitmap.getHeight();
                bitmapArr[0] = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                bitmapArr2[0] = Bitmap.createScaledBitmap(bitmap2, width, height, true);
                Canvas canvas = new Canvas(bitmapArr[0]);
                Paint paint = new Paint(1);
                paint.setStrokeWidth(2.0f);
                paint.setAntiAlias(true);
                paint.setStyle(Paint.Style.STROKE);
                paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
                canvas.drawBitmap(bitmap, 0.0f, 0.0f, (Paint) null);
                canvas.drawBitmap(bitmapArr2[0], 0.0f, 0.0f, paint);
                paint.setXfermode((Xfermode) null);
            } catch (OutOfMemoryError e) {
                e.printStackTrace();
            }
        }
        return bitmapArr[0];
    }
}
