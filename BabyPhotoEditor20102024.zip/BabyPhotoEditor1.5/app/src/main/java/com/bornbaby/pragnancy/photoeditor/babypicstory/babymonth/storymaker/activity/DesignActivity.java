package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.activity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import com.ads.rn.ads.RNAd;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.R;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.adapter.CollectionAdapter;


import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.application.MyApplication;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.myAds.AdSDKPref;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.CommonUtils;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.Constant;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.FileUtils;
import com.facebook.shimmer.ShimmerFrameLayout;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Objects;

public class DesignActivity extends AppCompatActivity {
    public static ArrayList<String> selectedSavedImage = new ArrayList<>();
    private ImageView btnBack;
    private ImageView btnDelete;
    private ImageView btnShare;
    private ArrayList<String> collectionImages = new ArrayList<>();

    public LinearLayout ll;

    public CollectionAdapter mCollectionAdapter;
    private RecyclerView mRecyclerView;

    private void bannerNativeAds() {



        FrameLayout frAds;
        ShimmerFrameLayout shimmerAds;
        frAds = findViewById(R.id.fr_ads);
        shimmerAds = findViewById(R.id.shimmer_native);

        if (AdSDKPref.getInstance(this).getString(AdSDKPref.TAG_ALL_AD_OFF, "0").equals("off") || AdSDKPref.getInstance(this).getString(AdSDKPref.TAG_NATIVE_MYCREATION_ONOFF, "0").equals("off")) {
            frAds.setVisibility(View.GONE);
            shimmerAds.setVisibility(View.GONE);
        } else {
            MyApplication.nativeAdsmyCreation.observe(this, apNativeAd -> {
                if (apNativeAd != null) {
                    RNAd.getInstance().populateNativeAdView(
                            this,
                            apNativeAd,
                            frAds,
                            shimmerAds
                    );
                } else {
                    frAds.setVisibility(View.GONE);
                    shimmerAds.setVisibility(View.GONE);
                }
            });
        }

    }

    public void onCreate(Bundle bundle) {
        CommonUtils.updateLanguage(this);
        super.onCreate(bundle);
        setContentView(R.layout.activity_design);
        bannerNativeAds();
        this.mRecyclerView = findViewById(R.id.categoryListRecycle);
        this.btnBack = findViewById(R.id.btnBack);
        TextView title = findViewById(R.id.txtT);
        this.ll = findViewById(R.id.ll);
        this.btnShare = findViewById(R.id.btnShare);
        this.btnDelete = findViewById(R.id.btnDelete);
        title.setTypeface(Constant.TYPEFACE);
        new Thread(new Runnable() {
            public void run() {
                getAllList();
            }
        }).start();
        initListeners();
    }

    public void getAllList() {
        if (Build.VERSION.SDK_INT > 29) {
            this.collectionImages = FileUtils.getImagesFromFolder(this, getString(R.string.app_name));
        } else {
            File[] listFiles = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/" + getString(R.string.app_name)).listFiles();
            if (listFiles != null) {
                for (File path : listFiles) {
                    this.collectionImages.add(path.getPath());
                }
            }
        }
        runOnUiThread(new Runnable() {
            public void run() {
                initAdapter();
            }
        });
    }

    private void initListeners() {
        this.btnBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                onBackPressed();
            }
        });
        this.btnShare.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                shareImages(selectedSavedImage);
            }
        });
        this.btnDelete.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                showDeleteItemDialog();
            }
        });
    }


    public void onBackPressed() {
        selectedSavedImage.clear();
        finish();
    }


    public void initAdapter() {
        CollectionAdapter.onImageClick onImageClick = new CollectionAdapter.onImageClick() {
            public final void onImageClick(String str) {
                if (selectedSavedImage.isEmpty()) {
                    Intent intent = new Intent(DesignActivity.this, SaveActivity.class);
                    intent.putExtra("fromWhere", "design");
                    intent.putExtra("designImgPath", str);
                    startActivity(intent);
                } else if (!selectedSavedImage.contains(str)) {
                    selectedSavedImage.add(str);
                } else {
                    selectedSavedImage.remove(str);
                    if (selectedSavedImage.isEmpty()) {
                        ll.setVisibility(View.INVISIBLE);
                    }
                }
                if (selectedSavedImage.isEmpty()) {
                    mCollectionAdapter.notifyDataSetChanged();
                }
            }
        };
        this.mCollectionAdapter = new CollectionAdapter(this, this.collectionImages, onImageClick, new CollectionAdapter.onLongImageClick() {
            public void onLongImageClick(String str) {
                ll.setVisibility(View.VISIBLE);
                if (!DesignActivity.selectedSavedImage.contains(str)) {
                    DesignActivity.selectedSavedImage.add(str);
                    if (DesignActivity.selectedSavedImage.size() == 1) {
                        mCollectionAdapter.notifyDataSetChanged();
                        return;
                    }
                    return;
                }
                DesignActivity.selectedSavedImage.remove(str);
            }
        });
        StaggeredGridLayoutManager staggeredGridLayoutManager = new StaggeredGridLayoutManager(2, 1);
        staggeredGridLayoutManager.setGapStrategy(0);
        this.mRecyclerView.setLayoutManager(staggeredGridLayoutManager);
        this.mRecyclerView.setAdapter(this.mCollectionAdapter);
        this.mRecyclerView.setHasFixedSize(true);
        this.mRecyclerView.setItemViewCacheSize(this.collectionImages.size());
        this.mRecyclerView.setDrawingCacheEnabled(true);
        this.mRecyclerView.setDrawingCacheQuality(1048576);
        RecyclerView.ItemAnimator itemAnimator = this.mRecyclerView.getItemAnimator();
        Objects.requireNonNull(itemAnimator);
        ((SimpleItemAnimator) itemAnimator).setSupportsChangeAnimations(false);
    }


    public void shareImages(ArrayList<String> arrayList) {
        if (arrayList != null && arrayList.size() != 0) {
            ArrayList arrayList2 = new ArrayList();
            Intent intent = new Intent();
            intent.setAction("android.intent.action.SEND_MULTIPLE");
            intent.setType("*/*");
            Iterator<String> it = arrayList.iterator();
            while (it.hasNext()) {
                File file = new File(it.next());
                arrayList2.add(FileProvider.getUriForFile(this, getPackageName() + ".provider", file));
            }
            intent.putParcelableArrayListExtra("android.intent.extra.STREAM", arrayList2);
            selectedSavedImage.clear();
            startActivity(intent);
            this.mCollectionAdapter.notifyDataSetChanged();
            this.ll.setVisibility(View.INVISIBLE);
        }
    }

    public void showDeleteItemDialog() {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.delete_items_dialog);
        dialog.getWindow().setFlags(8, 8);
        dialog.show();
        dialog.getWindow().getDecorView().setSystemUiVisibility(getWindow().getDecorView().getSystemUiVisibility());
        dialog.getWindow().clearFlags(8);
        dialog.getWindow().setLayout(-1, -1);
        dialog.findViewById(R.id.btnOk).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (DesignActivity.selectedSavedImage != null && !DesignActivity.selectedSavedImage.isEmpty()) {
                    int i = 0;
                    while (i < DesignActivity.selectedSavedImage.size()) {
                        File file = new File(DesignActivity.selectedSavedImage.get(i));
                        getContentResolver().delete(FileProvider.getUriForFile(DesignActivity.this, getPackageName() + ".provider", file), (String) null, (String[]) null);
                        mCollectionAdapter.removeItem(DesignActivity.selectedSavedImage.get(i));
                        DesignActivity.selectedSavedImage.remove(i);
                        if (i != 0) {
                            i--;
                        }
                        if (DesignActivity.selectedSavedImage.isEmpty()) {
                            ll.setVisibility(View.INVISIBLE);
                            mCollectionAdapter.notifyDataSetChanged();
                        }
                        i++;
                    }
                    if (!DesignActivity.selectedSavedImage.isEmpty()) {
                        File file2 = new File(DesignActivity.selectedSavedImage.get(0));
                        getContentResolver().delete(FileProvider.getUriForFile(DesignActivity.this, getPackageName() + ".provider", file2), (String) null, (String[]) null);
                        mCollectionAdapter.removeItem(DesignActivity.selectedSavedImage.get(0));
                        DesignActivity.selectedSavedImage.remove(0);
                        if (DesignActivity.selectedSavedImage.isEmpty()) {
                            ll.setVisibility(View.INVISIBLE);
                            mCollectionAdapter.notifyDataSetChanged();
                        }
                    }
                }
                dialog.dismiss();
            }
        });
        dialog.findViewById(R.id.btnCancel).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.getWindow().setBackgroundDrawableResource(R.color.transparent);
    }
}
