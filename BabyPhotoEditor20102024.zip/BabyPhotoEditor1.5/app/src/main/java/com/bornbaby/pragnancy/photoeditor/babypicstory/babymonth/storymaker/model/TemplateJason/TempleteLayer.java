package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.TemplateJason;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import java.io.Serializable;

public class TempleteLayer implements Serializable {
    @SerializedName("coordinate")
    @Expose
    private Coordinate coordinate;
    @SerializedName("created_date")
    @Expose
    private String createdDate;
    @SerializedName("dynamic_layout")
    @Expose
    private DynamicLayout dynamicLayout;
    @SerializedName("filter_strength")
    @Expose
    private Double filterStrength;
    @SerializedName("filter_type")
    @Expose
    private String filterType;
    @SerializedName("layer_id")
    @Expose
    private String layerId;
    @SerializedName("placeholder_image_url")
    @Expose
    private String placeholderImageUrl;
    @SerializedName("shadow_argb")
    @Expose
    private String shadowArgb;
    @SerializedName("shadow_style")
    @Expose
    private Double shadowStyle;
    @SerializedName("shadow_value")
    @Expose
    private Double shadowValue;
    @SerializedName("sticker")
    @Expose
    private Sticker sticker;
    @SerializedName("text")
    @Expose
    private Text text;
    @SerializedName("tint_argb")
    @Expose
    private String tintArgb;
    @SerializedName("type_value")
    @Expose
    private Double typeValue;
    @SerializedName("updated_date")
    @Expose
    private String updatedDate;
    @SerializedName("user_interactive")
    @Expose
    private Boolean userInteractive;
    @SerializedName("z_index")
    @Expose
    private Double zIndex;

    public String getLayerId() {
        return this.layerId;
    }

    public void setLayerId(String str) {
        this.layerId = str;
    }

    public Double getTypeValue() {
        return this.typeValue;
    }

    public void setTypeValue(Double d) {
        this.typeValue = d;
    }

    public Double getShadowStyle() {
        return this.shadowStyle;
    }

    public void setShadowStyle(Double d) {
        this.shadowStyle = d;
    }

    public Double getShadowValue() {
        return this.shadowValue;
    }

    public void setShadowValue(Double d) {
        this.shadowValue = d;
    }

    public String getShadowArgb() {
        return this.shadowArgb;
    }

    public void setShadowArgb(String str) {
        this.shadowArgb = str;
    }

    public String getFilterType() {
        return this.filterType;
    }

    public void setFilterType(String str) {
        this.filterType = str;
    }

    public Double getFilterStrength() {
        return this.filterStrength;
    }

    public void setFilterStrength(Double d) {
        this.filterStrength = d;
    }

    public Boolean getUserInteractive() {
        return this.userInteractive;
    }

    public void setUserInteractive(Boolean bool) {
        this.userInteractive = bool;
    }

    public Double getZIndex() {
        return this.zIndex;
    }

    public void setZIndex(Double d) {
        this.zIndex = d;
    }

    public Coordinate getCoordinate() {
        return this.coordinate;
    }

    public void setCoordinate(Coordinate coordinate2) {
        this.coordinate = coordinate2;
    }

    public Sticker getSticker() {
        return this.sticker;
    }

    public void setSticker(Sticker sticker2) {
        this.sticker = sticker2;
    }

    public String getUpdatedDate() {
        return this.updatedDate;
    }

    public void setUpdatedDate(String str) {
        this.updatedDate = str;
    }

    public String getCreatedDate() {
        return this.createdDate;
    }

    public void setCreatedDate(String str) {
        this.createdDate = str;
    }

    public Text getText() {
        return this.text;
    }

    public void setText(Text text2) {
        this.text = text2;
    }

    public String getPlaceholderImageUrl() {
        return this.placeholderImageUrl;
    }

    public void setPlaceholderImageUrl(String str) {
        this.placeholderImageUrl = str;
    }

    public String getTintArgb() {
        return this.tintArgb;
    }

    public void setTintArgb(String str) {
        this.tintArgb = str;
    }

    public DynamicLayout getDynamicLayout() {
        return this.dynamicLayout;
    }

    public void setDynamicLayout(DynamicLayout dynamicLayout2) {
        this.dynamicLayout = dynamicLayout2;
    }
}
