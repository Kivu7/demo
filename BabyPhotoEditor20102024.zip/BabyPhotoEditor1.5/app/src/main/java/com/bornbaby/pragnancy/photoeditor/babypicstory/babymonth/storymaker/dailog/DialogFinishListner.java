package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.dailog;

public interface DialogFinishListner {
    void CloseDialog();
}
