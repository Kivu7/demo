package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.eraser.eraser;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.os.AsyncTask;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.widget.AppCompatImageView;
import androidx.core.internal.view.SupportMenu;


import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.activity.EraserBgActivity;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.ImageUtils;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Vector;

public class EraseView extends AppCompatImageView implements View.OnTouchListener {
    public static int MODE = 1;

    private static int f4461pc = 0;
    public static final float scale = 1.0f;
    Bitmap Bitmap2 = null;
    Bitmap Bitmap3 = null;
    Bitmap Bitmap4 = null;
    private final int ERASE = 1;
    private final int LASSO = 3;
    private final int NONE = 0;
    private final int REDRAW = 4;
    public final int TARGET = 2;
    public int TOLERANCE = 30;

    float f4462X = 100.0f;

    float f4463Y = 100.0f;
    public ActionListener actionListener;
    public final ArrayList<Integer> brushIndx = new ArrayList<>();
    public int brushSize = 18;
    private int brushSize1 = 18;
    public final ArrayList<Boolean> brushTypeIndx = new ArrayList<>();

    Canvas f4464c2;
    public final ArrayList<Path> changesIndx = new ArrayList<>();
    Context ctx;
    public int curIndx = -1;
    private boolean drawLasso = false;
    private boolean drawOnLasso = true;
    Path drawPath = new Path();
    Paint erPaint = new Paint();
    Paint erPaint1 = new Paint();
    final int erps = ImageUtils.dpToPx(getContext(), 2.0f);
    int height;
    public boolean insidCutEnable = true;
    public boolean isAutoRunning = false;
    boolean isMoved = false;
    private boolean isNewPath = false;
    public boolean isRectBrushEnable = false;
    public final boolean isRotateEnabled = true;
    public final boolean isScaleEnabled = true;
    private boolean isSelected = true;
    private boolean isTouched = false;
    public final boolean isTranslateEnabled = true;
    Path lPath = new Path();
    public final ArrayList<Boolean> lassoIndx = new ArrayList<>();
    private ScaleGestureDetector mScaleGestureDetector;
    public final float maximumScale = 8.0f;
    public final float minimumScale = 0.5f;
    public final ArrayList<Integer> modeIndx = new ArrayList<>();
    private int offset = 200;
    private int offset1 = 200;

    private Bitmap orgBit;

    Paint f4465p = new Paint();
    Paint paint = new Paint();
    BitmapShader patternBMPshader;

    public ProgressDialog f4466pd = null;
    public Point point;

    float f4467sX;

    float f4468sY;
    Path tPath = new Path();
    private int targetBrushSize = 18;
    private int targetBrushSize1 = 18;
    public UndoRedoListener undoRedoListener;
    public boolean updateOnly = false;
    public final ArrayList<Vector<Point>> vectorPoints = new ArrayList<>();
    int width;

    public interface ActionListener {
        void onAction(int i);

        void onActionCompleted(int i);
    }

    public interface UndoRedoListener {
        void enableRedo(boolean z, int i);

        void enableUndo(boolean z, int i);
    }

    public int getIndex(int i, int i2, int i3) {
        return i2 == 0 ? i : i + ((i2 - 1) * i3);
    }

    public float updatebrushsize(int i, float f) {
        return ((float) i) / f;
    }

    private class AsyncTaskRunner extends AsyncTask<Void, Void, Bitmap> {

        final int f4469ch;
        Vector<Point> targetPoints;

        public AsyncTaskRunner(int i) {
            this.f4469ch = i;
        }

        public Bitmap doInBackground(Void... voidArr) {
            if (this.f4469ch == 0) {
                return null;
            }
            this.targetPoints = new Vector<>();
            EraseView eraseView = EraseView.this;
            eraseView.Bitmap3 = eraseView.Bitmap2.copy(EraseView.this.Bitmap2.getConfig(), true);
            FloodFill(EraseView.this.Bitmap2, new Point(EraseView.this.point.x, EraseView.this.point.y), this.f4469ch);
            EraseView.this.changesIndx.add(EraseView.this.curIndx + 1, new Path());
            EraseView.this.brushIndx.add(EraseView.this.curIndx + 1, EraseView.this.brushSize);
            EraseView.this.modeIndx.add(EraseView.this.curIndx + 1, EraseView.this.TARGET);
            EraseView.this.brushTypeIndx.add(EraseView.this.curIndx + 1, EraseView.this.isRectBrushEnable);
            EraseView.this.vectorPoints.add(EraseView.this.curIndx + 1, new Vector(this.targetPoints));
            EraseView.this.lassoIndx.add(EraseView.this.curIndx + 1, EraseView.this.insidCutEnable);
            EraseView.this.curIndx++;
            clearNextChanges();
            EraseView.this.updateOnly = true;
            return null;
        }

        private void FloodFill(Bitmap bitmap, Point point, int i) {
            if (i != 0) {
                int[] iArr = new int[(EraseView.this.width * EraseView.this.height)];
                bitmap.getPixels(iArr, 0, EraseView.this.width, 0, 0, EraseView.this.width, EraseView.this.height);
                LinkedList linkedList = new LinkedList();
                linkedList.add(point);
                while (linkedList.size() > 0) {
                    Point point2 = (Point) linkedList.poll();
                    if (compareColor(iArr[EraseView.this.getIndex(point2.x, point2.y, EraseView.this.width)], i)) {
                        Point point3 = new Point(point2.x + 1, point2.y);
                        while (point2.x > 0 && compareColor(iArr[EraseView.this.getIndex(point2.x, point2.y, EraseView.this.width)], i)) {
                            iArr[EraseView.this.getIndex(point2.x, point2.y, EraseView.this.width)] = 0;
                            this.targetPoints.add(new Point(point2.x, point2.y));
                            if (point2.y > 0 && compareColor(iArr[EraseView.this.getIndex(point2.x, point2.y - 1, EraseView.this.width)], i)) {
                                linkedList.add(new Point(point2.x, point2.y - 1));
                            }
                            if (point2.y < EraseView.this.height && compareColor(iArr[EraseView.this.getIndex(point2.x, point2.y + 1, EraseView.this.width)], i)) {
                                linkedList.add(new Point(point2.x, point2.y + 1));
                            }
                            point2.x--;
                        }
                        if (point2.y > 0 && point2.y < EraseView.this.height) {
                            iArr[EraseView.this.getIndex(point2.x, point2.y, EraseView.this.width)] = 0;
                            this.targetPoints.add(new Point(point2.x, point2.y));
                        }
                        while (point3.x < EraseView.this.width && compareColor(iArr[EraseView.this.getIndex(point3.x, point3.y, EraseView.this.width)], i)) {
                            iArr[EraseView.this.getIndex(point3.x, point3.y, EraseView.this.width)] = 0;
                            this.targetPoints.add(new Point(point3.x, point3.y));
                            if (point3.y > 0 && compareColor(iArr[EraseView.this.getIndex(point3.x, point3.y - 1, EraseView.this.width)], i)) {
                                linkedList.add(new Point(point3.x, point3.y - 1));
                            }
                            if (point3.y < EraseView.this.height && compareColor(iArr[EraseView.this.getIndex(point3.x, point3.y + 1, EraseView.this.width)], i)) {
                                linkedList.add(new Point(point3.x, point3.y + 1));
                            }
                            point3.x++;
                        }
                        if (point3.y > 0 && point3.y < EraseView.this.height) {
                            iArr[EraseView.this.getIndex(point3.x, point3.y, EraseView.this.width)] = 0;
                            this.targetPoints.add(new Point(point3.x, point3.y));
                        }
                    }
                }
                bitmap.setPixels(iArr, 0, EraseView.this.width, 0, 0, EraseView.this.width, EraseView.this.height);
            }
        }

        public boolean compareColor(int i, int i2) {
            if (i == 0 || i2 == 0) {
                return false;
            }
            if (i == i2) {
                return true;
            }
            return Math.abs(Color.red(i) - Color.red(i2)) <= EraseView.this.TOLERANCE && Math.abs(Color.green(i) - Color.green(i2)) <= EraseView.this.TOLERANCE && Math.abs(Color.blue(i) - Color.blue(i2)) <= EraseView.this.TOLERANCE;
        }

        private void clearNextChanges() {
            int size = EraseView.this.changesIndx.size();
            int i = EraseView.this.curIndx + 1;
            while (size > i) {
                EraseView.this.changesIndx.remove(i);
                EraseView.this.brushIndx.remove(i);
                EraseView.this.modeIndx.remove(i);
                EraseView.this.brushTypeIndx.remove(i);
                EraseView.this.vectorPoints.remove(i);
                EraseView.this.lassoIndx.remove(i);
                size = EraseView.this.changesIndx.size();
            }
            if (EraseView.this.undoRedoListener != null) {
                EraseView.this.undoRedoListener.enableUndo(true, EraseView.this.curIndx + 1);
                EraseView.this.undoRedoListener.enableRedo(false, EraseView.this.modeIndx.size() - (EraseView.this.curIndx + 1));
            }
            if (EraseView.this.actionListener != null) {
                EraseView.this.actionListener.onActionCompleted(EraseView.MODE);
            }
        }

        public void onPreExecute() {
            super.onPreExecute();
            EraseView eraseView = EraseView.this;
            eraseView.f4466pd = new ProgressDialog(eraseView.getContext());
            EraseView.this.f4466pd.setMessage("Processing...");
            EraseView.this.f4466pd.setCancelable(false);
            EraseView.this.f4466pd.show();
        }

        public void onPostExecute(Bitmap bitmap) {
            EraseView.this.f4466pd.dismiss();
            EraseView eraseView = EraseView.this;
            eraseView.f4466pd = null;
            eraseView.invalidate();
            EraseView.this.isAutoRunning = false;
        }
    }

    private class AsyncTaskRunner1 extends AsyncTask<Void, Void, Bitmap> {

        final int f4470ch;
        Vector<Point> targetPoints;

        public AsyncTaskRunner1(int i) {
            this.f4470ch = i;
        }

        public Bitmap doInBackground(Void... voidArr) {
            if (this.f4470ch == 0) {
                return null;
            }
            this.targetPoints = new Vector<>();
            FloodFill(new Point(EraseView.this.point.x, EraseView.this.point.y), this.f4470ch);
            if (EraseView.this.curIndx < 0) {
                EraseView.this.changesIndx.add(EraseView.this.curIndx + 1, new Path());
                EraseView.this.brushIndx.add(EraseView.this.curIndx + 1, EraseView.this.brushSize);
                EraseView.this.modeIndx.add(EraseView.this.curIndx + 1, EraseView.this.TARGET);
                EraseView.this.brushTypeIndx.add(EraseView.this.curIndx + 1, EraseView.this.isRectBrushEnable);
                EraseView.this.vectorPoints.add(EraseView.this.curIndx + 1, new Vector(this.targetPoints));
                EraseView.this.lassoIndx.add(EraseView.this.curIndx + 1, EraseView.this.insidCutEnable);
                EraseView.this.curIndx++;
                clearNextChanges();
            } else if (EraseView.this.modeIndx.get(EraseView.this.curIndx) == EraseView.this.TARGET && EraseView.this.curIndx == EraseView.this.modeIndx.size() - 1) {
                EraseView.this.vectorPoints.add(EraseView.this.curIndx, new Vector(this.targetPoints));
            } else {
                EraseView.this.changesIndx.add(EraseView.this.curIndx + 1, new Path());
                EraseView.this.brushIndx.add(EraseView.this.curIndx + 1, EraseView.this.brushSize);
                EraseView.this.modeIndx.add(EraseView.this.curIndx + 1, EraseView.this.TARGET);
                EraseView.this.brushTypeIndx.add(EraseView.this.curIndx + 1, EraseView.this.isRectBrushEnable);
                EraseView.this.vectorPoints.add(EraseView.this.curIndx + 1, new Vector(this.targetPoints));
                EraseView.this.lassoIndx.add(EraseView.this.curIndx + 1, EraseView.this.insidCutEnable);
                EraseView.this.curIndx++;
                clearNextChanges();
            }
            return null;
        }

        private void FloodFill(Point point, int i) {
            if (i != 0) {
                int[] iArr = new int[(EraseView.this.width * EraseView.this.height)];
                EraseView.this.Bitmap3.getPixels(iArr, 0, EraseView.this.width, 0, 0, EraseView.this.width, EraseView.this.height);
                LinkedList linkedList = new LinkedList();
                linkedList.add(point);
                while (linkedList.size() > 0) {
                    Point point2 = (Point) linkedList.poll();
                    if (compareColor(iArr[EraseView.this.getIndex(point2.x, point2.y, EraseView.this.width)], i)) {
                        Point point3 = new Point(point2.x + 1, point2.y);
                        while (point2.x > 0 && compareColor(iArr[EraseView.this.getIndex(point2.x, point2.y, EraseView.this.width)], i)) {
                            iArr[EraseView.this.getIndex(point2.x, point2.y, EraseView.this.width)] = 0;
                            this.targetPoints.add(new Point(point2.x, point2.y));
                            if (point2.y > 0 && compareColor(iArr[EraseView.this.getIndex(point2.x, point2.y - 1, EraseView.this.width)], i)) {
                                linkedList.add(new Point(point2.x, point2.y - 1));
                            }
                            if (point2.y < EraseView.this.height && compareColor(iArr[EraseView.this.getIndex(point2.x, point2.y + 1, EraseView.this.width)], i)) {
                                linkedList.add(new Point(point2.x, point2.y + 1));
                            }
                            point2.x--;
                        }
                        if (point2.y > 0 && point2.y < EraseView.this.height) {
                            iArr[EraseView.this.getIndex(point2.x, point2.y, EraseView.this.width)] = 0;
                            this.targetPoints.add(new Point(point2.x, point2.y));
                        }
                        while (point3.x < EraseView.this.width && compareColor(iArr[EraseView.this.getIndex(point3.x, point3.y, EraseView.this.width)], i)) {
                            iArr[EraseView.this.getIndex(point3.x, point3.y, EraseView.this.width)] = 0;
                            this.targetPoints.add(new Point(point3.x, point3.y));
                            if (point3.y > 0 && compareColor(iArr[EraseView.this.getIndex(point3.x, point3.y - 1, EraseView.this.width)], i)) {
                                linkedList.add(new Point(point3.x, point3.y - 1));
                            }
                            if (point3.y < EraseView.this.height && compareColor(iArr[EraseView.this.getIndex(point3.x, point3.y + 1, EraseView.this.width)], i)) {
                                linkedList.add(new Point(point3.x, point3.y + 1));
                            }
                            point3.x++;
                        }
                        if (point3.y > 0 && point3.y < EraseView.this.height) {
                            iArr[EraseView.this.getIndex(point3.x, point3.y, EraseView.this.width)] = 0;
                            this.targetPoints.add(new Point(point3.x, point3.y));
                        }
                    }
                }
                EraseView.this.Bitmap2.setPixels(iArr, 0, EraseView.this.width, 0, 0, EraseView.this.width, EraseView.this.height);
            }
        }

        public boolean compareColor(int i, int i2) {
            if (i == 0 || i2 == 0) {
                return false;
            }
            if (i == i2) {
                return true;
            }
            return Math.abs(Color.red(i) - Color.red(i2)) <= EraseView.this.TOLERANCE && Math.abs(Color.green(i) - Color.green(i2)) <= EraseView.this.TOLERANCE && Math.abs(Color.blue(i) - Color.blue(i2)) <= EraseView.this.TOLERANCE;
        }

        private void clearNextChanges() {
            int size = EraseView.this.changesIndx.size();
            int i = EraseView.this.curIndx + 1;
            while (size > i) {
                EraseView.this.changesIndx.remove(i);
                EraseView.this.brushIndx.remove(i);
                EraseView.this.modeIndx.remove(i);
                EraseView.this.brushTypeIndx.remove(i);
                EraseView.this.vectorPoints.remove(i);
                EraseView.this.lassoIndx.remove(i);
                size = EraseView.this.changesIndx.size();
            }
            if (EraseView.this.undoRedoListener != null) {
                EraseView.this.undoRedoListener.enableUndo(true, EraseView.this.curIndx + 1);
                EraseView.this.undoRedoListener.enableRedo(false, EraseView.this.modeIndx.size() - (EraseView.this.curIndx + 1));
            }
        }

        public void onPreExecute() {
            super.onPreExecute();
            EraseView eraseView = EraseView.this;
            eraseView.f4466pd = new ProgressDialog(eraseView.getContext());
            EraseView.this.f4466pd.setMessage("Processing...");
            EraseView.this.f4466pd.setCancelable(false);
            EraseView.this.f4466pd.show();
        }

        public void onPostExecute(Bitmap bitmap) {
            EraseView.this.f4466pd.dismiss();
            EraseView.this.invalidate();
            EraseView.this.isAutoRunning = false;
        }
    }

    private class ScaleGestureListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
        private float mPivotX;
        private float mPivotY;
        private final Vector2D mPrevSpanVector;

        private ScaleGestureListener() {
            this.mPrevSpanVector = new Vector2D();
        }

        public boolean onScaleBegin(View view, ScaleGestureDetector scaleGestureDetector) {
            this.mPivotX = scaleGestureDetector.getFocusX();
            this.mPivotY = scaleGestureDetector.getFocusY();
            this.mPrevSpanVector.set(scaleGestureDetector.getCurrentSpanVector());
            return true;
        }

        public boolean onScale(View view, ScaleGestureDetector scaleGestureDetector) {
            TransformInfo transformInfo = new TransformInfo();
            transformInfo.deltaScale = EraseView.this.isScaleEnabled ? scaleGestureDetector.getScaleFactor() : 1.0f;
            float f = 0.0f;
            transformInfo.deltaAngle = EraseView.this.isRotateEnabled ? Vector2D.getAngle(this.mPrevSpanVector, scaleGestureDetector.getCurrentSpanVector()) : 0.0f;
            transformInfo.deltaX = EraseView.this.isTranslateEnabled ? scaleGestureDetector.getFocusX() - this.mPivotX : 0.0f;
            if (EraseView.this.isTranslateEnabled) {
                f = scaleGestureDetector.getFocusY() - this.mPivotY;
            }
            transformInfo.deltaY = f;
            transformInfo.pivotX = this.mPivotX;
            transformInfo.pivotY = this.mPivotY;
            transformInfo.minimumScale = EraseView.this.minimumScale;
            transformInfo.maximumScale = EraseView.this.maximumScale;
            EraseView.this.move(view, transformInfo);
            return false;
        }
    }

    private static class TransformInfo {
        public float deltaAngle;
        public float deltaScale;
        public float deltaX;
        public float deltaY;
        public float maximumScale;
        public float minimumScale;
        public float pivotX;
        public float pivotY;

        private TransformInfo() {
        }
    }

    public void setUndoRedoListener(UndoRedoListener undoRedoListener2) {
        this.undoRedoListener = undoRedoListener2;
    }

    public void setActionListener(ActionListener actionListener2) {
        this.actionListener = actionListener2;
    }

    public EraseView(Context context) {
        super(context);
        initPaint(context);
    }

    public EraseView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        initPaint(context);
    }

    private void initPaint(Context context) {
        MODE = 1;
        this.mScaleGestureDetector = new ScaleGestureDetector(new ScaleGestureListener());
        this.ctx = context;
        setFocusable(true);
        setFocusableInTouchMode(true);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        ((Activity) context).getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int screenWidth = displayMetrics.widthPixels;
        this.brushSize = ImageUtils.dpToPx(getContext(), (float) this.brushSize);
        this.brushSize1 = ImageUtils.dpToPx(getContext(), (float) this.brushSize);
        this.targetBrushSize = ImageUtils.dpToPx(getContext(), 50.0f);
        this.targetBrushSize1 = ImageUtils.dpToPx(getContext(), 50.0f);
        this.paint.setAlpha(0);
        this.paint.setColor(0);
        this.paint.setStyle(Paint.Style.STROKE);
        this.paint.setStrokeJoin(Paint.Join.ROUND);
        this.paint.setStrokeCap(Paint.Cap.ROUND);
        this.paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        this.paint.setAntiAlias(true);
        this.paint.setStrokeWidth(updatebrushsize(this.brushSize1, scale));
        Paint paint2 = new Paint();
        this.erPaint = paint2;
        paint2.setAntiAlias(true);
        this.erPaint.setColor(SupportMenu.CATEGORY_MASK);
        this.erPaint.setAntiAlias(true);
        this.erPaint.setStyle(Paint.Style.STROKE);
        this.erPaint.setStrokeJoin(Paint.Join.MITER);
        this.erPaint.setStrokeWidth(updatebrushsize(this.erps, scale));
        Paint paint3 = new Paint();
        this.erPaint1 = paint3;
        paint3.setAntiAlias(true);
        this.erPaint1.setColor(SupportMenu.CATEGORY_MASK);
        this.erPaint1.setAntiAlias(true);
        this.erPaint1.setStyle(Paint.Style.STROKE);
        this.erPaint1.setStrokeJoin(Paint.Join.MITER);
        this.erPaint1.setStrokeWidth(updatebrushsize(this.erps, scale));
        this.erPaint1.setPathEffect(new DashPathEffect(new float[]{10.0f, 20.0f}, 0.0f));
    }

    public void setImageBitmap(Bitmap bitmap) {
        if (bitmap != null) {
            if (this.orgBit == null) {
                this.orgBit = bitmap.copy(bitmap.getConfig(), true);
            }
            this.width = bitmap.getWidth();
            int height2 = bitmap.getHeight();
            this.height = height2;
            this.Bitmap2 = Bitmap.createBitmap(this.width, height2, bitmap.getConfig());
            Canvas canvas = new Canvas();
            this.f4464c2 = canvas;
            canvas.setBitmap(this.Bitmap2);
            this.f4464c2.drawBitmap(bitmap, 0.0f, 0.0f, (Paint) null);
            boolean z = this.isSelected;
            if (z) {
                enableTouchClear(z);
            }
            super.setImageBitmap(this.Bitmap2);
        }
    }

    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f4464c2 != null) {
            if (!this.updateOnly && this.isTouched) {
                Paint paintByMode = getPaintByMode(MODE, this.brushSize, this.isRectBrushEnable);
                this.paint = paintByMode;
                Path path = this.tPath;
                if (path != null) {
                    this.f4464c2.drawPath(path, paintByMode);
                }
                this.isTouched = false;
            }
            if (MODE == this.TARGET) {
                Paint paint2 = new Paint();
                this.f4465p = paint2;
                paint2.setColor(SupportMenu.CATEGORY_MASK);
                this.erPaint.setStrokeWidth(updatebrushsize(this.erps, scale));
                canvas.drawCircle(this.f4462X, this.f4463Y, (float) (this.targetBrushSize / 2), this.erPaint);
                canvas.drawCircle(this.f4462X, this.f4463Y + ((float) this.offset), updatebrushsize(ImageUtils.dpToPx(getContext(), 7.0f), scale), this.f4465p);
                this.f4465p.setStrokeWidth(updatebrushsize(ImageUtils.dpToPx(getContext(), 1.0f), scale));
                float f = this.f4462X;
                float f2 = (float) (this.targetBrushSize / 2);
                float f3 = f - f2;
                float f4 = this.f4463Y;
                canvas.drawLine(f3, f4, f2 + f, f4, this.f4465p);
                float f5 = this.f4462X;
                float f6 = this.f4463Y;
                float f7 = (float) (this.targetBrushSize / 2);
                canvas.drawLine(f5, f6 - f7, f5, f7 + f6, this.f4465p);
                this.drawOnLasso = true;
            }
            if (MODE == this.LASSO) {
                Paint paint3 = new Paint();
                this.f4465p = paint3;
                paint3.setColor(SupportMenu.CATEGORY_MASK);
                this.erPaint.setStrokeWidth(updatebrushsize(this.erps, scale));
                canvas.drawCircle(this.f4462X, this.f4463Y, (float) (this.targetBrushSize / 2), this.erPaint);
                canvas.drawCircle(this.f4462X, this.f4463Y + ((float) this.offset), updatebrushsize(ImageUtils.dpToPx(getContext(), 7.0f), scale), this.f4465p);
                this.f4465p.setStrokeWidth(updatebrushsize(ImageUtils.dpToPx(getContext(), 1.0f), scale));
                float f8 = this.f4462X;
                float f9 = (float) (this.targetBrushSize / 2);
                float f10 = f8 - f9;
                float f11 = this.f4463Y;
                canvas.drawLine(f10, f11, f9 + f8, f11, this.f4465p);
                float f12 = this.f4462X;
                float f13 = this.f4463Y;
                float f14 = (float) (this.targetBrushSize / 2);
                canvas.drawLine(f12, f13 - f14, f12, f14 + f13, this.f4465p);
                if (!this.drawOnLasso) {
                    this.erPaint1.setStrokeWidth(updatebrushsize(this.erps, scale));
                    canvas.drawPath(this.lPath, this.erPaint1);
                }
            }
            int i = MODE;
            if (i == this.ERASE || i == this.REDRAW) {
                Paint paint4 = new Paint();
                this.f4465p = paint4;
                paint4.setColor(SupportMenu.CATEGORY_MASK);
                this.erPaint.setStrokeWidth(updatebrushsize(this.erps, scale));
                if (this.isRectBrushEnable) {
                    float f15 = this.f4462X;
                    float f16 = (float) (this.brushSize / 2);
                    float f17 = this.f4463Y;
                    canvas.drawRect(f15 - f16, f17 - f16, f16 + f15, f16 + f17, this.erPaint);
                } else {
                    canvas.drawCircle(this.f4462X, this.f4463Y, (float) (this.brushSize / 2), this.erPaint);
                }
                canvas.drawCircle(this.f4462X, this.f4463Y + ((float) this.offset), updatebrushsize(ImageUtils.dpToPx(getContext(), 7.0f), scale), this.f4465p);
            }
            this.updateOnly = false;
        }
    }

    public boolean onTouch(View view, MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        if (motionEvent.getPointerCount() == 1) {
            ActionListener actionListener2 = this.actionListener;
            if (actionListener2 != null) {
                actionListener2.onAction(motionEvent.getAction());
            }
            if (MODE == this.TARGET) {
                this.drawOnLasso = false;
                this.f4462X = motionEvent.getX();
                this.f4463Y = motionEvent.getY() - ((float) this.offset);
                if (action == 0) {
                    invalidate();
                } else if (action == 1) {
                    float f = this.f4462X;
                    if (f >= 0.0f && this.f4463Y >= 0.0f && f < ((float) this.Bitmap2.getWidth()) && this.f4463Y < ((float) this.Bitmap2.getHeight())) {
                        this.point = new Point((int) this.f4462X, (int) this.f4463Y);
                        f4461pc = this.Bitmap2.getPixel((int) this.f4462X, (int) this.f4463Y);
                        if (!this.isAutoRunning) {
                            this.isAutoRunning = true;
                            new AsyncTaskRunner(f4461pc).execute();
                        }
                    }
                    invalidate();
                } else if (action == 2) {
                    invalidate();
                }
            }
            if (MODE == this.LASSO) {
                this.f4462X = motionEvent.getX();
                this.f4463Y = motionEvent.getY() - ((float) this.offset);
                if (action == 0) {
                    this.isNewPath = true;
                    this.drawOnLasso = false;
                    this.f4467sX = this.f4462X;
                    this.f4468sY = this.f4463Y;
                    Path path = new Path();
                    this.lPath = path;
                    path.moveTo(this.f4462X, this.f4463Y);
                    invalidate();
                } else if (action == 1) {

                    this.lPath.lineTo(this.f4462X, this.f4463Y);
                    this.lPath.lineTo(this.f4467sX, this.f4468sY);
                    this.drawLasso = true;
                    invalidate();
                    ActionListener actionListener3 = this.actionListener;
                    if (actionListener3 != null) {
                        actionListener3.onActionCompleted(5);
                    }
                } else if (action != 2) {
                    return false;
                } else {
                    this.lPath.lineTo(this.f4462X, this.f4463Y);
                    invalidate();
                }
            }
            int i = MODE;
            if (i == this.ERASE || i == this.REDRAW) {
                int i2 = this.brushSize / 2;
                this.f4462X = motionEvent.getX();
                this.f4463Y = motionEvent.getY() - ((float) this.offset);
                this.isTouched = true;
                this.erPaint.setStrokeWidth(updatebrushsize(this.erps, scale));
                if (action == 0) {
                    this.paint.setStrokeWidth((float) this.brushSize);
                    Path path2 = new Path();
                    this.tPath = path2;
                    if (this.isRectBrushEnable) {
                        float f2 = this.f4462X;
                        float f3 = (float) i2;
                        float f4 = this.f4463Y;
                        path2.addRect(f2 - f3, f4 - f3, f2 + f3, f4 + f3, Path.Direction.CW);
                    } else {
                        path2.moveTo(this.f4462X, this.f4463Y);
                    }
                    invalidate();
                } else if (action == 1) {

                    Path path3 = this.tPath;
                    if (path3 != null) {
                        if (this.isRectBrushEnable) {
                            float f5 = this.f4462X;
                            float f6 = (float) i2;
                            float f7 = this.f4463Y;
                            path3.addRect(f5 - f6, f7 - f6, f5 + f6, f7 + f6, Path.Direction.CW);
                        } else {
                            path3.lineTo(this.f4462X, this.f4463Y);
                        }
                        invalidate();
                        this.changesIndx.add(this.curIndx + 1, new Path(this.tPath));
                        this.brushIndx.add(this.curIndx + 1, this.brushSize);
                        this.modeIndx.add(this.curIndx + 1, MODE);
                        this.brushTypeIndx.add(this.curIndx + 1, this.isRectBrushEnable);
                        this.vectorPoints.add(this.curIndx + 1, null);
                        this.lassoIndx.add(this.curIndx + 1, this.insidCutEnable);
                        this.tPath.reset();
                        this.curIndx++;
                        clearNextChanges();
                        this.tPath = null;
                    }
                } else if (action != 2) {
                    return false;
                } else {
                    if (this.tPath != null) {
                        if (this.isRectBrushEnable) {
                            Path path4 = this.tPath;
                            float f8 = this.f4462X;
                            float f9 = (float) i2;
                            float f10 = this.f4463Y;
                            path4.addRect(f8 - f9, f10 - f9, f8 + f9, f10 + f9, Path.Direction.CW);
                        } else {
                            this.tPath.lineTo(this.f4462X, this.f4463Y);
                        }
                        invalidate();
                        this.isMoved = true;
                    }
                }
            }
        }
        this.mScaleGestureDetector.onTouchEvent((View) view.getParent(), motionEvent);
        invalidate();
        return true;
    }

    public void move(View view, TransformInfo transformInfo) {
        computeRenderOffset(view, transformInfo.pivotX, transformInfo.pivotY);
        adjustTranslation(view, transformInfo.deltaX, transformInfo.deltaY);
        float max = Math.max(transformInfo.minimumScale, Math.min(transformInfo.maximumScale, view.getScaleX() * transformInfo.deltaScale));
        view.setScaleX(max);
        view.setScaleY(max);
        updateOnScale(max);
        invalidate();
    }

    private static void adjustTranslation(View view, float f, float f2) {
        float[] fArr = {f, f2};
        view.getMatrix().mapVectors(fArr);
        view.setTranslationX(view.getTranslationX() + fArr[0]);
        view.setTranslationY(view.getTranslationY() + fArr[1]);
    }

    private static void computeRenderOffset(View view, float f, float f2) {
        if (view.getPivotX() != f || view.getPivotY() != f2) {
            float[] fArr = {0.0f, 0.0f};
            view.getMatrix().mapPoints(fArr);
            view.setPivotX(f);
            view.setPivotY(f2);
            float[] fArr2 = {0.0f, 0.0f};
            view.getMatrix().mapPoints(fArr2);
            float f3 = fArr2[1] - fArr[1];
            view.setTranslationX(view.getTranslationX() - (fArr2[0] - fArr[0]));
            view.setTranslationY(view.getTranslationY() - f3);
        }
    }

    private void clearNextChanges() {
        int size = this.changesIndx.size();
        int i = this.curIndx + 1;
        while (size > i) {
            this.changesIndx.remove(i);
            this.brushIndx.remove(i);
            this.modeIndx.remove(i);
            this.brushTypeIndx.remove(i);
            this.vectorPoints.remove(i);
            this.lassoIndx.remove(i);
            size = this.changesIndx.size();
        }
        UndoRedoListener undoRedoListener2 = this.undoRedoListener;
        if (undoRedoListener2 != null) {
            undoRedoListener2.enableUndo(true, this.curIndx + 1);
            this.undoRedoListener.enableRedo(false, this.modeIndx.size() - (this.curIndx + 1));
        }
        ActionListener actionListener2 = this.actionListener;
        if (actionListener2 != null) {
            actionListener2.onActionCompleted(MODE);
        }
    }

    public void setMODE(int i) {
        Bitmap bitmap;
        MODE = i;
        if (!(i == this.TARGET || (bitmap = this.Bitmap3) == null)) {
            bitmap.recycle();
            this.Bitmap3 = null;
        }
        if (i != this.LASSO) {
            this.drawOnLasso = true;
            this.drawLasso = false;
            Bitmap bitmap2 = this.Bitmap4;
            if (bitmap2 != null) {
                bitmap2.recycle();
                this.Bitmap4 = null;
            }
        }
    }

    private Paint getPaintByMode(int i, int i2, boolean z) {
        Paint paint2 = new Paint();
        this.paint = paint2;
        paint2.setAlpha(0);
        if (z) {
            this.paint.setStyle(Paint.Style.FILL_AND_STROKE);
            this.paint.setStrokeJoin(Paint.Join.MITER);
            this.paint.setStrokeCap(Paint.Cap.SQUARE);
        } else {
            this.paint.setStyle(Paint.Style.STROKE);
            this.paint.setStrokeJoin(Paint.Join.ROUND);
            this.paint.setStrokeCap(Paint.Cap.ROUND);
            this.paint.setStrokeWidth((float) i2);
        }
        this.paint.setAntiAlias(true);
        if (i == this.ERASE) {
            this.paint.setColor(0);
            this.paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        }
        if (i == this.REDRAW) {
            this.paint.setColor(-1);
            BitmapShader bitmapShader = EraserBgActivity.patternBMPshader;
            this.patternBMPshader = bitmapShader;
            this.paint.setShader(bitmapShader);
        }
        return this.paint;
    }

    public void updateThreshHold() {
        if (this.Bitmap3 != null && !this.isAutoRunning) {
            this.isAutoRunning = true;
            new AsyncTaskRunner1(f4461pc).execute();
        }
    }

    public int getLastChangeMode() {
        int i = this.curIndx;
        if (i < 0) {
            return this.NONE;
        }
        return this.modeIndx.get(i);
    }

    public void setOffset(int i) {
        this.offset1 = i;
        this.offset = (int) updatebrushsize(ImageUtils.dpToPx(this.ctx, (float) i), scale);
        this.updateOnly = true;
    }

    public int getOffset() {
        return this.offset1;
    }

    public void setRadius(int i) {
        int dpToPx = ImageUtils.dpToPx(getContext(), (float) i);
        this.brushSize1 = dpToPx;
        this.brushSize = (int) updatebrushsize(dpToPx, scale);
        this.updateOnly = true;
    }

    public void updateOnScale(float f) {
        this.brushSize = (int) updatebrushsize(this.brushSize1, f);
        this.targetBrushSize = (int) updatebrushsize(this.targetBrushSize1, f);
        this.offset = (int) updatebrushsize(ImageUtils.dpToPx(this.ctx, (float) this.offset1), f);
    }

    public void setThreshold(int i) {
        this.TOLERANCE = i;
        if (this.curIndx >= 0) {
            StringBuilder sb = new StringBuilder();
            sb.append(" Threshold ");
            sb.append(i);
            sb.append("  ");
            sb.append(this.modeIndx.get(this.curIndx) == this.TARGET);
        }
    }

    public boolean isTouchEnable() {
        return this.isSelected;
    }

    public void enableTouchClear(boolean z) {
        this.isSelected = z;
        if (z) {
            setOnTouchListener(this);
        } else {
            setOnTouchListener((OnTouchListener) null);
        }
    }

    public void enableInsideCut(boolean z) {
        this.insidCutEnable = z;
        if (this.drawLasso) {
            if (this.isNewPath) {
                Bitmap bitmap = this.Bitmap2;
                this.Bitmap4 = bitmap.copy(bitmap.getConfig(), true);
                drawLassoPath(this.lPath, this.insidCutEnable);
                this.changesIndx.add(this.curIndx + 1, new Path(this.lPath));
                this.brushIndx.add(this.curIndx + 1, this.brushSize);
                this.modeIndx.add(this.curIndx + 1, MODE);
                this.brushTypeIndx.add(this.curIndx + 1, this.isRectBrushEnable);
                this.vectorPoints.add(this.curIndx + 1, null);
                this.lassoIndx.add(this.curIndx + 1, this.insidCutEnable);
                this.curIndx++;
                clearNextChanges();
                invalidate();
                this.isNewPath = false;
                return;
            }
            setImageBitmap(this.Bitmap4);
            drawLassoPath(this.lPath, this.insidCutEnable);
            this.lassoIndx.add(this.curIndx, this.insidCutEnable);
            return;
        }
        Toast.makeText(this.ctx, "Please Draw a closed path!!!", Toast.LENGTH_SHORT).show();
    }

    public boolean isRectBrushEnable() {
        return this.isRectBrushEnable;
    }

    public void enableRectBrush(boolean z) {
        this.isRectBrushEnable = z;
        this.updateOnly = true;
    }

    public void undoChange() {
        UndoRedoListener undoRedoListener2;
        this.drawLasso = false;
        setImageBitmap(this.orgBit);
        int i = this.curIndx;
        if (i >= 0) {
            this.curIndx = i - 1;
            redrawCanvas();
            UndoRedoListener undoRedoListener3 = this.undoRedoListener;
            if (undoRedoListener3 != null) {
                undoRedoListener3.enableUndo(true, this.curIndx + 1);
                this.undoRedoListener.enableRedo(true, this.modeIndx.size() - (this.curIndx + 1));
            }
            int i2 = this.curIndx;
            if (i2 < 0 && (undoRedoListener2 = this.undoRedoListener) != null) {
                undoRedoListener2.enableUndo(false, i2 + 1);
            }
        }
    }

    public void redoChange() {
        UndoRedoListener undoRedoListener2;
        this.drawLasso = false;
        StringBuilder sb = new StringBuilder();
        sb.append(this.curIndx + 1 >= this.changesIndx.size());
        sb.append(" Curindx ");
        sb.append(this.curIndx);
        sb.append(" ");
        sb.append(this.changesIndx.size());
        if (this.curIndx + 1 < this.changesIndx.size()) {
            setImageBitmap(this.orgBit);
            this.curIndx++;
            redrawCanvas();
            UndoRedoListener undoRedoListener3 = this.undoRedoListener;
            if (undoRedoListener3 != null) {
                undoRedoListener3.enableUndo(true, this.curIndx + 1);
                this.undoRedoListener.enableRedo(true, this.modeIndx.size() - (this.curIndx + 1));
            }
            if (this.curIndx + 1 >= this.changesIndx.size() && (undoRedoListener2 = this.undoRedoListener) != null) {
                undoRedoListener2.enableRedo(false, this.modeIndx.size() - (this.curIndx + 1));
            }
        }
    }

    private void redrawCanvas() {
        for (int i = 0; i <= this.curIndx; i++) {
            if (this.modeIndx.get(i) == this.ERASE || this.modeIndx.get(i) == this.REDRAW) {
                this.tPath = new Path(this.changesIndx.get(i));
                Paint paintByMode = getPaintByMode(this.modeIndx.get(i), this.brushIndx.get(i), this.brushTypeIndx.get(i));
                this.paint = paintByMode;
                this.f4464c2.drawPath(this.tPath, paintByMode);
                this.tPath.reset();
            }
            if (this.modeIndx.get(i) == this.TARGET) {
                Vector vector = this.vectorPoints.get(i);
                int i2 = this.width;
                int i3 = this.height;
                int[] iArr = new int[(i2 * i3)];
                this.Bitmap2.getPixels(iArr, 0, i2, 0, 0, i2, i3);
                for (int i4 = 0; i4 < vector.size(); i4++) {
                    Point point2 = (Point) vector.get(i4);
                    iArr[getIndex(point2.x, point2.y, this.width)] = 0;
                }
                Bitmap bitmap = this.Bitmap2;
                int i5 = this.width;
                bitmap.setPixels(iArr, 0, i5, 0, 0, i5, this.height);
            }
            if (this.modeIndx.get(i) == this.LASSO) {
                drawLassoPath(new Path(this.changesIndx.get(i)), this.lassoIndx.get(i));
            }
        }
    }

    private void drawLassoPath(Path path, boolean z) {
        if (z) {
            Paint paint2 = new Paint();
            paint2.setAntiAlias(true);
            paint2.setColor(0);
            paint2.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
            this.f4464c2.drawPath(path, paint2);
        } else {
            Bitmap bitmap = this.Bitmap2;
            Bitmap copy = bitmap.copy(bitmap.getConfig(), true);
            new Canvas(copy).drawBitmap(this.Bitmap2, 0.0f, 0.0f, (Paint) null);
            this.f4464c2.drawColor(this.NONE, PorterDuff.Mode.CLEAR);
            Paint paint3 = new Paint();
            paint3.setAntiAlias(true);
            this.f4464c2.drawPath(path, paint3);
            paint3.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
            this.f4464c2.drawBitmap(copy, 0.0f, 0.0f, paint3);
            copy.recycle();
        }
        this.drawOnLasso = true;
    }

    public Bitmap getFinalBitmap() {
        Bitmap bitmap = this.Bitmap2;
        return bitmap.copy(bitmap.getConfig(), true);
    }
}
