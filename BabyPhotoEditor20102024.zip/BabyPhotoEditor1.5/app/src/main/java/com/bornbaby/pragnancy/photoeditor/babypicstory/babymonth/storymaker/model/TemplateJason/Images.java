package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.TemplateJason;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;

public class Images implements Serializable {
    @SerializedName("aspect_ratio")
    private Double aspect_ratio;
    @SerializedName("coordinate")
    private Coordinate coordinate;
    @SerializedName("crop_rectangle_increase_mode")
    private String cropRectangleIncreaseMode;
    @SerializedName("crop_rectangle_percent_increase")
    private Double cropRectanglePercentIncrease;
    @SerializedName("filter_strength")
    private Double filterStrength;
    @SerializedName("media_type")
    private String mediaType;
    @SerializedName("placeholder_image")
    private String placeholderImage;
    @SerializedName("placeholder_image_thumbnail")
    private String placeholderImageThumbnail;
    @SerializedName("use_crop_rectangle")
    private Boolean useCropRectangle;
    @SerializedName("z_index")
    private Integer zIndex;

    public Boolean getUseCropRectangle() {
        return this.useCropRectangle;
    }

    public void setUseCropRectangle(Boolean bool) {
        this.useCropRectangle = bool;
    }

    public Double getCropRectanglePercentIncrease() {
        return this.cropRectanglePercentIncrease;
    }

    public void setCropRectanglePercentIncrease(Double d) {
        this.cropRectanglePercentIncrease = d;
    }

    public String getCropRectangleIncreaseMode() {
        return this.cropRectangleIncreaseMode;
    }

    public void setCropRectangleIncreaseMode(String str) {
        this.cropRectangleIncreaseMode = str;
    }

    public String getPlaceholderImage() {
        return this.placeholderImage;
    }

    public void setPlaceholderImage(String str) {
        this.placeholderImage = str;
    }

    public String getPlaceholderImageThumbnail() {
        return this.placeholderImageThumbnail;
    }

    public void setPlaceholderImageThumbnail(String str) {
        this.placeholderImageThumbnail = str;
    }

    public Integer getZIndex() {
        return this.zIndex;
    }

    public void setZIndex(Integer num) {
        this.zIndex = num;
    }

    public Coordinate getCoordinate() {
        return this.coordinate;
    }

    public void setCoordinate(Coordinate coordinate2) {
        this.coordinate = coordinate2;
    }

    public Double getAspectRatio() {
        return this.aspect_ratio;
    }

    public void setAspectRatio(Double d) {
        this.aspect_ratio = d;
    }

    public Double getFilterStrength() {
        return this.filterStrength;
    }

    public void setFilterStrength(Double d) {
        this.filterStrength = d;
    }

    public String getMediaType() {
        return this.mediaType;
    }

    public void setMediaType(String str) {
        this.mediaType = str;
    }
}
