package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.activity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.ads.sdk.ads.SdkAd;
import com.ads.sdk.funtion.AdCallback;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.R;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.adapter.FrameViewPagerAdaptor;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.adapter.InnerViewPagerAdapter;


import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.application.MyApplication;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.dailog.DialogFinishListner;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.fragments.CategoryListFragment;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.fragments.GenralFragment;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.fragments.StickerFragment;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.RingModel;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.TemplateJason.Main;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.TemplateJason.RootTemplate;


import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.myAds.Log;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.Api;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.CommonUtils;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.Constant;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.CustomDialog;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.CustomViewPager;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.EPreferences;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.Utils;
import com.bumptech.glide.load.Key;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd;
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAdLoadCallback;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TemplateListActivity extends AppCompatActivity {
    public static CustomDialog customDialog;

    private ImageView btnBack;


    public ArrayList<Fragment> fragments = new ArrayList<>();


    private TextView txtT;


    Context mContext;
    private CustomViewPager mCustomViewPager;
    private MyApplication application;

    private void bannerNativeAds() {
        FrameLayout frAds;
        ShimmerFrameLayout shimmerAds;

        frAds = findViewById(R.id.fr_ads);
        shimmerAds = findViewById(R.id.shimmer_native);



        SdkAd.getInstance().loadNativeAd(this, MyApplication.getApplication().nativeId, R.layout.native_medium, frAds, shimmerAds, new AdCallback() {
            @Override
            public void onAdFailedToLoad(@org.jetbrains.annotations.Nullable LoadAdError i) {
                super.onAdFailedToLoad(i);
                frAds.removeAllViews();
            }

            @Override
            public void onAdFailedToShow(@org.jetbrains.annotations.Nullable AdError adError) {
                super.onAdFailedToShow(adError);
                frAds.removeAllViews();
            }
        });
    }
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        CommonUtils.updateLanguage(this);


        setContentView(R.layout.activity_content_list);
        MyApplication.mTemplateListActivity=this;
        application=MyApplication.getInstance();
        bannerNativeAds();
        this.mContext = this;
        if (!isNetworkConnected()) {
            showNetworkDialog();
        }
        CustomDialog customDialog2 = new CustomDialog(this);
        customDialog = customDialog2;
        customDialog2.show();

        initView();
        initListeners();


        try {
            checkDir();
        } catch (Exception e) {

        }


        new Thread(new Runnable() {
            public final void run() {
                LoadData();
            }
        }).start();


    }


    private void initListeners() {

        this.btnBack.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                finish();
            }
        });

    }


    private void initView() {
        this.mCustomViewPager = findViewById(R.id.innerViewPager);


        this.txtT = findViewById(R.id.txtT);
        this.btnBack = findViewById(R.id.btnBack);

    }


    public void onBackPressed() {
        finish();
    }


    private void checkDir() {
        if (Build.VERSION.SDK_INT <= 29) {
            File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/" + getString(R.string.app_name));
            if (!file.exists()) {
                file.mkdirs();
            }
        }
    }


    ArrayList arrayList;
    ArrayList arrayList2;
    ArrayList arrayList3;
    String url = "";

    public void LoadData() {

//        try {
//            url = Utils.getAssetJsonData(TemplateListActivity.this,"template.data");
//
//        } catch (Exception e) {
//            e.printStackTrace();
//
//        }
        Api.ApiInterface apiInterface = Api.getApiData().create(Api.ApiInterface.class);

        Call<JsonObject> call = apiInterface.loadTemplateData();
//        progressBar.setVisibility(View.VISIBLE);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {

                if (response.isSuccessful()) {
//                    progressBar.setVisibility(View.GONE);
                    loaddata(response.body());

                }

            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Toast.makeText(TemplateListActivity.this, getString(R.string.no_internet_con), Toast.LENGTH_SHORT).show();
//                progressBar.setVisibility(View.GONE);
            }
        });

    }

    private boolean isNetworkConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService("connectivity");
        return connectivityManager.getActiveNetworkInfo() != null && connectivityManager.getActiveNetworkInfo().isConnected();
    }

    private void loaddata(JsonObject s) {
        ArrayList<RootTemplate> root_templete = new Gson().fromJson(s, Main.class).getResults();
        for (int i = 0; i < root_templete.size(); i++) {
            if (root_templete.get(i).getType().toLowerCase().contains("Portrait".toLowerCase()) || root_templete.get(i).getType().toLowerCase().contains("Wallpaper".toLowerCase())) {
                if (Constant.category.containsKey("general")) {
                    arrayList = Constant.category.get("general");
                } else {
                    arrayList = new ArrayList();
                }
                arrayList.add(root_templete.get(i));
                Constant.category.put("general", arrayList);
            } else if (root_templete.get(i).getType().toLowerCase().contains("Cutout".toLowerCase())) {
                if (Constant.category.containsKey("frame")) {
                    arrayList3 = Constant.category.get("frame");
                } else {
                    arrayList3 = new ArrayList();
                }
                arrayList3.add(root_templete.get(i));
                Constant.category.put("frame", arrayList3);
            } else if (root_templete.get(i).getType().toLowerCase().contains("Collage".toLowerCase())) {
                if (Constant.category.containsKey("collage")) {
                    arrayList2 = Constant.category.get("collage");
                } else {
                    arrayList2 = new ArrayList();
                }
                arrayList2.add(root_templete.get(i));
                Constant.category.put("collage", arrayList2);
            }
        }
        runOnUiThread(new Runnable() {
            public final void run() {
                if (fragments.isEmpty()) {
                    fragments.add(new GenralFragment().newInstance(2));
                    fragments.add(new GenralFragment().newInstance(3));
                    fragments.add(new GenralFragment().newInstance(1));
                }
                mCustomViewPager.setAdapter(new InnerViewPagerAdapter(getSupportFragmentManager(), 1, fragments));
                mCustomViewPager.setPagingEnabled(false);
                mCustomViewPager.setOffscreenPageLimit(3);
                String tag = getIntent().getStringExtra("tag");
                if (tag.equalsIgnoreCase("Template")) {
                    txtT.setText(getString(R.string.template));
                    mCustomViewPager.setCurrentItem(0);
                } else if (tag.equalsIgnoreCase("Collage")) {
                    txtT.setText(getString(R.string.collage));
                    mCustomViewPager.setCurrentItem(1);
                } else {
                    txtT.setText(getString(R.string.frame));
                    mCustomViewPager.setCurrentItem(2);
                }
                mCustomViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                    public void onPageScrollStateChanged(int i) {
                    }

                    public void onPageScrolled(int i, float f, int i2) {
                    }

                    public void onPageSelected(int i) {
//                        setSelectedTab(i);
                        try {
                            if (fragments.get(i) != null) {
                                ((CategoryListFragment) fragments.get(i)).refreshAds();
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        customDialog.dismiss();
                    }
                });
            }
        });
    }

    public void showNetworkDialog() {
        Dialog dialog2 = new Dialog(this);
        dialog2.setContentView(R.layout.network_dialog);
        dialog2.getWindow().setFlags(8, 8);
        dialog2.show();
        dialog2.getWindow().getDecorView().setSystemUiVisibility(getWindow().getDecorView().getSystemUiVisibility());
        dialog2.getWindow().clearFlags(8);
        dialog2.getWindow().setLayout(-1, -1);
        dialog2.findViewById(R.id.btnRetry).setOnClickListener(new View.OnClickListener() {


            public final void onClick(View view) {
                dialog2.dismiss();
            }
        });
        dialog2.getWindow().setBackgroundDrawableResource(R.color.transparent);
    }


    public boolean isVideoAdsLoaded = false;
    public boolean isWatermarkdailogClose = false;
    private RewardedInterstitialAd rewardedIntAdForPremiumItem;
    private boolean isUserErnedReward = false;
    public DialogFinishListner callBackForRewardedInt;

    public void showRewarededIntForPremiumItem() {
        Log.d("RewaredInt", "show RewarededInt For PremiumItem");
        isUserErnedReward = false;
        rewardedIntAdForPremiumItem.show(TemplateListActivity.this, new OnUserEarnedRewardListener() {
            @Override
            public void onUserEarnedReward(@NonNull RewardItem rewardItem) {
                isUserErnedReward = true;
            }
        });
    }

    public void loadAdRewardedIntForPremiumItem() {
//        if (EPreferences.getInstance(TemplateListActivity.this).getString(EPreferences.PREF_IS_PERCHASE, "0").equals("1")) {
//            Log.d("RewaredInt", "===Pro User, So Ads Not Load===");
//            return;
//        }
        if (rewardedIntAdForPremiumItem != null && isVideoAdsLoaded) {
            Log.d("RewaredInt", "Already Rewarded Int Loaded.");
            return;
        }
        // Use the test ad unit ID to load an ad.
        RewardedInterstitialAd.load(TemplateListActivity.this, getString(R.string.admob_rewared_int_ad_for_premium_item),
                new AdRequest.Builder().build(), new RewardedInterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(RewardedInterstitialAd ad) {
                        Log.d("RewaredInt", "Ad was loaded.");
                        rewardedIntAdForPremiumItem = ad;
                        isVideoAdsLoaded = true;
                        application.EventRegister("Rewareded_Int_Load", new Bundle());
                        rewardedIntAdForPremiumItem.setFullScreenContentCallback(new FullScreenContentCallback() {
                            @Override
                            public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                                super.onAdFailedToShowFullScreenContent(adError);
                                Log.e("RewaredInt", "Ad failed to show fullscreen content.");
                                isVideoAdsLoaded = false;
                                rewardedIntAdForPremiumItem = null;
                                callBackForRewardedInt.CloseDialog();
                            }

                            @Override
                            public void onAdShowedFullScreenContent() {
                                super.onAdShowedFullScreenContent();
                                // Called when ad is shown.
                                Log.d("RewaredInt", "Ad showed fullscreen content.");
                            }

                            @Override
                            public void onAdDismissedFullScreenContent() {
                                super.onAdDismissedFullScreenContent();
                                application.userActionCount = 0;
                                Log.d("RewaredInt", "Ad dismissed fullscreen content.");
                                application.EventRegister("Rewareded_Int_Close", new Bundle());
                                rewardedIntAdForPremiumItem = null;
                                isVideoAdsLoaded = false;
                                callBackForRewardedInt.CloseDialog();
                            }

                            @Override
                            public void onAdImpression() {
                                super.onAdImpression();
                                // Called when an impression is recorded for an ad.
                                Log.d("RewaredInt", "Ad recorded an impression.");
                            }
                        });
                    }

                    @Override
                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        Log.d("RewaredInt", loadAdError.toString());
                        application.EventRegister("Rewareded_Int_Failed_To_Load", new Bundle());
                        isVideoAdsLoaded = false;
                        rewardedIntAdForPremiumItem = null;
                    }
                });
    }

}
