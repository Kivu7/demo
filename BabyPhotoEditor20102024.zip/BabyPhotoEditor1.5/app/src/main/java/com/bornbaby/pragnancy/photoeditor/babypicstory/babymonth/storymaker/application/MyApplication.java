package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.application;

import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.provider.Settings;

import androidx.lifecycle.MutableLiveData;

import com.ads.rn.admob.Admob;
import com.ads.rn.admob.AppOpenManager;
import com.ads.rn.ads.RNAd;
import com.ads.rn.ads.wrapper.ApInterstitialAd;
import com.ads.rn.ads.wrapper.ApNativeAd;
import com.ads.rn.application.AdsMultiDexApplication;
import com.ads.rn.billing.AppPurchase;
import com.ads.rn.config.AdjustConfig;
import com.ads.rn.config.RNAdConfig;
import com.ads.rn.funtion.AdCallback;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.R;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.activity.SplashScreen;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.activity.TemplateListActivity;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.myAds.AdSDKPref;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.myAds.Log;
import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils.Utils;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.LoadAdError;
import com.google.firebase.analytics.FirebaseAnalytics;

import org.json.JSONException;
import org.json.JSONObject;

import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

public class MyApplication extends AdsMultiDexApplication {
    public static MyApplication myApplication;

    public Context context;
    public static TemplateListActivity mTemplateListActivity;
    public String mCurrentUnlockItemName="";
    public String isReadyPlaceToAppOpenAd="0";
    public boolean isSpashScreenAdLoad=false;

    public static MyApplication getInstance() {
        return myApplication;
    }
    public static ApInterstitialAd inter_select_image;
    public static ApInterstitialAd inter_preview;
    public static ApInterstitialAd inter_home_action;
    public static ApInterstitialAd inter_template;
    public static MutableLiveData<ApNativeAd> nativeAdsLanguage = new MutableLiveData<>();
    public static MutableLiveData<ApNativeAd> nativeAdsLanguage2 = new MutableLiveData<>();
    public static MutableLiveData<ApNativeAd> nativeAdsOnBoardingOne = new MutableLiveData<>();
    public static MutableLiveData<ApNativeAd> nativeAdsOnBoardingTwo = new MutableLiveData<>();
    public static MutableLiveData<ApNativeAd> nativeAdsOnBoardingThree = new MutableLiveData<>();


    public static MutableLiveData<ApNativeAd> nativeAdsSeeAll = new MutableLiveData<>();
    public static MutableLiveData<ApNativeAd> nativeAdsmyCreation = new MutableLiveData<>();
    public static MutableLiveData<ApNativeAd> nativeAdshomeExit = new MutableLiveData<>();
    public static MutableLiveData<ApNativeAd> nativesavemedia = new MutableLiveData<>();
    public static MutableLiveData<ApNativeAd> nativeCreation = new MutableLiveData<>();
    public static MutableLiveData<ApNativeAd> nativePrevie = new MutableLiveData<>();

    public static MutableLiveData<ApNativeAd> nativeSelectImage = new MutableLiveData<>();
    public static MutableLiveData<ApNativeAd> nativeSelectTemplate = new MutableLiveData<>();
    public static MutableLiveData<ApNativeAd> nativeCreationViewImage = new MutableLiveData<>();
    public MutableLiveData<Boolean> isAdCloseSplash = new MutableLiveData<>();
//    public String intterialID = "ca-app-pub-6082872268446334/2280292750";
//    public String bannerId = "ca-app-pub-6082872268446334/7029853298";
//    public String nativeId = "ca-app-pub-6082872268446334/5229889725";
//    public String appopenResumeId = "ca-app-pub-6082872268446334/1701708257";

    public String intterialID = "ca-app-pub-3940256099942544/1033173712";
    public String bannerId = "ca-app-pub-3940256099942544/9214589741";
    public String nativeId = "ca-app-pub-3940256099942544/2247696110";
    public String appopenResumeId = "ca-app-pub-3940256099942544/9257395921";


    public static String SPLIT_PATTERN = "?";
    public static String App_url = "http://babyphoto.com/Babynew/";
     public static  String BASE_URL = "http://babyphoto.com/";

    public static volatile MyApplication instance;
    public int userActionCount = 0;
    private FirebaseAnalytics mFirebaseAnalytics;

    public static MyApplication getApplication() {
        return instance;
    }

    public void onCreate() {
        super.onCreate();
        this.context = this;
        myApplication = this;
        instance = this;
        initAds();
        initBilling();
        String url;
        FirebaseAnalytics.getInstance(this);
        try {
            url = Utils.getAssetJsonData(instance,"app_url.data");
            Log.i("VVBB","app_url : "+url);
            urlsdata(url);
        } catch (Exception e) {
        }

    }

    boolean isDebug = false;
    private void initAds() {
        String environment = isDebug ? RNAdConfig.ENVIRONMENT_DEVELOP : RNAdConfig.ENVIRONMENT_PRODUCTION;
        mRNAdConfig = new RNAdConfig(this, environment);

        AdjustConfig adjustConfig = new AdjustConfig(true, getString(R.string.adjust_token));
        mRNAdConfig.setAdjustConfig(adjustConfig);
        mRNAdConfig.setFacebookClientToken(getString(R.string.facebook_client_token));
        mRNAdConfig.setAdjustTokenTiktok(getString(R.string.tiktok_token));
        mRNAdConfig.setIdAdResume(getString(R.string.aoa_resume));
        if (isDebug) {
            String androidId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
            String id = md5(androidId).toUpperCase(Locale.getDefault());
            List<String> a = new ArrayList<>();
            a.add(id);
            mRNAdConfig.setListDeviceTest(a);
        }
        RNAd.getInstance().init(this, mRNAdConfig);
        Admob.getInstance().setDisableAdResumeWhenClickAds(false);
        Admob.getInstance().setOpenActivityAfterShowInterAds(true);

        AppOpenManager.getInstance().disableAppResumeWithActivity(SplashScreen.class);
    }
    private String md5(String s) {
        try {
            MessageDigest digest = MessageDigest.getInstance("MD5");
            digest.update(s.getBytes());
            byte[] messageDigest = digest.digest();
            StringBuilder hexString = new StringBuilder();
            for (byte b : messageDigest) {
                String h = Integer.toHexString(0xFF & b);
                while (h.length() < 2) {
                    h = "0" + h;
                }
                hexString.append(h);
            }
            return hexString.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    private void initBilling() {
        List<String> listIAP = new ArrayList<>();
        listIAP.add("android.test.purchased");
        List<String> listSub = new ArrayList<>();
        AppPurchase.getInstance().initBilling(this, listIAP, listSub);
    }
    public static Context getContext() {
        return getContext();
    }
    public void urlsdata(String spath) {
        try {
            JSONObject jsonObject = new JSONObject(spath);
            JSONObject v4 = jsonObject.getJSONObject("v4");
            String baseUrl = v4.getString("baseUrl");
            String key = v4.getString("apikey");
            App_url = baseUrl;
            BASE_URL = key;

        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }
    public void EventRegister(String rewardedIntDialogClose, Bundle bundle) {

    }
    public void preloadSeeAll(Activity activity) {
        if (AdSDKPref.getInstance(this).getString(AdSDKPref.TAG_ALL_AD_OFF, "0").equals("off") || (AdSDKPref.getInstance(MyApplication.this).getString(AdSDKPref.TAG_NATIVE_SEE_ALL_ONOFF, "0")).equalsIgnoreCase("off") || !isNetworkAvailable(MyApplication.this)) {
            MyApplication.nativeAdsSeeAll.setValue(null);
            return;
        }

        RNAd.getInstance().loadNativeAdResultCallback(
                activity,
                getString(R.string.native_welcome),
                R.layout.native_medium,
                new AdCallback() {
                    @Override
                    public void onNativeAdLoaded(ApNativeAd nativeAd) {
                        super.onNativeAdLoaded(nativeAd);
                        MyApplication.nativeAdsSeeAll.setValue(nativeAd);
                    }

                    @Override
                    public void onAdFailedToLoad(LoadAdError i) {
                        super.onAdFailedToLoad(i);
                        MyApplication.nativeAdsSeeAll.setValue(null);
                    }

                    @Override
                    public void onAdFailedToShow(AdError adError) {
                        super.onAdFailedToShow(adError);
                        MyApplication.nativeAdsSeeAll.setValue(null);
                    }
                }
        );

    }
    public void preloadhomeExit(Activity activity) {
        if (AdSDKPref.getInstance(this).getString(AdSDKPref.TAG_ALL_AD_OFF, "0").equals("off") || (AdSDKPref.getInstance(MyApplication.this).getString(AdSDKPref.TAG_NATIVE_EXIT_ONOFF, "0")).equalsIgnoreCase("off") || !isNetworkAvailable(MyApplication.this)) {
            MyApplication.nativeAdshomeExit.setValue(null);
            return;
        }

        RNAd.getInstance().loadNativeAdResultCallback(
                activity,
                getString(R.string.native_exit),
                R.layout.native_medium,
                new AdCallback() {
                    @Override
                    public void onNativeAdLoaded(ApNativeAd nativeAd) {
                        super.onNativeAdLoaded(nativeAd);
                        MyApplication.nativeAdshomeExit.setValue(nativeAd);
                    }

                    @Override
                    public void onAdFailedToLoad(LoadAdError i) {
                        super.onAdFailedToLoad(i);
                        MyApplication.nativeAdshomeExit.setValue(null);
                    }

                    @Override
                    public void onAdFailedToShow(AdError adError) {
                        super.onAdFailedToShow(adError);
                        MyApplication.nativeAdshomeExit.setValue(null);
                    }
                }
        );

    }
    public void preloadnativeCreation(Activity activity) {
        if (AdSDKPref.getInstance(this).getString(AdSDKPref.TAG_ALL_AD_OFF, "0").equals("off") || (AdSDKPref.getInstance(MyApplication.this).getString(AdSDKPref.TAG_NATIVE_CREATION_ONOFF, "0")).equalsIgnoreCase("off") || !isNetworkAvailable(MyApplication.this)) {
            MyApplication.nativeCreation.setValue(null);
            return;
        }

        RNAd.getInstance().loadNativeAdResultCallback(
                activity,
                getString(R.string.native_result),
                R.layout.native_medium,
                new AdCallback() {
                    @Override
                    public void onNativeAdLoaded(ApNativeAd nativeAd) {
                        super.onNativeAdLoaded(nativeAd);
                        MyApplication.nativeCreation.setValue(nativeAd);
                    }

                    @Override
                    public void onAdFailedToLoad(LoadAdError i) {
                        super.onAdFailedToLoad(i);
                        MyApplication.nativeCreation.setValue(null);
                    }

                    @Override
                    public void onAdFailedToShow(AdError adError) {
                        super.onAdFailedToShow(adError);
                        MyApplication.nativeCreation.setValue(null);
                    }
                }
        );

    }
    public void preloadnativePreview(Activity activity) {
        if (AdSDKPref.getInstance(this).getString(AdSDKPref.TAG_ALL_AD_OFF, "0").equals("off") || (AdSDKPref.getInstance(MyApplication.this).getString(AdSDKPref.TAG_NATIVE_PREVIEW_ONOFF, "0")).equalsIgnoreCase("off") || !isNetworkAvailable(MyApplication.this)) {
            MyApplication.nativePrevie.setValue(null);
            return;
        }

        RNAd.getInstance().loadNativeAdResultCallback(
                activity,
                getString(R.string.native_result),
                R.layout.native_medium,
                new AdCallback() {
                    @Override
                    public void onNativeAdLoaded(ApNativeAd nativeAd) {
                        super.onNativeAdLoaded(nativeAd);
                        MyApplication.nativePrevie.setValue(nativeAd);
                    }

                    @Override
                    public void onAdFailedToLoad(LoadAdError i) {
                        super.onAdFailedToLoad(i);
                        MyApplication.nativePrevie.setValue(null);
                    }

                    @Override
                    public void onAdFailedToShow(AdError adError) {
                        super.onAdFailedToShow(adError);
                        MyApplication.nativePrevie.setValue(null);
                    }
                }
        );

    }
    public void preloadnativeSelectImage(Activity activity) {
        if (AdSDKPref.getInstance(this).getString(AdSDKPref.TAG_ALL_AD_OFF, "0").equals("off") || (AdSDKPref.getInstance(MyApplication.this).getString(AdSDKPref.TAG_NATIVE_SELECTIMAGE_ONOFF, "0")).equalsIgnoreCase("off") || !isNetworkAvailable(MyApplication.this)) {
            MyApplication.nativeSelectImage.setValue(null);
            return;
        }

        RNAd.getInstance().loadNativeAdResultCallback(
                activity,
                getString(R.string.native_result),
                R.layout.native_medium,
                new AdCallback() {
                    @Override
                    public void onNativeAdLoaded(ApNativeAd nativeAd) {
                        super.onNativeAdLoaded(nativeAd);
                        MyApplication.nativeSelectImage.setValue(nativeAd);
                    }

                    @Override
                    public void onAdFailedToLoad(LoadAdError i) {
                        super.onAdFailedToLoad(i);
                        MyApplication.nativeSelectImage.setValue(null);
                    }

                    @Override
                    public void onAdFailedToShow(AdError adError) {
                        super.onAdFailedToShow(adError);
                        MyApplication.nativeSelectImage.setValue(null);
                    }
                }
        );

    }
    public void preloadnativeSelectTemplate(Activity activity) {
        if (activity==null){
            return;
        }
        if (AdSDKPref.getInstance(this).getString(AdSDKPref.TAG_ALL_AD_OFF, "0").equals("off") || (AdSDKPref.getInstance(MyApplication.this).getString(AdSDKPref.TAG_NATIVE_SELECTTEMPLATE_ONOFF, "0")).equalsIgnoreCase("off") || !isNetworkAvailable(MyApplication.this)) {
            MyApplication.nativeSelectTemplate.setValue(null);
            return;
        }

        RNAd.getInstance().loadNativeAdResultCallback(
                activity,
                getString(R.string.native_result),
                R.layout.native_medium,
                new AdCallback() {
                    @Override
                    public void onNativeAdLoaded(ApNativeAd nativeAd) {
                        super.onNativeAdLoaded(nativeAd);
                        MyApplication.nativeSelectTemplate.setValue(nativeAd);
                    }

                    @Override
                    public void onAdFailedToLoad(LoadAdError i) {
                        super.onAdFailedToLoad(i);
                        MyApplication.nativeSelectTemplate.setValue(null);
                    }

                    @Override
                    public void onAdFailedToShow(AdError adError) {
                        super.onAdFailedToShow(adError);
                        MyApplication.nativeSelectTemplate.setValue(null);
                    }
                }
        );

    }
    public void preloadnativeCreationViewImage(Activity activity) {
        if (AdSDKPref.getInstance(this).getString(AdSDKPref.TAG_ALL_AD_OFF, "0").equals("off") || (AdSDKPref.getInstance(MyApplication.this).getString(AdSDKPref.TAG_NATIVE_CREATIONVIEWIMAGE_ONOFF, "0")).equalsIgnoreCase("off") || !isNetworkAvailable(MyApplication.this)) {
            MyApplication.nativeCreationViewImage.setValue(null);
            return;
        }

        RNAd.getInstance().loadNativeAdResultCallback(
                activity,
                getString(R.string.native_result),
                R.layout.native_medium,
                new AdCallback() {
                    @Override
                    public void onNativeAdLoaded(ApNativeAd nativeAd) {
                        super.onNativeAdLoaded(nativeAd);
                        MyApplication.nativeCreationViewImage.setValue(nativeAd);
                    }

                    @Override
                    public void onAdFailedToLoad(LoadAdError i) {
                        super.onAdFailedToLoad(i);
                        MyApplication.nativeCreationViewImage.setValue(null);
                    }

                    @Override
                    public void onAdFailedToShow(AdError adError) {
                        super.onAdFailedToShow(adError);
                        MyApplication.nativeCreationViewImage.setValue(null);
                    }
                }
        );

    }

    public void preLoadNativeSaveMedia(Activity homeActivity) {
        if (!(Objects.requireNonNull(AdSDKPref.getInstance(instance)).getString(AdSDKPref.TAG_NATIVE_SAVE_MEDIA_ONOFF, "0")).equalsIgnoreCase("off")) {

            RNAd.getInstance().loadNativeAdResultCallback(
                    homeActivity,
                    getString(R.string.native_list_media),
                    R.layout.native_medium,
                    new AdCallback() {
                        @Override
                        public void onNativeAdLoaded(ApNativeAd nativeAd) {
                            super.onNativeAdLoaded(nativeAd);
                            MyApplication.instance.nativesavemedia.setValue(nativeAd);
                        }

                        @Override
                        public void onAdFailedToLoad(LoadAdError i) {
                            super.onAdFailedToLoad(i);
                            MyApplication.instance.nativesavemedia.setValue(null);
                        }

                        @Override
                        public void onAdFailedToShow(AdError adError) {
                            super.onAdFailedToShow(adError);
                            MyApplication.instance.nativesavemedia.setValue(null);
                        }
                    }
            );
        } else {
            MyApplication.instance.nativesavemedia.setValue(null);
        }
    }



    public void preLoadNativeChooseFace(Activity homeActivity) {
        if (!(Objects.requireNonNull(AdSDKPref.getInstance(instance)).getString(AdSDKPref.TAG_NATIVE_MYCREATION_ONOFF, "0")).equalsIgnoreCase("off")) {

            RNAd.getInstance().loadNativeAdResultCallback(
                    homeActivity,
                    getString(R.string.native_list_media),
                    R.layout.native_medium,
                    new AdCallback() {
                        @Override
                        public void onNativeAdLoaded(ApNativeAd nativeAd) {
                            super.onNativeAdLoaded(nativeAd);
                            MyApplication.instance.nativeAdsmyCreation.setValue(nativeAd);
                        }

                        @Override
                        public void onAdFailedToLoad(LoadAdError i) {
                            super.onAdFailedToLoad(i);
                            MyApplication.instance.nativeAdsmyCreation.setValue(null);
                        }

                        @Override
                        public void onAdFailedToShow(AdError adError) {
                            super.onAdFailedToShow(adError);
                            MyApplication.instance.nativeAdsmyCreation.setValue(null);
                        }
                    }
            );
        } else {
            MyApplication.instance.nativeAdsmyCreation.setValue(null);
        }
    }


    public void preloadLangugeOne(Activity activity) {
        android.util.Log.e("NativeLanguege", "HighFloor ==> 1");

        if (!AdSDKPref.getInstance(this).getString(AdSDKPref.TAG_NATIVE_LANGUAGE_1_ONOFF, "0").equalsIgnoreCase("off")) {
            android.util.Log.e("NativeLanguege", "HighFloor ==> 2");

            int layout = R.layout.native_medium;


            if (AdSDKPref.getInstance(this).getString(AdSDKPref.TAG_NAITVE_LANGUAGE_HIGH_FLOW, "off").equalsIgnoreCase("on")) {
                android.util.Log.e("NativeLanguege", "HighFloor ==> true");

                RNAd.getInstance().loadNativePriorityAlternate(
                        activity,
                        getString(R.string.native_language_1_high),
                        getString(R.string.native_language_1_all_price),
                        layout,
                        new AdCallback() {
                            @Override
                            public void onNativeAdLoaded(ApNativeAd nativeAd) {
                                super.onNativeAdLoaded(nativeAd);
                                preLoadNativeAdLangugeTwo(activity);
                                MyApplication.nativeAdsLanguage.setValue(nativeAd);
                            }

                            @Override
                            public void onAdFailedToLoad(LoadAdError i) {
                                super.onAdFailedToLoad(i);
                                preLoadNativeAdLangugeTwo(activity);
                                MyApplication.nativeAdsLanguage.setValue(null);
                            }

                            @Override
                            public void onAdFailedToShow(AdError adError) {
                                super.onAdFailedToShow(adError);
                                preLoadNativeAdLangugeTwo(activity);
                                MyApplication.nativeAdsLanguage.setValue(null);
                            }
                        }
                );
            } else {

                android.util.Log.e("NativeLanguege", "HighFloor ==> false");
                RNAd.getInstance().loadNativeAdResultCallback(
                        activity,
                        getString(R.string.native_language_1),
                        layout,
                        new AdCallback() {
                            @Override
                            public void onNativeAdLoaded(ApNativeAd nativeAd) {
                                super.onNativeAdLoaded(nativeAd);
                                preLoadNativeAdLangugeTwo(activity);
                                MyApplication.nativeAdsLanguage.setValue(nativeAd);
                            }

                            @Override
                            public void onAdFailedToLoad(LoadAdError i) {
                                super.onAdFailedToLoad(i);
                                preLoadNativeAdLangugeTwo(activity);
                                MyApplication.nativeAdsLanguage.setValue(null);
                            }

                            @Override
                            public void onAdFailedToShow(AdError adError) {
                                super.onAdFailedToShow(adError);
                                preLoadNativeAdLangugeTwo(activity);
                                MyApplication.nativeAdsLanguage.setValue(null);
                            }
                        }
                );
            }

        } else {
            MyApplication.nativeAdsLanguage.setValue(null);
        }
    }

    public void preLoadNativeAdLangugeTwo(Activity activity) {


        if (!AdSDKPref.getInstance(this).getString(AdSDKPref.TAG_NATIVE_LANGUAGE_2_ONOFF, "0").equalsIgnoreCase("off")) {


            int layout = R.layout.native_medium;


            if (AdSDKPref.getInstance(this).getString(AdSDKPref.TAG_NAITVE_LANGUAGE_HIGH_FLOW, "off").equalsIgnoreCase("on")) {
                android.util.Log.e("NativeLanguege", "HighFloor ==> true");
                RNAd.getInstance().loadNativePriorityAlternate(
                        activity,
                        getString(R.string.native_language_2_high),
                        getString(R.string.native_language_2_all_price),
                        layout,
                        new AdCallback() {
                            @Override
                            public void onNativeAdLoaded(ApNativeAd nativeAd) {
                                super.onNativeAdLoaded(nativeAd);
                                MyApplication.nativeAdsLanguage2.setValue(nativeAd);
                            }

                            @Override
                            public void onAdFailedToLoad(LoadAdError i) {
                                super.onAdFailedToLoad(i);
                                MyApplication.nativeAdsLanguage2.setValue(null);
                            }

                            @Override
                            public void onAdFailedToShow(AdError adError) {
                                super.onAdFailedToShow(adError);
                                MyApplication.nativeAdsLanguage2.setValue(null);
                            }
                        }
                );
            } else {

                android.util.Log.e("NativeLanguege", "HighFloor ==> false");
                RNAd.getInstance().loadNativeAdResultCallback(
                        activity,
                        getString(R.string.native_language_2),
                        layout,
                        new AdCallback() {
                            @Override
                            public void onNativeAdLoaded(ApNativeAd nativeAd) {
                                super.onNativeAdLoaded(nativeAd);
                                MyApplication.nativeAdsLanguage2.setValue(nativeAd);
                            }

                            @Override
                            public void onAdFailedToLoad(LoadAdError i) {
                                super.onAdFailedToLoad(i);
                                MyApplication.nativeAdsLanguage2.setValue(null);
                            }

                            @Override
                            public void onAdFailedToShow(AdError adError) {
                                super.onAdFailedToShow(adError);
                                MyApplication.nativeAdsLanguage2.setValue(null);
                            }
                        }
                );
            }

        } else {
            MyApplication.nativeAdsLanguage2.setValue(null);
        }
    }
    public static final boolean isNetworkAvailable(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService("connectivity");
        NetworkInfo activeNetworkInfo = connectivityManager != null ? connectivityManager.getActiveNetworkInfo() : null;
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    public void preLoadIntersial_select_image() {
        if (AdSDKPref.getInstance(this).getString(AdSDKPref.TAG_ALL_AD_OFF, "0").equals("off")) {
            return;
        }

        if (AdSDKPref.getInstance(this).getString(AdSDKPref.TAG_INTER_SELECT_IMAGE_ONOFF, "0").equals("off")) {
            return;
        }

        RNAd.getInstance().getInterstitialAds(
                this,
                getString(R.string.inter_select_image),
                new AdCallback() {
                    @Override
                    public void onApInterstitialLoad(ApInterstitialAd apInterstitialAd) {
                        super.onApInterstitialLoad(apInterstitialAd);
                        android.util.Log.e("SPLASHH", "onApInterstitialLoad");
                        MyApplication.inter_select_image = apInterstitialAd;
                    }
                }
        );

    }

    public void preLoadIntersial_preview() {
        if (AdSDKPref.getInstance(this).getString(AdSDKPref.TAG_ALL_AD_OFF, "0").equals("off")) {
            return;
        }

        if (AdSDKPref.getInstance(this).getString(AdSDKPref.TAG_INTER_PREVIEW_ONOFF, "0").equals("off")) {
            return;
        }

        RNAd.getInstance().getInterstitialAds(
                this,
                getString(R.string.inter_preview),
                new AdCallback() {
                    @Override
                    public void onApInterstitialLoad(ApInterstitialAd apInterstitialAd) {
                        super.onApInterstitialLoad(apInterstitialAd);
                        android.util.Log.e("SPLASHH", "onApInterstitialLoad");
                        MyApplication.inter_preview = apInterstitialAd;
                    }
                }
        );

    }

    public void preloadintersial_home() {
        if (AdSDKPref.getInstance(this).getString(AdSDKPref.TAG_ALL_AD_OFF, "0").equals("off")) {
            return;
        }

        if (AdSDKPref.getInstance(this).getString(AdSDKPref.TAG_INTER_HOME_ONOFF, "0").equals("off")) {
            return;
        }

        RNAd.getInstance().getInterstitialAds(
                this,
                getString(R.string.inter_home),
                new AdCallback() {
                    @Override
                    public void onApInterstitialLoad(ApInterstitialAd apInterstitialAd) {
                        super.onApInterstitialLoad(apInterstitialAd);
                        android.util.Log.e("SPLASHH", "onApInterstitialLoad");
                        MyApplication.inter_home_action = apInterstitialAd;
                    }
                }
        );

    }
    public void preloadintersial_template() {
        if (AdSDKPref.getInstance(this).getString(AdSDKPref.TAG_ALL_AD_OFF, "0").equals("off")) {
            return;
        }

        if (AdSDKPref.getInstance(this).getString(AdSDKPref.TAG_INTER_TEMPLATE_ONOFF, "0").equals("off")) {
            return;
        }

        RNAd.getInstance().getInterstitialAds(
                this,
                getString(R.string.inter_template),
                new AdCallback() {
                    @Override
                    public void onApInterstitialLoad(ApInterstitialAd apInterstitialAd) {
                        super.onApInterstitialLoad(apInterstitialAd);
                        android.util.Log.e("SPLASHH", "onApInterstitialLoad");
                        MyApplication.inter_template = apInterstitialAd;
                    }
                }
        );

    }
}
