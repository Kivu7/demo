package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.utils;

import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.os.Build;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.TemplateJason.RootTemplate;
import java.util.ArrayList;
import java.util.HashMap;

public class Constant {

    public static Bitmap Cutout = null;
    public static Bitmap Cutout_portrait = null;

    public static final String IS_FROM_SETTINGS = "isFromSetting";


    public static Typeface TYPEFACE = null;
    public static HashMap<String, ArrayList<RootTemplate>> category = new HashMap<>();






}
