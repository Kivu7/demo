package com.bornbaby.pragnancy.photoeditor.babypicstory.babymonth.storymaker.model.TemplateJason;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;
import java.util.ArrayList;

public class Main implements Serializable {
    @SerializedName("next")
    private Object next;
    @SerializedName("page_size")
    private Integer pageSize;
    @SerializedName("previous")
    private Object previous;
    @SerializedName("results")
    private ArrayList<RootTemplate> results = null;
    @SerializedName("results_size")
    private Integer resultsSize;

    public Integer getPageSize() {
        return this.pageSize;
    }

    public void setPageSize(Integer num) {
        this.pageSize = num;
    }

    public Object getPrevious() {
        return this.previous;
    }

    public void setPrevious(Object obj) {
        this.previous = obj;
    }

    public Object getNext() {
        return this.next;
    }

    public void setNext(Object obj) {
        this.next = obj;
    }

    public Integer getResultsSize() {
        return this.resultsSize;
    }

    public void setResultsSize(Integer num) {
        this.resultsSize = num;
    }

    public ArrayList<RootTemplate> getResults() {
        return this.results;
    }

    public void setResults(ArrayList<RootTemplate> arrayList) {
        this.results = arrayList;
    }
}
